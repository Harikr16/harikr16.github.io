```python
import pandas as pd
import os

# Read the CSV file into a pandas DataFrame
papers = pd.read_csv("datasets/papers.csv")

# Print head
papers.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>authors</th>
      <th>year</th>
      <th>title</th>
      <th>pdf_name</th>
      <th>abstract</th>
      <th>paper_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0004d0b59e19461ff126e3a08a814c33</td>
      <td>['Martijn Leisink', 'Bert Kappen']</td>
      <td>2001</td>
      <td>Means, Correlations and Bounds</td>
      <td>0004d0b59e19461ff126e3a08a814c33</td>
      <td>The  partition function  for  a  Boltzmann  ma...</td>
      <td>Means.  Correlations  and  Bounds \n\nM.A.R.  ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0004d0b59e19461ff126e3a08a814c33</td>
      <td>['Seongmin Ok']</td>
      <td>2020</td>
      <td>A graph similarity for deep learning</td>
      <td>0004d0b59e19461ff126e3a08a814c33</td>
      <td>Graph neural networks (GNNs) have been success...</td>
      <td>A Graph Similarity for Deep Learning\n\nSeongm...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>000c076c390a4c357313fca29e390ece</td>
      <td>['Christoph Dann', 'Teodor Vanislavov Marinov'...</td>
      <td>2021</td>
      <td>Beyond Value-Function Gaps: Improved Instance-...</td>
      <td>000c076c390a4c357313fca29e390ece</td>
      <td>We provide improved gap-dependent regret bound...</td>
      <td>Beyond Value-Function Gaps: Improved\nInstance...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>003dd617c12d444ff9c80f717c3fa982</td>
      <td>['Ahmed Touati', 'Yann Ollivier']</td>
      <td>2021</td>
      <td>Learning One Representation to Optimize All Re...</td>
      <td>003dd617c12d444ff9c80f717c3fa982</td>
      <td>We introduce the forward-backward (FB) represe...</td>
      <td>Learning One Representation to Optimize All\nR...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>00411460f7c92d2124a67ea0f4cb5f85</td>
      <td>['Maxim Raginsky', 'Svetlana Lazebnik', 'Rebec...</td>
      <td>2008</td>
      <td>Near-minimax recursive density estimation on t...</td>
      <td>00411460f7c92d2124a67ea0f4cb5f85</td>
      <td>NaN</td>
      <td>Near-Minimax Recursive Density Estimation\non ...</td>
    </tr>
  </tbody>
</table>
</div>




```python
main_feature = "paper_text"
processed_feature = main_feature + '_processed'
```


```python
# Remove the columns
papers = papers.drop(columns=['id', 'pdf_name'], axis=1)

# sample only 100 papers
papers = papers.sample(100)

# Print out the first rows of papers
papers.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>authors</th>
      <th>year</th>
      <th>title</th>
      <th>abstract</th>
      <th>paper_text</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>12514</th>
      <td>['Katja Schwarz', 'Yiyi Liao', 'Michael Niemey...</td>
      <td>2020</td>
      <td>GRAF: Generative Radiance Fields for 3D-Aware ...</td>
      <td>While 2D generative adversarial networks have ...</td>
      <td>GRAF: Generative Radiance Fields\nfor 3D-Aware...</td>
    </tr>
    <tr>
      <th>11842</th>
      <td>['Maithra Raghu', 'Justin Gilmer', 'Jason Yosi...</td>
      <td>2017</td>
      <td>SVCCA: Singular Vector Canonical Correlation A...</td>
      <td>We propose a new technique, Singular Vector Ca...</td>
      <td>SVCCA: Singular Vector Canonical Correlation\n...</td>
    </tr>
    <tr>
      <th>1400</th>
      <td>['Jongjin Park', 'Younggyo Seo', 'Chang Liu', ...</td>
      <td>2021</td>
      <td>Object-Aware Regularization for Addressing Cau...</td>
      <td>Behavioral cloning has proven to be effective ...</td>
      <td>Object-Aware Regularization for\nAddressing Ca...</td>
    </tr>
    <tr>
      <th>2995</th>
      <td>['Kolyan Ray', 'Botond Szabo']</td>
      <td>2019</td>
      <td>Debiased Bayesian inference for average treatm...</td>
      <td>Bayesian approaches have become increasingly p...</td>
      <td>Debiased Bayesian inference for average treatm...</td>
    </tr>
    <tr>
      <th>466</th>
      <td>['Jianbo Yang', 'Xuejun Liao', 'Minhua Chen', ...</td>
      <td>2014</td>
      <td>Compressive Sensing of Signals from a GMM with...</td>
      <td>This paper is concerned with compressive sensi...</td>
      <td>Compressive Sensing of Signals from a GMM with...</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Load the regular expression library
import re

# Remove punctuation
papers['paper_text_processed'] = papers['paper_text'].map(lambda x: re.sub('[,\.!?]', '', x))

# Convert the titles to lowercase
papers['paper_text_processed'] = papers['paper_text_processed'].map(lambda x: x.lower())

# Print out the first rows of papers
papers['paper_text_processed'].head()
```




    12514    graf: generative radiance fields\nfor 3d-aware...
    11842    svcca: singular vector canonical correlation\n...
    1400     object-aware regularization for\naddressing ca...
    2995     debiased bayesian inference for average treatm...
    466      compressive sensing of signals from a gmm with...
    Name: paper_text_processed, dtype: object




```python
import gensim
from gensim.utils import simple_preprocess

def sent_to_words(sentences):
    for sentence in sentences:
        yield(gensim.utils.simple_preprocess(str(sentence), deacc=True))  # deacc=True removes punctuations

data = papers.paper_text_processed.values.tolist()
data_words = list(sent_to_words(data))

print(data_words[:1][0][:30])
```

    ['graf', 'generative', 'radiance', 'fields', 'for', 'aware', 'image', 'synthesis', 'katja', 'schwarz', 'yiyi', 'liao', 'michael', 'niemeyer', 'andreas', 'geiger', 'autonomous', 'vision', 'group', 'mpi', 'for', 'intelligent', 'systems', 'and', 'university', 'of', 'tubingen', 'tuempgde', 'abstract', 'while']



```python
# Build the bigram and trigram models
bigram = gensim.models.Phrases(data_words, min_count=5, threshold=100) # higher threshold fewer phrases.
trigram = gensim.models.Phrases(bigram[data_words], threshold=100)  

# Faster way to get a sentence clubbed as a trigram/bigram
bigram_mod = gensim.models.phrases.Phraser(bigram)
trigram_mod = gensim.models.phrases.Phraser(trigram)
```


```python
# NLTK Stop words
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords

stop_words = stopwords.words('english')
stop_words.extend(['from', 'subject', 're', 'edu', 'use'])

# Define functions for stopwords, bigrams, trigrams and lemmatization
def remove_stopwords(texts):
    return [[word for word in simple_preprocess(str(doc)) if word not in stop_words] for doc in texts]

def make_bigrams(texts):
    return [bigram_mod[doc] for doc in texts]

def make_trigrams(texts):
    return [trigram_mod[bigram_mod[doc]] for doc in texts]

def lemmatization(texts, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV']):
    """https://spacy.io/api/annotation"""
    texts_out = []
    for sent in texts:
        doc = nlp(" ".join(sent)) 
        texts_out.append([token.lemma_ for token in doc if token.pos_ in allowed_postags])
    return texts_out
```

    [nltk_data] Downloading package stopwords to /home/hari/nltk_data...
    [nltk_data]   Package stopwords is already up-to-date!



```python
!python3.9 -m spacy download en_core_web_sm
import spacy

# Remove Stop Words
data_words_nostops = remove_stopwords(data_words)

# Form Bigrams
data_words_bigrams = make_bigrams(data_words_nostops)

# Initialize spacy 'en' model, keeping only tagger component (for efficiency)
nlp = spacy.load("en_core_web_sm", disable=['parser', 'ner'])

# Do lemmatization keeping only noun, adj, vb, adv
data_lemmatized = lemmatization(data_words_bigrams, allowed_postags=['NOUN', 'ADJ', 'VERB', 'ADV'])

print(data_lemmatized[:1][0][:30])
```

    Defaulting to user installation because normal site-packages is not writeable
    Collecting en-core-web-sm==3.3.0
      Downloading https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.3.0/en_core_web_sm-3.3.0-py3-none-any.whl (12.8 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m12.8/12.8 MB[0m [31m95.2 MB/s[0m eta [36m0:00:00[0m00:01[0m00:01[0m
    [?25hRequirement already satisfied: spacy<3.4.0,>=3.3.0.dev0 in /home/hari/.local/lib/python3.9/site-packages (from en-core-web-sm==3.3.0) (3.3.1)
    Requirement already satisfied: wasabi<1.1.0,>=0.9.1 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (0.10.1)
    Requirement already satisfied: requests<3.0.0,>=2.13.0 in /usr/local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.28.1)
    Requirement already satisfied: spacy-legacy<3.1.0,>=3.0.9 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.0.10)
    Requirement already satisfied: tqdm<5.0.0,>=4.38.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (4.64.1)
    Requirement already satisfied: spacy-loggers<2.0.0,>=1.0.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (1.0.3)
    Requirement already satisfied: setuptools in /usr/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (50.3.2)
    Requirement already satisfied: langcodes<4.0.0,>=3.2.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.3.0)
    Requirement already satisfied: pathy>=0.3.5 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (0.6.2)
    Requirement already satisfied: catalogue<2.1.0,>=2.0.6 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.0.8)
    Requirement already satisfied: preshed<3.1.0,>=3.0.2 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.0.7)
    Requirement already satisfied: packaging>=20.0 in /usr/local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (21.3)
    Requirement already satisfied: thinc<8.1.0,>=8.0.14 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (8.0.17)
    Requirement already satisfied: srsly<3.0.0,>=2.4.3 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.4.4)
    Requirement already satisfied: murmurhash<1.1.0,>=0.28.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (1.0.8)
    Requirement already satisfied: typer<0.5.0,>=0.3.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (0.4.2)
    Requirement already satisfied: numpy>=1.15.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (1.23.3)
    Requirement already satisfied: jinja2 in /usr/local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.1.2)
    Requirement already satisfied: pydantic!=1.8,!=1.8.1,<1.9.0,>=1.7.4 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (1.8.2)
    Requirement already satisfied: blis<0.8.0,>=0.4.0 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (0.7.8)
    Requirement already satisfied: cymem<2.1.0,>=2.0.2 in /home/hari/.local/lib/python3.9/site-packages (from spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.0.6)
    Requirement already satisfied: pyparsing!=3.0.5,>=2.0.2 in /usr/local/lib/python3.9/site-packages (from packaging>=20.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.0.9)
    Requirement already satisfied: smart-open<6.0.0,>=5.2.1 in /home/hari/.local/lib/python3.9/site-packages (from pathy>=0.3.5->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (5.2.1)
    Requirement already satisfied: typing-extensions>=3.7.4.3 in /home/hari/.local/lib/python3.9/site-packages (from pydantic!=1.8,!=1.8.1,<1.9.0,>=1.7.4->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (4.3.0)
    Requirement already satisfied: charset-normalizer<3,>=2 in /usr/local/lib/python3.9/site-packages (from requests<3.0.0,>=2.13.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.1.1)
    Requirement already satisfied: urllib3<1.27,>=1.21.1 in /usr/local/lib/python3.9/site-packages (from requests<3.0.0,>=2.13.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (1.26.12)
    Requirement already satisfied: certifi>=2017.4.17 in /usr/local/lib/python3.9/site-packages (from requests<3.0.0,>=2.13.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2022.9.24)
    Requirement already satisfied: idna<4,>=2.5 in /usr/local/lib/python3.9/site-packages (from requests<3.0.0,>=2.13.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (3.4)
    Requirement already satisfied: click<9.0.0,>=7.1.1 in /home/hari/.local/lib/python3.9/site-packages (from typer<0.5.0,>=0.3.0->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (8.1.3)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib64/python3.9/site-packages (from jinja2->spacy<3.4.0,>=3.3.0.dev0->en-core-web-sm==3.3.0) (2.1.1)
    
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip available: [0m[31;49m22.2.2[0m[39;49m -> [0m[32;49m22.3.1[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpython3.9 -m pip install --upgrade pip[0m
    [38;5;2m✔ Download and installation successful[0m
    You can now load the package via spacy.load('en_core_web_sm')
    ['field', 'aware', 'image_synthesis', 'katja', 'liao', 'autonomous', 'vision', 'group', 'intelligent_system', 'university', 'tubingen', 'tuempgde', 'abstract', 'generative_adversarial', 'network', 'enable', 'high', 'resolution', 'image', 'syn', 'thesis', 'largely', 'lack', 'understand', 'world', 'image', 'formation', 'process', 'thus', 'provide']



```python
import gensim.corpora as corpora

# Create Dictionary
id2word = corpora.Dictionary(data_lemmatized)

# Create Corpus
texts = data_lemmatized

# Term Document Frequency
corpus = [id2word.doc2bow(text) for text in texts]

# View
print(corpus[:1][0][:30])
```

    [(0, 1), (1, 2), (2, 1), (3, 1), (4, 1), (5, 6), (6, 4), (7, 1), (8, 2), (9, 1), (10, 5), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1), (16, 3), (17, 2), (18, 3), (19, 1), (20, 1), (21, 1), (22, 8), (23, 1), (24, 2), (25, 4), (26, 2), (27, 4), (28, 1), (29, 1)]



```python
# Build LDA model
lda_model = gensim.models.LdaMulticore(corpus=corpus,
                                       id2word=id2word,
                                       num_topics=10, 
                                       random_state=100,
                                       chunksize=100,
                                       passes=10,
                                       per_word_topics=True)
```


```python
from pprint import pprint

# Print the Keyword in the 10 topics
pprint(lda_model.print_topics())
doc_lda = lda_model[corpus]
```

    [(0,
      '0.289*"cid" + 0.008*"model" + 0.005*"function" + 0.005*"result" + '
      '0.005*"solution" + 0.005*"show" + 0.004*"input" + 0.004*"use" + '
      '0.004*"neural" + 0.004*"problem"'),
     (1,
      '0.020*"cid" + 0.014*"model" + 0.009*"learn" + 0.008*"time" + 0.008*"set" + '
      '0.006*"use" + 0.006*"datum" + 0.006*"method" + 0.006*"problem" + '
      '0.006*"function"'),
     (2,
      '0.009*"network" + 0.009*"neural" + 0.009*"learn" + 0.008*"method" + '
      '0.007*"use" + 0.007*"representation" + 0.006*"image" + 0.006*"model" + '
      '0.006*"show" + 0.005*"problem"'),
     (3,
      '0.017*"cid" + 0.015*"measure" + 0.011*"paper" + 0.009*"network" + '
      '0.009*"problem" + 0.008*"reviewer" + 0.008*"learn" + 0.007*"function" + '
      '0.007*"state" + 0.006*"set"'),
     (4,
      '0.017*"model" + 0.013*"learn" + 0.008*"network" + 0.008*"method" + '
      '0.008*"task" + 0.007*"cid" + 0.007*"use" + 0.006*"image" + 0.006*"set" + '
      '0.006*"learning"'),
     (5,
      '0.011*"model" + 0.009*"cid" + 0.008*"method" + 0.008*"path" + 0.007*"base" '
      '+ 0.007*"potential" + 0.007*"set" + 0.006*"image" + 0.006*"sample" + '
      '0.006*"learn"'),
     (6,
      '0.015*"agent" + 0.013*"learn" + 0.012*"action" + 0.009*"goal" + '
      '0.009*"task" + 0.008*"reward" + 0.007*"use" + 0.007*"loss" + 0.007*"show" + '
      '0.007*"policy"'),
     (7,
      '0.013*"model" + 0.010*"label" + 0.009*"cid" + 0.008*"method" + 0.008*"use" '
      '+ 0.007*"matrix" + 0.007*"set" + 0.006*"image" + 0.005*"graph" + '
      '0.005*"feature"'),
     (8,
      '0.052*"cid" + 0.008*"cost" + 0.008*"state" + 0.008*"datum" + 0.007*"regret" '
      '+ 0.007*"use" + 0.006*"bind" + 0.006*"bound" + 0.006*"variable" + '
      '0.006*"function"'),
     (9,
      '0.015*"learn" + 0.015*"model" + 0.011*"question" + 0.011*"network" + '
      '0.009*"agent" + 0.007*"passage" + 0.007*"use" + 0.007*"policy" + '
      '0.007*"hop" + 0.006*"neural"')]



```python
from gensim.models import CoherenceModel

# Compute Coherence Score
coherence_model_lda = CoherenceModel(model=lda_model, texts=data_lemmatized, dictionary=id2word, coherence='c_v')
coherence_lda = coherence_model_lda.get_coherence()
print('Coherence Score: ', coherence_lda)
```

    Coherence Score:  0.277046287548003



```python
# supporting function
def compute_coherence_values(corpus, dictionary, k, a, b):
    
    lda_model = gensim.models.LdaMulticore(corpus=corpus,
                                           id2word=dictionary,
                                           num_topics=k, 
                                           random_state=100,
                                           chunksize=100,
                                           passes=10,
                                           alpha=a,
                                           eta=b, 
                                           workers = 20)
    
    coherence_model_lda = CoherenceModel(model=lda_model, texts=data_lemmatized, dictionary=id2word, coherence='c_v', processes = 20)
    
    return coherence_model_lda.get_coherence()
```


```python
import numpy as np
import tqdm

grid = {}
grid['Validation_Set'] = {}

# Topics range
min_topics = 2
max_topics = 11
step_size = 1
topics_range = range(min_topics, max_topics, step_size)

# Alpha parameter
alpha = list(np.arange(0.01, 1, 0.3))
alpha.append('symmetric')
alpha.append('asymmetric')

# Beta parameter
beta = list(np.arange(0.01, 1, 0.3))
beta.append('symmetric')

# Validation sets
num_of_docs = len(corpus)
corpus_sets = [gensim.utils.ClippedCorpus(corpus, int(num_of_docs*0.75)), 
               corpus]

corpus_title = ['75% Corpus', '100% Corpus']

model_results = {'Validation_Set': [],
                 'Topics': [],
                 'Alpha': [],
                 'Beta': [],
                 'Coherence': []
                }

# Can take a long time to run
if 1 == 1:
    pbar = tqdm.tqdm(total=(len(beta)*len(alpha)*len(topics_range)*len(corpus_title)))
    
    # iterate through validation corpuses
    for i in range(len(corpus_sets)):
        # iterate through number of topics
        for k in topics_range:
            # iterate through alpha values
            for a in alpha:
                # iterare through beta values
                for b in beta:
                    # get the coherence score for the given parameters
                    cv = compute_coherence_values(corpus=corpus_sets[i], dictionary=id2word, 
                                                  k=k, a=a, b=b)
                    # Save the model results
                    model_results['Validation_Set'].append(corpus_title[i])
                    model_results['Topics'].append(k)
                    model_results['Alpha'].append(a)
                    model_results['Beta'].append(b)
                    model_results['Coherence'].append(cv)
                    
                    pbar.update(1)
    pd.DataFrame(model_results).to_csv('lda_tuning_results_1.csv', index=False)
    pbar.close()
```

    
      1%|          | 4/540 [00:53<1:59:37, 13.39s/it]
    
      0%|          | 1/540 [00:06<54:08,  6.03s/it][A
      0%|          | 2/540 [00:11<51:38,  5.76s/it][A
      1%|          | 3/540 [00:17<52:01,  5.81s/it][A
      1%|          | 4/540 [00:23<50:55,  5.70s/it][A
      1%|          | 5/540 [00:28<50:50,  5.70s/it][A
      1%|          | 6/540 [00:34<50:55,  5.72s/it][A
      1%|▏         | 7/540 [00:40<51:12,  5.76s/it][A
      1%|▏         | 8/540 [00:45<50:20,  5.68s/it][A
      2%|▏         | 9/540 [00:53<55:52,  6.31s/it][A
      2%|▏         | 10/540 [00:59<53:34,  6.07s/it][A
      2%|▏         | 11/540 [01:05<54:40,  6.20s/it][A
      2%|▏         | 12/540 [01:12<56:18,  6.40s/it][A
      2%|▏         | 13/540 [01:18<54:08,  6.16s/it][A
      3%|▎         | 14/540 [01:23<53:04,  6.05s/it][A
      3%|▎         | 15/540 [01:31<57:36,  6.58s/it][A
      3%|▎         | 16/540 [01:37<55:47,  6.39s/it][A
      3%|▎         | 17/540 [01:43<55:06,  6.32s/it][A
      3%|▎         | 18/540 [01:49<54:01,  6.21s/it][A
      4%|▎         | 19/540 [01:56<56:22,  6.49s/it][A
      4%|▎         | 20/540 [02:03<55:35,  6.41s/it][A
      4%|▍         | 21/540 [02:09<55:32,  6.42s/it][A
      4%|▍         | 22/540 [02:15<53:12,  6.16s/it][A
      4%|▍         | 23/540 [02:21<53:37,  6.22s/it][A
      4%|▍         | 24/540 [02:27<52:00,  6.05s/it][A
      5%|▍         | 25/540 [02:33<53:10,  6.19s/it][A
      5%|▍         | 26/540 [02:40<56:02,  6.54s/it][A
      5%|▌         | 27/540 [02:51<1:05:37,  7.67s/it][A
      5%|▌         | 28/540 [02:57<1:00:59,  7.15s/it][A
      5%|▌         | 29/540 [03:03<58:48,  6.90s/it]  [A
      6%|▌         | 30/540 [03:09<55:40,  6.55s/it][A
      6%|▌         | 31/540 [03:16<56:34,  6.67s/it][A
      6%|▌         | 32/540 [03:22<54:42,  6.46s/it][A
      6%|▌         | 33/540 [03:28<55:18,  6.55s/it][A
      6%|▋         | 34/540 [03:35<56:29,  6.70s/it][A
      6%|▋         | 35/540 [03:42<55:59,  6.65s/it][A
      7%|▋         | 36/540 [03:48<55:12,  6.57s/it][A
      7%|▋         | 37/540 [03:56<57:08,  6.82s/it][A
      7%|▋         | 38/540 [04:04<59:49,  7.15s/it][A
      7%|▋         | 39/540 [04:11<1:00:52,  7.29s/it][A
      7%|▋         | 40/540 [04:18<59:04,  7.09s/it]  [A
      8%|▊         | 41/540 [04:25<58:02,  6.98s/it][A
      8%|▊         | 42/540 [04:32<58:37,  7.06s/it][A
      8%|▊         | 43/540 [04:38<56:59,  6.88s/it][A
      8%|▊         | 44/540 [04:45<56:20,  6.82s/it][A
      8%|▊         | 45/540 [04:51<54:01,  6.55s/it][A
      9%|▊         | 46/540 [04:58<53:56,  6.55s/it][A
      9%|▊         | 47/540 [05:04<53:48,  6.55s/it][A
      9%|▉         | 48/540 [05:10<52:27,  6.40s/it][A
      9%|▉         | 49/540 [05:17<52:24,  6.40s/it][A
      9%|▉         | 50/540 [05:23<52:58,  6.49s/it][A
      9%|▉         | 51/540 [05:30<53:37,  6.58s/it][A
     10%|▉         | 52/540 [05:37<54:56,  6.76s/it][A
     10%|▉         | 53/540 [05:44<54:29,  6.71s/it][A
     10%|█         | 54/540 [05:50<53:26,  6.60s/it][A
     10%|█         | 55/540 [05:56<52:02,  6.44s/it][A
     10%|█         | 56/540 [06:02<51:08,  6.34s/it][A
     11%|█         | 57/540 [06:08<49:57,  6.21s/it][A
     11%|█         | 58/540 [06:14<49:43,  6.19s/it][A
     11%|█         | 59/540 [06:21<51:21,  6.41s/it][A
     11%|█         | 60/540 [06:29<54:10,  6.77s/it][A
     11%|█▏        | 61/540 [06:36<54:41,  6.85s/it][A
     11%|█▏        | 62/540 [06:42<52:26,  6.58s/it][A
     12%|█▏        | 63/540 [06:49<53:55,  6.78s/it][A
     12%|█▏        | 64/540 [06:56<53:47,  6.78s/it][A
     12%|█▏        | 65/540 [07:02<52:30,  6.63s/it][A
     12%|█▏        | 66/540 [07:09<52:31,  6.65s/it][A
     12%|█▏        | 67/540 [07:16<53:59,  6.85s/it][A
     13%|█▎        | 68/540 [07:23<54:33,  6.94s/it][A
     13%|█▎        | 69/540 [07:29<52:11,  6.65s/it][A
     13%|█▎        | 70/540 [07:36<52:48,  6.74s/it][A
     13%|█▎        | 71/540 [07:43<51:34,  6.60s/it][A
     13%|█▎        | 72/540 [07:49<52:18,  6.71s/it][A
     14%|█▎        | 73/540 [07:56<51:17,  6.59s/it][A
     14%|█▎        | 74/540 [08:02<50:13,  6.47s/it][A
     14%|█▍        | 75/540 [08:08<49:45,  6.42s/it][A
     14%|█▍        | 76/540 [08:15<50:00,  6.47s/it][A
     14%|█▍        | 77/540 [08:21<49:54,  6.47s/it][A
     14%|█▍        | 78/540 [08:28<49:54,  6.48s/it][A
     15%|█▍        | 79/540 [08:34<49:11,  6.40s/it][A
     15%|█▍        | 80/540 [08:40<48:34,  6.34s/it][A
     15%|█▌        | 81/540 [08:47<49:31,  6.47s/it][A
     15%|█▌        | 82/540 [08:54<50:22,  6.60s/it][A
     15%|█▌        | 83/540 [09:01<50:11,  6.59s/it][A
     16%|█▌        | 84/540 [09:08<51:23,  6.76s/it][A
     16%|█▌        | 85/540 [09:15<52:40,  6.95s/it][A
     16%|█▌        | 86/540 [09:22<52:27,  6.93s/it][A
     16%|█▌        | 87/540 [09:29<51:44,  6.85s/it][A
     16%|█▋        | 88/540 [09:35<51:36,  6.85s/it][A
     16%|█▋        | 89/540 [09:43<53:24,  7.11s/it][A
     17%|█▋        | 90/540 [09:51<54:37,  7.28s/it][A
     17%|█▋        | 91/540 [10:00<57:49,  7.73s/it][A
     17%|█▋        | 92/540 [10:08<59:20,  7.95s/it][A
     17%|█▋        | 93/540 [10:15<57:39,  7.74s/it][A
     17%|█▋        | 94/540 [10:24<58:33,  7.88s/it][A
     18%|█▊        | 95/540 [10:31<57:10,  7.71s/it][A
     18%|█▊        | 96/540 [10:39<57:26,  7.76s/it][A
     18%|█▊        | 97/540 [10:46<56:02,  7.59s/it][A
     18%|█▊        | 98/540 [10:53<55:35,  7.55s/it][A
     18%|█▊        | 99/540 [11:01<55:18,  7.53s/it][A
     19%|█▊        | 100/540 [11:07<52:38,  7.18s/it][A
     19%|█▊        | 101/540 [11:15<53:50,  7.36s/it][A
     19%|█▉        | 102/540 [11:22<52:30,  7.19s/it][A
     19%|█▉        | 103/540 [11:31<55:53,  7.67s/it][A
     19%|█▉        | 104/540 [11:39<57:38,  7.93s/it][A
     19%|█▉        | 105/540 [11:46<55:04,  7.60s/it][A
     20%|█▉        | 106/540 [11:53<53:15,  7.36s/it][A
     20%|█▉        | 107/540 [12:00<53:33,  7.42s/it][A
     20%|██        | 108/540 [12:07<52:18,  7.26s/it][A
     20%|██        | 109/540 [12:14<50:50,  7.08s/it][A
     20%|██        | 110/540 [12:23<54:20,  7.58s/it][A
     21%|██        | 111/540 [12:31<56:06,  7.85s/it][A
     21%|██        | 112/540 [12:40<57:54,  8.12s/it][A
     21%|██        | 113/540 [12:48<58:11,  8.18s/it][A
     21%|██        | 114/540 [12:55<56:05,  7.90s/it][A
     21%|██▏       | 115/540 [13:02<52:12,  7.37s/it][A
     21%|██▏       | 116/540 [13:08<50:58,  7.21s/it][A
     22%|██▏       | 117/540 [13:16<51:30,  7.31s/it][A
     22%|██▏       | 118/540 [13:23<50:52,  7.23s/it][A
     22%|██▏       | 119/540 [13:31<52:22,  7.46s/it][A
     22%|██▏       | 120/540 [13:38<52:13,  7.46s/it][A
     22%|██▏       | 121/540 [13:46<53:09,  7.61s/it][A
     23%|██▎       | 122/540 [13:54<52:03,  7.47s/it][A
     23%|██▎       | 123/540 [14:02<53:08,  7.65s/it][A
     23%|██▎       | 124/540 [14:09<52:15,  7.54s/it][A
     23%|██▎       | 125/540 [14:16<51:03,  7.38s/it][A
     23%|██▎       | 126/540 [14:24<51:24,  7.45s/it][A
     24%|██▎       | 127/540 [14:30<50:14,  7.30s/it][A
     24%|██▎       | 128/540 [14:37<48:10,  7.02s/it][A
     24%|██▍       | 129/540 [14:44<48:25,  7.07s/it][A
     24%|██▍       | 130/540 [14:54<53:32,  7.84s/it][A
     24%|██▍       | 131/540 [15:04<59:26,  8.72s/it][A
     24%|██▍       | 132/540 [15:13<59:05,  8.69s/it][A
     25%|██▍       | 133/540 [15:21<56:57,  8.40s/it][A
     25%|██▍       | 134/540 [15:28<54:10,  8.01s/it][A
     25%|██▌       | 135/540 [15:36<53:28,  7.92s/it][A
     25%|██▌       | 136/540 [15:44<54:44,  8.13s/it][A
     25%|██▌       | 137/540 [15:52<53:34,  7.98s/it][A
     26%|██▌       | 138/540 [15:59<51:13,  7.65s/it][A
     26%|██▌       | 139/540 [16:06<50:41,  7.58s/it][A
     26%|██▌       | 140/540 [16:15<53:26,  8.02s/it][A
     26%|██▌       | 141/540 [16:23<52:33,  7.90s/it][A
     26%|██▋       | 142/540 [16:30<50:14,  7.57s/it][A
     26%|██▋       | 143/540 [16:38<50:46,  7.67s/it][A
     27%|██▋       | 144/540 [16:44<48:35,  7.36s/it][A
     27%|██▋       | 145/540 [16:51<48:16,  7.33s/it][A
     27%|██▋       | 146/540 [17:01<52:01,  7.92s/it][A
     27%|██▋       | 147/540 [17:08<51:19,  7.84s/it][A
     27%|██▋       | 148/540 [17:16<51:02,  7.81s/it][A
     28%|██▊       | 149/540 [17:23<49:50,  7.65s/it][A
     28%|██▊       | 150/540 [17:31<48:50,  7.51s/it][A
     28%|██▊       | 151/540 [17:40<52:41,  8.13s/it][A
     28%|██▊       | 152/540 [17:50<55:30,  8.58s/it][A
     28%|██▊       | 153/540 [17:59<57:28,  8.91s/it][A
     29%|██▊       | 154/540 [18:07<55:16,  8.59s/it][A
     29%|██▊       | 155/540 [18:14<51:07,  7.97s/it][A
     29%|██▉       | 156/540 [18:21<49:38,  7.76s/it][A
     29%|██▉       | 157/540 [18:28<48:16,  7.56s/it][A
     29%|██▉       | 158/540 [18:35<47:22,  7.44s/it][A
     29%|██▉       | 159/540 [18:42<46:19,  7.30s/it][A
     30%|██▉       | 160/540 [18:50<46:47,  7.39s/it][A
     30%|██▉       | 161/540 [18:59<50:47,  8.04s/it][A
     30%|███       | 162/540 [19:07<50:05,  7.95s/it][A
     30%|███       | 163/540 [19:16<51:03,  8.13s/it][A
     30%|███       | 164/540 [19:23<49:12,  7.85s/it][A
     31%|███       | 165/540 [19:32<50:55,  8.15s/it][A
     31%|███       | 166/540 [19:40<50:48,  8.15s/it][A
     31%|███       | 167/540 [19:48<50:47,  8.17s/it][A
     31%|███       | 168/540 [19:56<49:36,  8.00s/it][A
     31%|███▏      | 169/540 [20:04<49:47,  8.05s/it][A
     31%|███▏      | 170/540 [20:13<50:52,  8.25s/it][A
     32%|███▏      | 171/540 [20:21<50:59,  8.29s/it][A
     32%|███▏      | 172/540 [20:28<48:29,  7.91s/it][A
     32%|███▏      | 173/540 [20:36<49:18,  8.06s/it][A
     32%|███▏      | 174/540 [20:44<48:18,  7.92s/it][A
     32%|███▏      | 175/540 [20:51<46:07,  7.58s/it][A
     33%|███▎      | 176/540 [20:58<45:53,  7.56s/it][A
     33%|███▎      | 177/540 [21:05<44:56,  7.43s/it][A
     33%|███▎      | 178/540 [21:12<43:58,  7.29s/it][A
     33%|███▎      | 179/540 [21:20<43:26,  7.22s/it][A
     33%|███▎      | 180/540 [21:28<45:55,  7.66s/it][A
     34%|███▎      | 181/540 [21:38<48:52,  8.17s/it][A
     34%|███▎      | 182/540 [21:46<48:57,  8.20s/it][A
     34%|███▍      | 183/540 [21:55<49:52,  8.38s/it][A
     34%|███▍      | 184/540 [22:02<48:46,  8.22s/it][A
     34%|███▍      | 185/540 [22:11<48:24,  8.18s/it][A
     34%|███▍      | 186/540 [22:19<49:10,  8.34s/it][A
     35%|███▍      | 187/540 [22:27<48:20,  8.22s/it][A
     35%|███▍      | 188/540 [22:36<48:51,  8.33s/it][A
     35%|███▌      | 189/540 [22:44<48:10,  8.23s/it][A
     35%|███▌      | 190/540 [22:55<52:26,  8.99s/it][A
     35%|███▌      | 191/540 [23:04<53:54,  9.27s/it][A
     36%|███▌      | 192/540 [23:12<50:48,  8.76s/it][A
     36%|███▌      | 193/540 [23:21<51:06,  8.84s/it][A
     36%|███▌      | 194/540 [23:29<48:36,  8.43s/it][A
     36%|███▌      | 195/540 [23:37<48:18,  8.40s/it][A
     36%|███▋      | 196/540 [23:46<49:09,  8.57s/it][A
     36%|███▋      | 197/540 [23:56<51:14,  8.96s/it][A
     37%|███▋      | 198/540 [24:05<52:18,  9.18s/it][A
     37%|███▋      | 199/540 [24:13<50:17,  8.85s/it][A
     37%|███▋      | 200/540 [24:22<50:14,  8.87s/it][A
     37%|███▋      | 201/540 [24:31<49:04,  8.69s/it][A
     37%|███▋      | 202/540 [24:38<47:17,  8.39s/it][A
     38%|███▊      | 203/540 [24:46<46:03,  8.20s/it][A
     38%|███▊      | 204/540 [24:53<43:48,  7.82s/it][A
     38%|███▊      | 205/540 [25:01<43:54,  7.87s/it][A
     38%|███▊      | 206/540 [25:11<47:48,  8.59s/it][A
     38%|███▊      | 207/540 [25:19<46:25,  8.36s/it][A
     39%|███▊      | 208/540 [25:27<45:52,  8.29s/it][A
     39%|███▊      | 209/540 [25:35<44:11,  8.01s/it][A
     39%|███▉      | 210/540 [25:42<43:10,  7.85s/it][A
     39%|███▉      | 211/540 [25:52<46:05,  8.41s/it][A
     39%|███▉      | 212/540 [26:01<47:06,  8.62s/it][A
     39%|███▉      | 213/540 [26:13<52:46,  9.68s/it][A
     40%|███▉      | 214/540 [26:23<53:47,  9.90s/it][A
     40%|███▉      | 215/540 [26:34<55:17, 10.21s/it][A
     40%|████      | 216/540 [26:46<57:39, 10.68s/it][A
     40%|████      | 217/540 [26:56<55:49, 10.37s/it][A
     40%|████      | 218/540 [27:05<53:37,  9.99s/it][A
     41%|████      | 219/540 [27:15<52:54,  9.89s/it][A
     41%|████      | 220/540 [27:26<54:23, 10.20s/it][A
     41%|████      | 221/540 [27:36<54:28, 10.25s/it][A
     41%|████      | 222/540 [27:47<55:25, 10.46s/it][A
     41%|████▏     | 223/540 [27:59<58:24, 11.05s/it][A
     41%|████▏     | 224/540 [28:08<54:04, 10.27s/it][A
     42%|████▏     | 225/540 [28:16<51:22,  9.78s/it][A
     42%|████▏     | 226/540 [28:29<54:55, 10.49s/it][A
     42%|████▏     | 227/540 [28:41<57:18, 10.98s/it][A
     42%|████▏     | 228/540 [28:51<55:53, 10.75s/it][A
     42%|████▏     | 229/540 [29:01<54:15, 10.47s/it][A
     43%|████▎     | 230/540 [29:12<55:00, 10.65s/it][A
     43%|████▎     | 231/540 [29:21<53:27, 10.38s/it][A
     43%|████▎     | 232/540 [29:32<53:34, 10.44s/it][A
     43%|████▎     | 233/540 [29:43<53:56, 10.54s/it][A
     43%|████▎     | 234/540 [29:51<50:26,  9.89s/it][A
     44%|████▎     | 235/540 [30:04<54:16, 10.68s/it][A
     44%|████▎     | 236/540 [30:15<54:20, 10.73s/it][A
     44%|████▍     | 237/540 [30:24<52:50, 10.47s/it][A
     44%|████▍     | 238/540 [30:34<51:34, 10.25s/it][A
     44%|████▍     | 239/540 [30:44<51:03, 10.18s/it][A
     44%|████▍     | 240/540 [30:53<49:38,  9.93s/it][A
     45%|████▍     | 241/540 [31:08<55:43, 11.18s/it][A
     45%|████▍     | 242/540 [31:21<58:15, 11.73s/it][A
     45%|████▌     | 243/540 [31:33<59:03, 11.93s/it][A
     45%|████▌     | 244/540 [31:48<1:03:38, 12.90s/it][A
     45%|████▌     | 245/540 [32:02<1:04:58, 13.21s/it][A
     46%|████▌     | 246/540 [32:17<1:07:35, 13.79s/it][A
     46%|████▌     | 247/540 [32:30<1:06:13, 13.56s/it][A
     46%|████▌     | 248/540 [32:44<1:06:08, 13.59s/it][A
     46%|████▌     | 249/540 [32:59<1:07:52, 14.00s/it][A
     46%|████▋     | 250/540 [33:12<1:06:44, 13.81s/it][A
     46%|████▋     | 251/540 [33:26<1:06:10, 13.74s/it][A
     47%|████▋     | 252/540 [33:39<1:05:32, 13.66s/it][A
     47%|████▋     | 253/540 [33:53<1:05:31, 13.70s/it][A
     47%|████▋     | 254/540 [34:07<1:05:06, 13.66s/it][A
     47%|████▋     | 255/540 [34:20<1:04:35, 13.60s/it][A
     47%|████▋     | 256/540 [34:35<1:05:57, 13.93s/it][A
     48%|████▊     | 257/540 [34:49<1:06:06, 14.01s/it][A
     48%|████▊     | 258/540 [35:02<1:03:50, 13.58s/it][A
     48%|████▊     | 259/540 [35:15<1:03:42, 13.60s/it][A
     48%|████▊     | 260/540 [35:28<1:02:08, 13.32s/it][A
     48%|████▊     | 261/540 [35:41<1:01:25, 13.21s/it][A
     49%|████▊     | 262/540 [35:54<1:00:36, 13.08s/it][A
     49%|████▊     | 263/540 [36:07<1:00:51, 13.18s/it][A
     49%|████▉     | 264/540 [36:20<1:00:31, 13.16s/it][A
     49%|████▉     | 265/540 [36:32<58:41, 12.80s/it]  [A
     49%|████▉     | 266/540 [36:46<1:00:16, 13.20s/it][A
     49%|████▉     | 267/540 [36:59<59:29, 13.08s/it]  [A
     50%|████▉     | 268/540 [37:12<58:55, 13.00s/it][A
     50%|████▉     | 269/540 [37:25<59:05, 13.08s/it][A
     50%|█████     | 270/540 [37:36<55:41, 12.38s/it][A
     50%|█████     | 271/540 [37:44<49:23, 11.02s/it][A
     50%|█████     | 272/540 [37:51<44:06,  9.87s/it][A
     51%|█████     | 273/540 [37:57<39:19,  8.84s/it][A
     51%|█████     | 274/540 [38:05<37:54,  8.55s/it][A
     51%|█████     | 275/540 [38:12<35:27,  8.03s/it][A
     51%|█████     | 276/540 [38:19<33:26,  7.60s/it][A
     51%|█████▏    | 277/540 [38:25<32:00,  7.30s/it][A
     51%|█████▏    | 278/540 [38:32<31:28,  7.21s/it][A
     52%|█████▏    | 279/540 [38:39<30:25,  6.99s/it][A
     52%|█████▏    | 280/540 [38:46<30:08,  6.95s/it][A
     52%|█████▏    | 281/540 [38:53<30:05,  6.97s/it][A
     52%|█████▏    | 282/540 [38:59<29:41,  6.91s/it][A
     52%|█████▏    | 283/540 [39:06<29:51,  6.97s/it][A
     53%|█████▎    | 284/540 [39:13<29:47,  6.98s/it][A
     53%|█████▎    | 285/540 [39:20<29:36,  6.97s/it][A
     53%|█████▎    | 286/540 [39:28<30:33,  7.22s/it][A
     53%|█████▎    | 287/540 [39:36<30:57,  7.34s/it][A
     53%|█████▎    | 288/540 [39:44<31:40,  7.54s/it][A
     54%|█████▎    | 289/540 [39:52<32:25,  7.75s/it][A
     54%|█████▎    | 290/540 [40:00<33:02,  7.93s/it][A
     54%|█████▍    | 291/540 [40:08<32:06,  7.74s/it][A
     54%|█████▍    | 292/540 [40:15<30:54,  7.48s/it][A
     54%|█████▍    | 293/540 [40:22<31:08,  7.56s/it][A
     54%|█████▍    | 294/540 [40:30<30:35,  7.46s/it][A
     55%|█████▍    | 295/540 [40:37<30:18,  7.42s/it][A
     55%|█████▍    | 296/540 [40:46<31:46,  7.81s/it][A
     55%|█████▌    | 297/540 [40:56<34:25,  8.50s/it][A
     55%|█████▌    | 298/540 [41:03<32:47,  8.13s/it][A
     55%|█████▌    | 299/540 [41:11<32:33,  8.11s/it][A
     56%|█████▌    | 300/540 [41:18<31:07,  7.78s/it][A
     56%|█████▌    | 301/540 [41:27<31:46,  7.98s/it][A
     56%|█████▌    | 302/540 [41:34<30:29,  7.69s/it][A
     56%|█████▌    | 303/540 [41:43<31:53,  8.08s/it][A
     56%|█████▋    | 304/540 [41:50<31:37,  8.04s/it][A
     56%|█████▋    | 305/540 [41:58<30:30,  7.79s/it][A
     57%|█████▋    | 306/540 [42:06<30:54,  7.92s/it][A
     57%|█████▋    | 307/540 [42:13<29:51,  7.69s/it][A
     57%|█████▋    | 308/540 [42:23<32:06,  8.30s/it][A
     57%|█████▋    | 309/540 [42:31<31:52,  8.28s/it][A
     57%|█████▋    | 310/540 [42:42<34:28,  8.99s/it][A
     58%|█████▊    | 311/540 [42:49<32:25,  8.50s/it][A
     58%|█████▊    | 312/540 [42:57<31:32,  8.30s/it][A
     58%|█████▊    | 313/540 [43:07<33:55,  8.97s/it][A
     58%|█████▊    | 314/540 [43:18<35:49,  9.51s/it][A
     58%|█████▊    | 315/540 [43:30<38:11, 10.19s/it][A
     59%|█████▊    | 316/540 [43:38<35:13,  9.44s/it][A
     59%|█████▊    | 317/540 [43:46<34:03,  9.17s/it][A
     59%|█████▉    | 318/540 [43:54<32:30,  8.79s/it][A
     59%|█████▉    | 319/540 [44:02<31:32,  8.56s/it][A
     59%|█████▉    | 320/540 [44:09<29:57,  8.17s/it][A
     59%|█████▉    | 321/540 [44:17<29:06,  7.97s/it][A
     60%|█████▉    | 322/540 [44:24<28:05,  7.73s/it][A
     60%|█████▉    | 323/540 [44:34<30:10,  8.34s/it][A
     60%|██████    | 324/540 [44:43<30:45,  8.54s/it][A
     60%|██████    | 325/540 [44:50<28:43,  8.01s/it][A
     60%|██████    | 326/540 [44:57<28:14,  7.92s/it][A
     61%|██████    | 327/540 [45:07<30:11,  8.50s/it][A
     61%|██████    | 328/540 [45:15<29:24,  8.32s/it][A
     61%|██████    | 329/540 [45:23<29:20,  8.34s/it][A
     61%|██████    | 330/540 [45:31<28:42,  8.20s/it][A
     61%|██████▏   | 331/540 [45:39<27:56,  8.02s/it][A
     61%|██████▏   | 332/540 [45:48<28:37,  8.26s/it][A
     62%|██████▏   | 333/540 [45:55<27:36,  8.00s/it][A
     62%|██████▏   | 334/540 [46:04<28:05,  8.18s/it][A
     62%|██████▏   | 335/540 [46:13<28:56,  8.47s/it][A
     62%|██████▏   | 336/540 [46:21<28:17,  8.32s/it][A
     62%|██████▏   | 337/540 [46:28<27:26,  8.11s/it][A
     63%|██████▎   | 338/540 [46:36<26:43,  7.94s/it][A
     63%|██████▎   | 339/540 [46:44<26:35,  7.94s/it][A
     63%|██████▎   | 340/540 [46:54<28:27,  8.54s/it][A
     63%|██████▎   | 341/540 [47:01<26:59,  8.14s/it][A
     63%|██████▎   | 342/540 [47:08<25:51,  7.83s/it][A
     64%|██████▎   | 343/540 [47:17<26:35,  8.10s/it][A
     64%|██████▎   | 344/540 [47:26<27:06,  8.30s/it][A
     64%|██████▍   | 345/540 [47:34<26:32,  8.16s/it][A
     64%|██████▍   | 346/540 [47:41<25:55,  8.02s/it][A
     64%|██████▍   | 347/540 [47:50<26:48,  8.33s/it][A
     64%|██████▍   | 348/540 [47:59<26:45,  8.36s/it][A
     65%|██████▍   | 349/540 [48:07<26:21,  8.28s/it][A
     65%|██████▍   | 350/540 [48:15<26:35,  8.40s/it][A
     65%|██████▌   | 351/540 [48:24<26:11,  8.32s/it][A
     65%|██████▌   | 352/540 [48:30<24:41,  7.88s/it][A
     65%|██████▌   | 353/540 [48:38<24:09,  7.75s/it][A
     66%|██████▌   | 354/540 [48:47<24:55,  8.04s/it][A
     66%|██████▌   | 355/540 [48:54<24:36,  7.98s/it][A
     66%|██████▌   | 356/540 [49:02<24:19,  7.93s/it][A
     66%|██████▌   | 357/540 [49:10<24:04,  7.89s/it][A
     66%|██████▋   | 358/540 [49:17<23:24,  7.72s/it][A
     66%|██████▋   | 359/540 [49:24<22:38,  7.51s/it][A
     67%|██████▋   | 360/540 [49:32<22:52,  7.63s/it][A
     67%|██████▋   | 361/540 [49:42<24:35,  8.24s/it][A
     67%|██████▋   | 362/540 [49:51<24:44,  8.34s/it][A
     67%|██████▋   | 363/540 [49:58<24:11,  8.20s/it][A
     67%|██████▋   | 364/540 [50:06<23:38,  8.06s/it][A
     68%|██████▊   | 365/540 [50:17<26:09,  8.97s/it][A
     68%|██████▊   | 366/540 [50:26<25:56,  8.94s/it][A
     68%|██████▊   | 367/540 [50:34<25:13,  8.75s/it][A
     68%|██████▊   | 368/540 [50:44<25:36,  8.93s/it][A
     68%|██████▊   | 369/540 [50:51<24:20,  8.54s/it][A
     69%|██████▊   | 370/540 [51:01<25:06,  8.86s/it][A
     69%|██████▊   | 371/540 [51:10<24:48,  8.81s/it][A
     69%|██████▉   | 372/540 [51:18<23:59,  8.57s/it][A
     69%|██████▉   | 373/540 [51:26<23:35,  8.47s/it][A
     69%|██████▉   | 374/540 [51:34<23:24,  8.46s/it][A
     69%|██████▉   | 375/540 [51:42<22:52,  8.32s/it][A
     70%|██████▉   | 376/540 [51:50<22:32,  8.25s/it][A
     70%|██████▉   | 377/540 [51:59<22:23,  8.24s/it][A
     70%|███████   | 378/540 [52:07<21:53,  8.11s/it][A
     70%|███████   | 379/540 [52:15<21:58,  8.19s/it][A
     70%|███████   | 380/540 [52:24<22:21,  8.39s/it][A
     71%|███████   | 381/540 [52:32<22:17,  8.41s/it][A
     71%|███████   | 382/540 [52:40<21:24,  8.13s/it][A
     71%|███████   | 383/540 [52:48<21:20,  8.16s/it][A
     71%|███████   | 384/540 [52:56<21:19,  8.20s/it][A
     71%|███████▏  | 385/540 [53:04<20:38,  7.99s/it][A
     71%|███████▏  | 386/540 [53:13<21:15,  8.28s/it][A
     72%|███████▏  | 387/540 [53:21<21:27,  8.42s/it][A
     72%|███████▏  | 388/540 [53:29<21:00,  8.30s/it][A
     72%|███████▏  | 389/540 [53:39<21:42,  8.63s/it][A
     72%|███████▏  | 390/540 [53:48<21:40,  8.67s/it][A
     72%|███████▏  | 391/540 [53:56<21:37,  8.71s/it][A
     73%|███████▎  | 392/540 [54:05<21:23,  8.67s/it][A
     73%|███████▎  | 393/540 [54:14<21:24,  8.74s/it][A
     73%|███████▎  | 394/540 [54:22<20:53,  8.59s/it][A
     73%|███████▎  | 395/540 [54:32<21:30,  8.90s/it][A
     73%|███████▎  | 396/540 [54:39<20:26,  8.52s/it][A
     74%|███████▎  | 397/540 [54:48<20:31,  8.61s/it][A
     74%|███████▎  | 398/540 [54:57<20:29,  8.66s/it][A
     74%|███████▍  | 399/540 [55:07<21:00,  8.94s/it][A
     74%|███████▍  | 400/540 [55:17<21:51,  9.37s/it][A
     74%|███████▍  | 401/540 [55:26<21:13,  9.16s/it][A
     74%|███████▍  | 402/540 [55:35<21:28,  9.34s/it][A
     75%|███████▍  | 403/540 [55:43<20:16,  8.88s/it][A
     75%|███████▍  | 404/540 [55:51<19:43,  8.70s/it][A
     75%|███████▌  | 405/540 [56:00<19:46,  8.79s/it][A
     75%|███████▌  | 406/540 [56:11<20:47,  9.31s/it][A
     75%|███████▌  | 407/540 [56:19<19:40,  8.87s/it][A
     76%|███████▌  | 408/540 [56:28<20:03,  9.12s/it][A
     76%|███████▌  | 409/540 [56:37<19:16,  8.83s/it][A
     76%|███████▌  | 410/540 [56:46<19:44,  9.11s/it][A
     76%|███████▌  | 411/540 [56:57<20:15,  9.42s/it][A
     76%|███████▋  | 412/540 [57:06<20:02,  9.39s/it][A
     76%|███████▋  | 413/540 [57:13<18:38,  8.81s/it][A
     77%|███████▋  | 414/540 [57:22<18:15,  8.69s/it][A
     77%|███████▋  | 415/540 [57:31<18:13,  8.75s/it][A
     77%|███████▋  | 416/540 [57:40<18:12,  8.81s/it][A
     77%|███████▋  | 417/540 [57:49<18:07,  8.84s/it][A
     77%|███████▋  | 418/540 [57:57<17:45,  8.73s/it][A
     78%|███████▊  | 419/540 [58:05<17:10,  8.52s/it][A
     78%|███████▊  | 420/540 [58:13<16:29,  8.25s/it][A
     78%|███████▊  | 421/540 [58:23<17:28,  8.81s/it][A
     78%|███████▊  | 422/540 [58:31<17:08,  8.72s/it][A
     78%|███████▊  | 423/540 [58:39<16:28,  8.45s/it][A
     79%|███████▊  | 424/540 [58:50<17:33,  9.08s/it][A
     79%|███████▊  | 425/540 [58:59<17:34,  9.17s/it][A
     79%|███████▉  | 426/540 [59:08<17:27,  9.19s/it][A
     79%|███████▉  | 427/540 [59:17<17:15,  9.16s/it][A
     79%|███████▉  | 428/540 [59:25<16:10,  8.67s/it][A
     79%|███████▉  | 429/540 [59:33<15:38,  8.46s/it][A
     80%|███████▉  | 430/540 [59:43<16:18,  8.89s/it][A
     80%|███████▉  | 431/540 [59:52<16:29,  9.07s/it][A
     80%|████████  | 432/540 [1:00:02<16:41,  9.27s/it][A
     80%|████████  | 433/540 [1:00:10<15:45,  8.84s/it][A
     80%|████████  | 434/540 [1:00:19<15:57,  9.03s/it][A
     81%|████████  | 435/540 [1:00:28<15:23,  8.79s/it][A
     81%|████████  | 436/540 [1:00:37<15:46,  9.10s/it][A
     81%|████████  | 437/540 [1:00:46<15:25,  8.98s/it][A
     81%|████████  | 438/540 [1:00:57<16:06,  9.48s/it][A
     81%|████████▏ | 439/540 [1:01:05<15:24,  9.15s/it][A
     81%|████████▏ | 440/540 [1:01:14<15:12,  9.13s/it][A
     82%|████████▏ | 441/540 [1:01:23<15:02,  9.12s/it][A
     82%|████████▏ | 442/540 [1:01:32<14:30,  8.88s/it][A
     82%|████████▏ | 443/540 [1:01:39<13:49,  8.55s/it][A
     82%|████████▏ | 444/540 [1:01:49<14:18,  8.94s/it][A
     82%|████████▏ | 445/540 [1:01:59<14:34,  9.21s/it][A
     83%|████████▎ | 446/540 [1:02:07<13:54,  8.88s/it][A
     83%|████████▎ | 447/540 [1:02:15<13:22,  8.63s/it][A
     83%|████████▎ | 448/540 [1:02:24<13:28,  8.78s/it][A
     83%|████████▎ | 449/540 [1:02:35<14:16,  9.41s/it][A
     83%|████████▎ | 450/540 [1:02:44<13:53,  9.27s/it][A
     84%|████████▎ | 451/540 [1:02:55<14:21,  9.68s/it][A
     84%|████████▎ | 452/540 [1:03:04<13:56,  9.51s/it][A
     84%|████████▍ | 453/540 [1:03:13<13:29,  9.31s/it][A
     84%|████████▍ | 454/540 [1:03:22<13:22,  9.34s/it][A
     84%|████████▍ | 455/540 [1:03:30<12:48,  9.04s/it][A
     84%|████████▍ | 456/540 [1:03:40<12:49,  9.16s/it][A
     85%|████████▍ | 457/540 [1:03:50<13:05,  9.47s/it][A
     85%|████████▍ | 458/540 [1:03:59<12:48,  9.38s/it][A
     85%|████████▌ | 459/540 [1:04:09<12:38,  9.36s/it][A
     85%|████████▌ | 460/540 [1:04:17<12:02,  9.03s/it][A
     85%|████████▌ | 461/540 [1:04:26<11:46,  8.94s/it][A
     86%|████████▌ | 462/540 [1:04:34<11:32,  8.88s/it][A
     86%|████████▌ | 463/540 [1:04:45<11:57,  9.32s/it][A
     86%|████████▌ | 464/540 [1:04:52<11:11,  8.83s/it][A
     86%|████████▌ | 465/540 [1:05:01<11:07,  8.90s/it][A
     86%|████████▋ | 466/540 [1:05:11<11:22,  9.22s/it][A
     86%|████████▋ | 467/540 [1:05:20<11:00,  9.04s/it][A
     87%|████████▋ | 468/540 [1:05:29<10:40,  8.89s/it][A
     87%|████████▋ | 469/540 [1:05:37<10:12,  8.62s/it][A
     87%|████████▋ | 470/540 [1:05:44<09:48,  8.41s/it][A
     87%|████████▋ | 471/540 [1:05:53<09:43,  8.46s/it][A
     87%|████████▋ | 472/540 [1:06:01<09:21,  8.26s/it][A
     88%|████████▊ | 473/540 [1:06:10<09:23,  8.41s/it][A
     88%|████████▊ | 474/540 [1:06:18<09:14,  8.40s/it][A
     88%|████████▊ | 475/540 [1:06:26<08:52,  8.20s/it][A
     88%|████████▊ | 476/540 [1:06:34<08:46,  8.22s/it][A
     88%|████████▊ | 477/540 [1:06:42<08:27,  8.05s/it][A
     89%|████████▊ | 478/540 [1:06:50<08:26,  8.17s/it][A
     89%|████████▊ | 479/540 [1:06:58<08:12,  8.07s/it][A
     89%|████████▉ | 480/540 [1:07:06<08:10,  8.17s/it][A
     89%|████████▉ | 481/540 [1:07:19<09:14,  9.40s/it][A
     89%|████████▉ | 482/540 [1:07:30<09:40, 10.01s/it][A
     89%|████████▉ | 483/540 [1:07:42<09:59, 10.51s/it][A
     90%|████████▉ | 484/540 [1:07:53<10:00, 10.72s/it][A
     90%|████████▉ | 485/540 [1:08:04<09:54, 10.81s/it][A
     90%|█████████ | 486/540 [1:08:16<10:00, 11.12s/it][A
     90%|█████████ | 487/540 [1:08:27<09:52, 11.19s/it][A
     90%|█████████ | 488/540 [1:08:39<09:54, 11.42s/it][A
     91%|█████████ | 489/540 [1:08:51<09:57, 11.72s/it][A
     91%|█████████ | 490/540 [1:09:05<10:08, 12.16s/it][A
     91%|█████████ | 491/540 [1:09:19<10:27, 12.81s/it][A
     91%|█████████ | 492/540 [1:09:35<11:03, 13.82s/it][A
     91%|█████████▏| 493/540 [1:09:49<10:55, 13.95s/it][A
     91%|█████████▏| 494/540 [1:10:01<10:09, 13.26s/it][A
     92%|█████████▏| 495/540 [1:10:12<09:26, 12.58s/it][A
     92%|█████████▏| 496/540 [1:10:24<09:10, 12.51s/it][A
     92%|█████████▏| 497/540 [1:10:36<08:45, 12.23s/it][A
     92%|█████████▏| 498/540 [1:10:47<08:23, 11.99s/it][A
     92%|█████████▏| 499/540 [1:10:59<08:09, 11.95s/it][A
     93%|█████████▎| 500/540 [1:11:11<07:53, 11.84s/it][A
     93%|█████████▎| 501/540 [1:11:22<07:34, 11.65s/it][A
     93%|█████████▎| 502/540 [1:11:33<07:12, 11.37s/it][A
     93%|█████████▎| 503/540 [1:11:44<06:58, 11.32s/it][A
     93%|█████████▎| 504/540 [1:11:56<06:49, 11.39s/it][A
     94%|█████████▎| 505/540 [1:12:07<06:34, 11.27s/it][A
     94%|█████████▎| 506/540 [1:12:18<06:24, 11.32s/it][A
     94%|█████████▍| 507/540 [1:12:29<06:09, 11.20s/it][A
     94%|█████████▍| 508/540 [1:12:40<05:58, 11.21s/it][A
     94%|█████████▍| 509/540 [1:12:52<05:50, 11.31s/it][A
     94%|█████████▍| 510/540 [1:13:03<05:37, 11.24s/it][A
     95%|█████████▍| 511/540 [1:13:19<06:13, 12.89s/it][A
     95%|█████████▍| 512/540 [1:13:37<06:40, 14.32s/it][A
     95%|█████████▌| 513/540 [1:13:50<06:14, 13.88s/it][A
     95%|█████████▌| 514/540 [1:14:07<06:22, 14.71s/it][A
     95%|█████████▌| 515/540 [1:14:24<06:27, 15.50s/it][A
     96%|█████████▌| 516/540 [1:14:41<06:24, 16.03s/it][A
     96%|█████████▌| 517/540 [1:14:59<06:17, 16.40s/it][A
     96%|█████████▌| 518/540 [1:15:16<06:06, 16.65s/it][A
     96%|█████████▌| 519/540 [1:15:30<05:32, 15.82s/it][A
     96%|█████████▋| 520/540 [1:15:43<05:04, 15.22s/it][A
     96%|█████████▋| 521/540 [1:15:58<04:43, 14.95s/it][A
     97%|█████████▋| 522/540 [1:16:12<04:23, 14.63s/it][A
     97%|█████████▋| 523/540 [1:16:28<04:16, 15.07s/it][A
     97%|█████████▋| 524/540 [1:16:45<04:10, 15.66s/it][A
     97%|█████████▋| 525/540 [1:17:01<03:58, 15.90s/it][A
     97%|█████████▋| 526/540 [1:17:18<03:45, 16.10s/it][A
     98%|█████████▊| 527/540 [1:17:35<03:32, 16.36s/it][A
     98%|█████████▊| 528/540 [1:17:50<03:12, 16.01s/it][A
     98%|█████████▊| 529/540 [1:18:06<02:55, 15.98s/it][A
     98%|█████████▊| 530/540 [1:18:23<02:43, 16.31s/it][A
     98%|█████████▊| 531/540 [1:18:41<02:31, 16.85s/it][A
     99%|█████████▊| 532/540 [1:18:57<02:12, 16.51s/it][A
     99%|█████████▊| 533/540 [1:19:12<01:53, 16.22s/it][A
     99%|█████████▉| 534/540 [1:19:26<01:32, 15.47s/it][A
     99%|█████████▉| 535/540 [1:19:39<01:14, 14.82s/it][A
     99%|█████████▉| 536/540 [1:19:55<01:00, 15.21s/it][A
     99%|█████████▉| 537/540 [1:20:12<00:46, 15.63s/it][A
    100%|█████████▉| 538/540 [1:20:25<00:29, 14.91s/it][A
    100%|█████████▉| 539/540 [1:20:41<00:15, 15.03s/it][A
    100%|██████████| 540/540 [1:20:57<00:00,  9.00s/it][A


Final model


```python
num_topics = 8

lda_model = gensim.models.LdaMulticore(corpus=corpus,
                                           id2word=id2word,
                                           num_topics=num_topics, 
                                           random_state=100,
                                           chunksize=100,
                                           passes=10,
                                           alpha=0.01,
                                           eta=0.9)
```


```python
!pip install pyLDAvis
```

    Defaulting to user installation because normal site-packages is not writeable
    Collecting pyLDAvis
      Downloading pyLDAvis-3.3.1.tar.gz (1.7 MB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m1.7/1.7 MB[0m [31m23.6 MB/s[0m eta [36m0:00:00[0m00:01[0m0:01[0m
    [?25h  Installing build dependencies ... [?25ldone
    [?25h  Getting requirements to build wheel ... [?25ldone
    [?25h  Installing backend dependencies ... [?25ldone
    [?25h  Preparing metadata (pyproject.toml) ... [?25ldone
    [?25hRequirement already satisfied: gensim in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (4.2.0)
    Collecting sklearn
      Downloading sklearn-0.0.post1.tar.gz (3.6 kB)
      Preparing metadata (setup.py) ... [?25ldone
    [?25hRequirement already satisfied: numpy>=1.20.0 in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (1.23.3)
    Requirement already satisfied: jinja2 in /usr/local/lib/python3.9/site-packages (from pyLDAvis) (3.1.2)
    Requirement already satisfied: pandas>=1.2.0 in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (1.4.4)
    Requirement already satisfied: setuptools in /usr/lib/python3.9/site-packages (from pyLDAvis) (50.3.2)
    Collecting future
      Downloading future-0.18.3.tar.gz (840 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m840.9/840.9 kB[0m [31m124.5 MB/s[0m eta [36m0:00:00[0m
    [?25h  Preparing metadata (setup.py) ... [?25ldone
    [?25hRequirement already satisfied: scipy in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (1.9.1)
    Collecting numexpr
      Downloading numexpr-2.8.4-cp39-cp39-manylinux_2_17_x86_64.manylinux2014_x86_64.whl (380 kB)
    [2K     [90m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m [32m380.7/380.7 kB[0m [31m103.4 MB/s[0m eta [36m0:00:00[0m
    [?25hRequirement already satisfied: scikit-learn in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (1.1.2)
    Requirement already satisfied: joblib in /home/hari/.local/lib/python3.9/site-packages (from pyLDAvis) (1.2.0)
    Collecting funcy
      Downloading funcy-1.17-py2.py3-none-any.whl (33 kB)
    Requirement already satisfied: python-dateutil>=2.8.1 in /usr/local/lib/python3.9/site-packages (from pandas>=1.2.0->pyLDAvis) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in /usr/local/lib/python3.9/site-packages (from pandas>=1.2.0->pyLDAvis) (2022.2.1)
    Requirement already satisfied: smart-open>=1.8.1 in /home/hari/.local/lib/python3.9/site-packages (from gensim->pyLDAvis) (5.2.1)
    Requirement already satisfied: MarkupSafe>=2.0 in /usr/local/lib64/python3.9/site-packages (from jinja2->pyLDAvis) (2.1.1)
    Requirement already satisfied: threadpoolctl>=2.0.0 in /home/hari/.local/lib/python3.9/site-packages (from scikit-learn->pyLDAvis) (3.1.0)
    Requirement already satisfied: six>=1.5 in /usr/local/lib/python3.9/site-packages (from python-dateutil>=2.8.1->pandas>=1.2.0->pyLDAvis) (1.16.0)
    Using legacy 'setup.py install' for future, since package 'wheel' is not installed.
    Using legacy 'setup.py install' for sklearn, since package 'wheel' is not installed.
    Building wheels for collected packages: pyLDAvis
      Building wheel for pyLDAvis (pyproject.toml) ... [?25ldone
    [?25h  Created wheel for pyLDAvis: filename=pyLDAvis-3.3.1-py2.py3-none-any.whl size=136882 sha256=4eb23caabd479854ab3ff9d97c7291096c57bb7e8998eef46ef2892b21ce82f0
      Stored in directory: /home/hari/.cache/pip/wheels/57/a4/86/d10c6c2e0bf149fbc0afb0aa5a6528ac35b30a133a0270c477
    Successfully built pyLDAvis
    Installing collected packages: sklearn, funcy, numexpr, future, pyLDAvis
      Running setup.py install for sklearn ... [?25ldone
    [?25h  Running setup.py install for future ... [?25ldone
    [?25hSuccessfully installed funcy-1.17 future-0.18.3 numexpr-2.8.4 pyLDAvis-3.3.1 sklearn-0.0.post1
    
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m A new release of pip available: [0m[31;49m22.2.2[0m[39;49m -> [0m[32;49m22.3.1[0m
    [1m[[0m[34;49mnotice[0m[1;39;49m][0m[39;49m To update, run: [0m[32;49mpython3.9 -m pip install --upgrade pip[0m



```python
import pyLDAvis.gensim_models as gensimvis
import pickle 
import pyLDAvis

# Visualize the topics
pyLDAvis.enable_notebook()

# LDAvis_data_filepath = os.path.join('./results/ldavis_tuned_'+str(num_topics))
LDAvis_data_filepath = os.path.join('ldavis_tuned_'+str(num_topics))

# # this is a bit time consuming - make the if statement True
# # if you want to execute visualization prep yourself
if 1 == 1:
    LDAvis_prepared = gensimvis.prepare(lda_model, corpus, id2word)
    with open(LDAvis_data_filepath, 'wb') as f:
        pickle.dump(LDAvis_prepared, f)

# load the pre-prepared pyLDAvis data from disk
with open(LDAvis_data_filepath, 'rb') as f:
    LDAvis_prepared = pickle.load(f)

pyLDAvis.save_html(LDAvis_prepared, 'ldavis_tuned_'+ str(num_topics) +'.html')

LDAvis_prepared
```

    /home/hari/.local/lib/python3.9/site-packages/pyLDAvis/_prepare.py:246: FutureWarning: In a future version of pandas all arguments of DataFrame.drop except for the argument 'labels' will be keyword-only.
      default_term_info = default_term_info.sort_values(






<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/bmabey/pyLDAvis@3.3.1/pyLDAvis/js/ldavis.v1.0.0.css">


<div id="ldavis_el27545871397211637755529140865402"></div>
<script type="text/javascript">

var ldavis_el27545871397211637755529140865402_data = {"mdsDat": {"x": [0.10379371515603379, 0.09302951066780639, 0.09690225764036825, 0.03747268465858637, -0.05836593005141596, -0.05739067040602884, -0.0765695729979833, -0.13887199466736683], "y": [0.0542856196186888, 0.005705204816259919, -0.10161682384457564, 0.04679655583409367, 0.03430050150810055, -0.011233927960681546, -0.01020891352573977, -0.018028216446145905], "topics": [1, 2, 3, 4, 5, 6, 7, 8], "cluster": [1, 1, 1, 1, 1, 1, 1, 1], "Freq": [34.284386483337045, 25.147133358280705, 18.33357562439156, 13.648992902127544, 3.308360714202315, 3.0260005408570128, 2.2510699444692053, 0.00048043233461289055]}, "tinfo": {"Term": ["cid", "measure", "agent", "paper", "image", "goal", "task", "action", "policy", "reward", "network", "label", "question", "problem", "method", "property", "environment", "model", "assignment", "learn", "classi\ufb01cation", "probability", "class", "bind", "pattern", "performance", "reviewer", "use", "vector", "regret", "meta", "latency", "device", "equivariant", "coagent", "coan", "robot", "topological", "latency_predictor", "robotic", "shoot", "fitness", "eat", "collision", "densepose", "demonstration", "siren", "der", "continual", "mdp_homomorphism", "equivariance", "hardware", "svcca", "replay", "critic", "layer", "nas", "unseen_device", "genetic", "motion_planne", "\ufb01ne_tuning", "forget", "network", "deep", "reinforcement", "representation", "architecture", "task", "path", "learn", "neural", "international_conference", "learning", "gradient", "train", "space", "policy", "training", "baseline", "approach", "model", "use", "figure", "state", "base", "output", "method", "performance", "problem", "image", "system", "show", "sample", "value", "function", "set", "also", "result", "cid", "\u02c6\u03b8kl", "optimistic", "vbo", "reroote", "bandit", "uproot", "compartment", "hinge", "trw", "ncor", "sgld", "bind", "covid", "resilient", "compartmental", "minibatche", "pure_potential", "byzantine_agent", "forecast", "\u02c6\u03b8k", "ppca", "motif", "\u02c6\u03b8li", "byzantine", "regret", "evidence_procedure", "tmdp", "ibound", "forecasting", "dependent_prior", "bootstrap", "covariate", "partition", "bound", "round", "variable", "alignment", "user", "variational", "momentum", "dependent", "minibatch", "stochastic", "optimal", "expect", "let", "set", "potential", "algorithm", "relationship", "guarantee", "datum", "action", "model", "function", "sequence", "cluster", "problem", "method", "number", "case", "use", "result", "time", "cid", "show", "matrix", "give", "follow", "policy", "sample", "base", "learn", "value", "weight", "state", "stem", "reservoir_compute", "stimulus", "spike_train", "suf\ufb01xe", "urnn", "microcircuit", "freerexmomentum", "lmax", "trs_oden", "rnn", "unitary", "critical_point", "chaotic", "hidden_state", "supp", "bmc", "recurrent_kernel", "cid", "crbm", "htp", "minimizer", "postsynaptic", "traveling_pulse", "characteristic_equation", "hoden", "\ufb01ring_rate", "oscillator", "pulse", "panel", "spike", "adaptation", "circuit", "recurrent", "measurement", "solution", "input", "neuron", "hypothesis", "constant", "analysis", "time", "signal", "linear", "system", "sparse", "result", "function", "matrix", "output", "condition", "show", "parameter", "model", "neural", "noise", "error", "set", "non", "case", "use", "number", "value", "network", "problem", "learn", "also", "feature", "distribution", "give", "follow", "method", "mixer", "passage", "hop", "sentence", "icnet", "sism", "baleen", "molecule", "caption", "grammar", "eeg", "molecular", "hover", "distinctiveness", "mlc", "flipr", "particle_\ufb01lter", "intra_cue", "hotpotqa", "patch", "electrode", "label_set", "co_saliency", "bf", "al", "intra_saliency", "wikipedia", "volume_conduction", "power_law", "image_captione", "retrieval", "resolution", "retrieve", "query", "label", "parse", "gmm", "image", "active", "bit", "model", "generate", "table", "top", "feature", "graph", "method", "use", "dataset", "result", "performance", "training", "propose", "number", "set", "learn", "base", "approach", "datum", "cid", "show", "matrix", "network", "give", "figure", "vqa", "assistant", "low_level", "ella", "instruction", "adversary", "lcon", "hamdp", "ssd", "base_vqa", "single_stage", "stage_detector", "misprediction", "subtask", "cls", "voc_voc", "object_detection", "updn", "hamdps", "social_dilemma", "instruction_followe", "sample_efficiency", "language_biase", "vqa_cp", "myopic_policy", "defect", "door", "red_ball", "voc", "consistency_losse", "question", "high_level", "box", "agent", "reward", "language", "detector", "answer", "maze", "ground", "goal", "environment", "pick", "consistency", "action", "task", "open", "performance", "policy", "trajectory", "show", "learn", "loss", "model", "state", "work", "set", "however", "use", "train", "reviewer", "multiclass", "bid", "constant_baseline", "peer_review", "fractional_assignment", "confusion", "program_chair", "binary_classi\ufb01cation", "cmax", "cost_sensitive", "discard", "pairwise_constraine", "cii", "threshold_logic", "fractional", "minimal_agreement", "sakurai", "nhl", "micro_macro", "sufficiently", "false_negative", "triplet_constraine", "untruthful", "integrity", "de_anonymization", "bidding", "jaccard", "predicted_labeling", "dvc", "micro", "assignment", "load", "assign", "measure", "incentive", "svmperf", "dichotomy", "paper", "review", "classi\ufb01er", "classi\ufb01cation", "similarity", "labeling", "thresholde", "property", "binary", "subset", "probability", "class", "distance", "pair", "problem", "conference", "de\ufb01nition", "result", "research", "theorem", "matrix", "section", "algorithm", "cid", "give", "number", "optimal", "set", "also", "use", "ompr", "rois", "oreo", "causal_confusion", "profile", "expert_demonstration", "fiber", "functional_connectivity", "p", "roi", "across_subject", "expert_action", "behavioral_clone", "lsh", "bc", "object_aware", "structural_connectivity", "hard_thresholding", "environment_interaction", "discrete_code", "cosamp", "codebook", "omp", "dropblock", "structural_profile", "_", "rip", "error_incurre", "cb_retrieval", "simulated_anneale", "recovery", "hash", "ax", "pattern", "sparse", "energy", "iterative", "retrieval", "stage", "address", "fig", "support", "vector", "functional", "brain", "method", "optimization", "use", "size", "region", "error", "show", "step", "matrix", "analysis", "problem", "base", "questionable", "ducti", "mva", "reho", "northwestern", "lobe", "elucidate", "goebelr", "meuli", "reso", "segregated", "gyrification", "resultstable", "worldpro", "gcm", "lezamatlozano", "io", "programdecoder", "pna", "scalepre", "highlighted", "htpt", "\ud835\udc40\ud835\udc38\ud835\udc53", "executorioop", "lop", "latentexecutor", "jlikliandlfei", "cv", "paracingulate", "ptpt", "lobule", "fsl", "spontaneous", "\ud835\udc38\ud835\udc50", "cefe", "involvement", "\ud835\udc38\ud835\udc53", "subcortical", "fluctuation", "segregate", "flirt", "ospan", "polytechnical", "embark", "iiee", "cid", "learn", "model", "miuimize", "use", "method", "thoo", "network", "set", "show", "result", "functioo", "neural", "image", "problem", "inversioo", "base", "performance", "learning", "figure", "function", "task", "number", "time", "training", "follow", "approach", "state", "sample", "datum", "value", "also", "policy", "work"], "Freq": [9142.0, 382.0, 299.0, 289.0, 548.0, 296.0, 554.0, 340.0, 517.0, 148.0, 1169.0, 301.0, 133.0, 804.0, 977.0, 260.0, 162.0, 1853.0, 108.0, 1582.0, 158.0, 275.0, 273.0, 245.0, 119.0, 556.0, 61.0, 1117.0, 281.0, 222.0, 102.17328087457777, 113.27479546077582, 140.25944889481826, 65.32525823018673, 51.045411871183596, 46.57195036064704, 50.834630826970304, 44.3049278307761, 31.37538766551389, 52.64994703555563, 54.201225864638026, 29.478809205036065, 37.37980880556745, 30.481353274899973, 28.559191907299052, 57.23444721551103, 37.776617129909035, 49.50054175671151, 34.08235889434062, 25.904891002892917, 24.9374909607494, 63.93931758828182, 28.258298184628618, 33.26640941299951, 24.103888421491728, 249.2731972387143, 21.485938893440423, 20.587490718834186, 26.79079812929122, 19.683280104015754, 45.60167429352924, 28.83222517705751, 896.9910939072738, 260.745943476289, 122.33773200949642, 290.7919925000782, 164.78743670711634, 403.8321758079666, 103.77523509746277, 1028.6083038718637, 562.5459631264794, 108.92160748597726, 355.53041695234816, 146.2530018191092, 232.33754962123606, 241.5490918765757, 311.77570345433224, 288.88483882927227, 127.47398012512458, 289.3859321516697, 717.2305558269783, 484.54234727636367, 283.79932844902856, 293.2762463498273, 306.266536308513, 179.6747061904562, 401.9315721593564, 263.589717072245, 331.17344456727795, 253.00160619279956, 218.35087494096953, 308.4703029133716, 246.57187831330523, 242.85485708816438, 301.8756940182997, 315.39899618927086, 222.95136781471257, 238.8743387772296, 438.9448498688158, 46.43633296422316, 46.74946335211217, 39.152800276985396, 39.134774809359584, 67.01540850368679, 30.621529051671196, 37.592245341069926, 36.62500966170967, 22.173323436808854, 23.670228321769972, 21.42881797119427, 211.71811323246357, 17.890942704302514, 18.615241538400497, 17.03690653484973, 17.035496628071964, 16.973332695072564, 16.912188467623782, 33.383989123709085, 15.422090765008077, 15.42170818489865, 42.01893498600723, 16.069605313877098, 16.058036457181693, 184.9909387531512, 16.665255108230365, 14.543947475990795, 14.465802059137461, 21.478157087298396, 13.682500531669362, 21.45727522475201, 31.774954733768045, 103.446844823815, 206.92619828736642, 31.595477411517173, 172.8137095694734, 46.17056934717295, 44.02046608374898, 54.80673153985884, 30.587237070388817, 78.9135523565439, 33.42149416822123, 131.8412150150425, 170.0353427005352, 116.05480738710654, 123.72307848430845, 419.2599027308033, 86.62472120115497, 153.78333965209782, 59.63936764114498, 84.63354872661506, 256.70214466528, 160.97260216161524, 565.7085689473307, 301.31360708890384, 102.51375175182984, 115.16066127510571, 283.0404592341665, 309.44808329602455, 211.68738488582596, 157.50967601480602, 317.1441196492954, 251.7100321030812, 216.5514138952147, 1059.8340399229196, 241.6910302943144, 171.35916133256347, 181.53643851409063, 168.2006409180801, 173.87436186136964, 177.31047386760102, 190.4839233655429, 283.6004223826951, 167.1373425741123, 152.70581115712758, 160.12549968506198, 44.405711572966126, 47.04906394632482, 25.212843586752655, 25.06161511303275, 22.165678184772627, 25.417538198943866, 21.46115507593676, 20.66955752560082, 19.936193327728827, 30.393038327230762, 53.2420194067592, 18.880832161240658, 24.01806863632774, 18.207594866565348, 18.096220968567128, 19.799093142750742, 15.913487034573295, 15.342899302918063, 7467.063732486807, 14.020576375319433, 16.846936426538253, 18.81536686736317, 13.16712172314193, 12.571051065780585, 16.226331841314554, 16.77653389914811, 12.465133349764619, 16.735410288839105, 11.799550267206163, 19.640541606044472, 33.143707466119814, 41.5778446820797, 43.69433212139492, 57.62715397713421, 64.54401921664119, 113.12907728891729, 169.96452703680106, 75.2095059481716, 33.98829554476649, 58.4376336953403, 104.17305348825822, 155.20580146979788, 65.45745297726921, 100.14561331827085, 118.82183754393834, 49.64085039937712, 160.0622168147964, 161.81763613305225, 113.54361377092533, 90.23364865450205, 77.54428067136986, 150.8564310055159, 103.95711758544941, 209.95032671325842, 136.26748493097233, 58.31480181517935, 69.21607561752896, 126.78471621004861, 69.74244716159278, 80.40668930578711, 120.99059320641389, 94.3138237679008, 89.66448997580592, 114.07339015034427, 100.09429187047688, 117.11425482893542, 81.70500725514121, 75.14701877399115, 75.44036800910376, 77.06390551928352, 75.34730843600362, 75.823185293861, 69.66810981471514, 74.76639593014389, 69.5507397133409, 59.522618132093044, 41.80939894802057, 32.932135090513285, 29.72558643594798, 53.83655162938013, 38.43493242230287, 27.600621068950687, 19.30477734907037, 35.78567996155552, 18.63907563052819, 18.50250564959566, 17.218724664549104, 15.863653950904787, 15.859133606975691, 16.42079295853194, 15.178504164082007, 48.773521549251974, 18.619612670924248, 15.14236623152146, 15.048564131218248, 18.598893876385393, 14.416609460544981, 14.37362813761447, 13.77261184576925, 13.079419917047721, 17.11873604669432, 15.146396816371857, 58.203696933149644, 45.9085269051536, 28.49153916167039, 62.200104541890944, 169.77282704461516, 21.368936479100487, 35.56690325742633, 224.53571495198082, 34.934491919504005, 52.756129865032555, 333.19792638037455, 84.10364614722387, 76.90097116446923, 52.76184151482877, 104.7623260683522, 87.9287042620789, 162.816540588643, 160.0304070837645, 81.39572849088718, 123.48455815758776, 98.71110777145464, 89.26335731683409, 80.4697661505766, 93.59743395524235, 115.47607064958672, 125.50928837259944, 91.4827998574593, 81.47189926435713, 78.3451714120713, 144.5422792156371, 80.42286179124203, 69.17338696156725, 78.81868240241867, 67.28737769641484, 63.62835452760558, 24.956070292517886, 27.20883966628357, 21.949351172061807, 13.428517476180632, 24.763145592558878, 8.917205152883621, 6.493965700827647, 6.4844847803566905, 6.129424709773525, 6.152268755036879, 7.475082553176325, 5.791144344418123, 5.798984151244108, 4.920243593598483, 5.441626842401313, 5.436994265736337, 9.5765157418306, 5.126049752297197, 5.107307287983779, 4.220349531542493, 4.210727440005302, 4.21111084778746, 4.431763630636528, 4.423118908100509, 4.409068376468551, 3.8663991778350946, 6.635224597924091, 3.856214407303794, 4.04967371246533, 4.04698183690691, 45.495347103232554, 12.61916450285995, 11.998809909218638, 71.01234458526547, 38.6688822328443, 24.97926084858018, 9.341279025309541, 16.500107910004658, 6.587564123011757, 6.8751207617392085, 34.940573624198684, 23.56590586415976, 9.441609943768862, 11.876923131475351, 24.18275283807015, 27.476583427130045, 10.436752061337076, 20.58669745523607, 18.72429014285791, 11.924367839246678, 18.346954320763817, 21.087532292818512, 13.85347767831217, 19.64926221942441, 14.909764513943077, 13.065791255225117, 14.52480866270566, 11.440653201878458, 12.591116378745872, 11.467920072478263, 54.56822602367961, 10.177707111274952, 7.8615206312959085, 7.545396532493211, 7.168151283157778, 5.802850219116658, 5.129143802836303, 4.425788371942279, 10.697545390806795, 3.7497192344691563, 5.0392763945375, 3.405632049728765, 2.712401911758723, 2.7155067203560814, 2.6942609377070017, 3.2964854087443074, 2.3699581039696747, 2.3496838578955126, 2.348991842132408, 3.00870644433797, 2.3495895838159377, 3.5723445712878297, 2.0257212545426433, 2.025518583612818, 2.0254516380115635, 2.024973481347261, 2.0243838098184033, 2.0249384495394813, 2.025002277126431, 2.0057743999705067, 3.875812833439125, 32.77581218155764, 5.805743369566489, 19.69415601985076, 85.24598287048326, 2.3669222585122385, 2.719517770640559, 3.6420013776868148, 58.72916255722545, 9.864639400141582, 12.77133670506446, 25.691909644921047, 16.26043432948604, 5.805585634725177, 4.931014902790451, 27.530625423744635, 12.726039660542222, 11.937499712010297, 22.18112971584769, 21.989084978773928, 12.791751261782347, 14.516619167699956, 26.916918039672428, 14.525032670770493, 9.321424083476888, 15.897515071993853, 9.29947252911924, 10.693776628575076, 12.821748760347752, 11.670247002599007, 11.200572070856483, 20.743233575456635, 12.187378845714107, 11.39566365814405, 10.279078525058368, 11.42522536835718, 10.746519491257661, 10.436149412735938, 21.021988407970973, 15.488356317617693, 15.191875837520666, 6.610902789541616, 6.049956660824406, 5.000790355548444, 4.122161698094376, 4.679213216558966, 3.8659106972064414, 5.231316244109807, 3.571071618501617, 3.9261928347537913, 3.9202739658931303, 3.285221634270699, 4.726899269839869, 4.6740049394232095, 2.739072950589827, 6.059278947501118, 4.4890224135805585, 3.1082930270796645, 3.00781688533253, 3.3808993716819242, 3.8387264704585706, 2.574534126841881, 2.1846509489690056, 6.925471703999998, 7.167608290223112, 2.1768895627018354, 2.133803799474092, 2.45080520803224, 10.279471194777887, 5.780626569774063, 4.371397925218727, 16.233190704582753, 12.701032442444909, 10.100102998485225, 6.535048487331583, 9.358430799272924, 5.697667441853741, 8.78446588790913, 10.150931591821424, 9.716737125591564, 11.689964114088017, 7.182042798625764, 6.528867103402044, 14.184011175388953, 9.752741531192099, 12.25474045227172, 9.099984441078211, 7.0590711348225, 7.952901106649643, 9.477029758851973, 7.121068898396913, 7.081432943382008, 6.815668909421159, 6.955096611388244, 6.696419938517717, 8.032353346533935e-05, 8.031952217574178e-05, 8.032013369720492e-05, 8.031810257234517e-05, 8.031687224940145e-05, 8.031478288440236e-05, 8.031520512541262e-05, 8.03132249606748e-05, 8.031494304478556e-05, 8.031355984147605e-05, 8.030981791252295e-05, 8.031183447734787e-05, 8.012075586016543e-05, 8.012015161871971e-05, 8.031246055884586e-05, 8.012029721906807e-05, 8.012067577997384e-05, 8.012024625894614e-05, 8.031139767630276e-05, 8.012037001924225e-05, 8.03096359120875e-05, 8.012069762002609e-05, 8.031075703476994e-05, 8.012065393992158e-05, 8.012042097936419e-05, 8.012063937988673e-05, 8.012052289960804e-05, 8.012050105955578e-05, 8.031242415875877e-05, 8.012063937988673e-05, 8.030764846733226e-05, 8.031167431696466e-05, 8.030946119166946e-05, 8.031079343485704e-05, 8.030952671182622e-05, 8.030777950764578e-05, 8.03091627109553e-05, 8.030850022937022e-05, 8.030943207159978e-05, 8.030907535074628e-05, 8.030936655144301e-05, 8.030778678766321e-05, 8.030843470921345e-05, 8.030858758957924e-05, 8.030872590991019e-05, 0.0006240286495562207, 0.00026780371083800483, 0.00025623439451679005, 8.034572295843082e-05, 0.00021279809778934728, 0.00020593219688171471, 8.034227951019189e-05, 0.00019843896231309818, 0.0001932174426198787, 0.00017762547987391713, 0.0001699423533309574, 8.033960046378189e-05, 0.00016826353763415498, 0.00015601707777277912, 0.00016241897949022846, 8.033826822059432e-05, 0.00015479831549671913, 0.00015149438151159286, 0.00014984688444972467, 0.00014770098283535356, 0.00015316454854770215, 0.00014443433709944466, 0.0001449713839844048, 0.0001452686707757052, 0.00013782496944560394, 0.0001373340924311117, 0.00013717473284982152, 0.00013805057718540214, 0.00013730524900209976, 0.00013849676945297984, 0.00013662493137434425, 0.00013624401174294051, 0.00013530311317170847, 0.00013195204835381508], "Total": [9142.0, 382.0, 299.0, 289.0, 548.0, 296.0, 554.0, 340.0, 517.0, 148.0, 1169.0, 301.0, 133.0, 804.0, 977.0, 260.0, 162.0, 1853.0, 108.0, 1582.0, 158.0, 275.0, 273.0, 245.0, 119.0, 556.0, 61.0, 1117.0, 281.0, 222.0, 105.73351076663499, 117.48319868042644, 145.9285601057619, 68.60532766430639, 54.288338781469484, 49.783157578943076, 55.496093229885275, 48.64958846276839, 34.47361951224098, 58.16193215799954, 59.881988915594896, 32.659873366773645, 41.43304406839991, 33.869702322155334, 31.741495317435344, 63.628290423481026, 42.17002506457246, 55.28814121723201, 38.110770980296856, 28.98915926569337, 28.07133426499924, 72.0226622275185, 31.858214248689784, 37.514218732733475, 27.22329391509706, 283.4893829978529, 24.543844569609984, 23.638634162167378, 30.793320059135105, 22.728545886092096, 52.828176097377636, 33.364148689918544, 1169.9817986107198, 324.13464976527735, 151.90338967808825, 379.4635357529093, 208.32940471214317, 554.1580182322531, 129.8527950957026, 1582.4827506170263, 818.2552737377542, 143.8586734922873, 573.8298329126834, 206.2728709056714, 354.4212130927544, 371.67718431663326, 517.4153327799546, 481.81675674829484, 179.86873469189447, 529.5098374324969, 1853.6023932675832, 1117.9896862576888, 548.4016830950301, 576.2927739113163, 644.0851045071646, 310.2134834176592, 977.0257723228295, 556.1915568993076, 804.3279010530191, 548.5752992432173, 437.4149724989284, 816.4247287107944, 553.3741707801116, 540.0889573176203, 817.8349924711029, 1007.0174726498961, 530.4052462671851, 802.309016330069, 9142.883059978938, 49.62384600674017, 50.916158675186395, 42.66231540040564, 42.653448596349726, 73.13835819616747, 34.01733173832525, 41.817272244734504, 40.84963098751488, 25.369823002344205, 27.08840971640627, 24.534451272997188, 245.6873228095235, 21.052673426351348, 21.92012727033402, 20.187111735164038, 20.20002538597904, 20.197595352814446, 20.191757916389598, 39.90384421698115, 18.48417182974069, 18.48478755753351, 50.515355731826425, 19.332601098426565, 19.332003826884403, 222.71738108592837, 20.070655005806085, 17.607855055501233, 17.596267500505974, 26.210172603011976, 16.750553396743904, 26.334049914315955, 39.198421786317326, 131.06280528324325, 273.2933861192013, 39.84999444621016, 258.13202822394857, 61.471661215210815, 59.062228708736576, 76.34963324850544, 39.43615650486806, 117.29146286354361, 43.81255720808304, 213.42269885313732, 307.1960666701984, 195.94938082610315, 218.31302288559402, 1007.0174726498961, 142.8377759414503, 303.12212161417415, 90.17195030343883, 142.9904985066963, 613.9217781857932, 340.96862496596043, 1853.6023932675832, 817.8349924711029, 187.84831239390962, 222.2124416621663, 804.3279010530191, 977.0257723228295, 587.4327052425879, 380.6023922765996, 1117.9896862576888, 802.309016330069, 649.1961092835929, 9142.883059978938, 816.4247287107944, 460.9932117779527, 551.9106228229618, 480.85829210309515, 517.4153327799546, 553.3741707801116, 644.0851045071646, 1582.4827506170263, 540.0889573176203, 413.0831005748185, 576.2927739113163, 47.75926782242583, 50.79768286877831, 28.39666380592866, 28.369803766621867, 25.394660177807744, 29.129326508862555, 24.657192132821823, 23.91207517427914, 23.167699979474907, 35.32525280763044, 62.68403433084054, 22.429233936691446, 28.60491635243098, 21.710784049069147, 21.678715710048877, 23.73252024767092, 19.288737283755886, 18.71563933385673, 9142.883059978938, 17.196894549082796, 20.758308567737952, 23.289971254894635, 16.43980446296744, 15.718421820443837, 20.33284590428524, 21.088124430716256, 15.699831739760905, 21.092205580247263, 14.960374951445745, 25.044806033148156, 44.68390510918865, 57.57018466214168, 65.40199112979076, 93.22155670174456, 111.46197301291116, 256.8640973061861, 444.7827192994688, 154.12175720118563, 57.076206234611014, 131.33736838900933, 318.7949126916676, 649.1961092835929, 166.1696917889442, 330.72237839874555, 437.4149724989284, 112.30865184661069, 802.309016330069, 817.8349924711029, 460.9932117779527, 310.2134834176592, 242.36826907552813, 816.4247287107944, 416.97414014902677, 1853.6023932675832, 818.2552737377542, 153.38923053935866, 234.9454973950647, 1007.0174726498961, 263.6942404260918, 380.6023922765996, 1117.9896862576888, 587.4327052425879, 540.0889573176203, 1169.9817986107198, 804.3279010530191, 1582.4827506170263, 530.4052462671851, 403.9234282221424, 428.9641205226873, 551.9106228229618, 480.85829210309515, 977.0257723228295, 73.57810860665454, 79.22433628611965, 74.69506349492438, 63.971554030190845, 45.625414225746866, 36.55952957733544, 33.055644052433884, 59.911083585964576, 42.96944765844049, 30.992984355988913, 22.587377162110325, 42.039551827003436, 21.9041269078266, 21.95310923612349, 20.525057935530935, 19.111571461655817, 19.13452565943243, 19.82472644948937, 18.4197842844811, 59.1996871461292, 22.637031459988656, 18.43146168432019, 18.421903870997376, 22.799919626927554, 17.743569271276417, 17.725340396631598, 17.02901288617943, 16.318488459482886, 21.44650116751235, 19.004070973720744, 80.27071633293858, 65.16384122622324, 38.413547802575465, 94.3454462991982, 301.0458781706361, 28.232968371567704, 53.17800081704286, 548.5752992432173, 56.26713939026292, 106.22473580986549, 1853.6023932675832, 250.98478511370635, 223.21688620764343, 122.33308934494849, 403.9234282221424, 315.67659769761894, 977.0257723228295, 1117.9896862576888, 350.33377476864666, 802.309016330069, 556.1915568993076, 481.81675674829484, 395.23840012150583, 587.4327052425879, 1007.0174726498961, 1582.4827506170263, 644.0851045071646, 529.5098374324969, 613.9217781857932, 9142.883059978938, 816.4247287107944, 460.9932117779527, 1169.9817986107198, 551.9106228229618, 548.4016830950301, 30.171557802206827, 33.022569985823814, 26.826729064752897, 17.13906934119463, 33.037758570911144, 13.19210804753556, 10.479616584809497, 10.588204868465178, 10.128990571908414, 10.198714050666846, 12.567090926432726, 9.753338382001473, 9.832960931493725, 8.483260857751848, 9.386877765101413, 9.39061734572998, 16.620119261316116, 9.0632853241849, 9.084660142045585, 7.749818854660465, 7.763229847835847, 7.764275693481049, 8.320107535683574, 8.334908655850091, 8.347673791530013, 7.38916990820636, 12.718469699434568, 7.402760856233191, 7.921860169763714, 7.921815379811489, 133.01106746271466, 30.77466460579121, 29.853987599635456, 299.6241124991991, 148.26593159718774, 93.39469752639613, 24.205279731567956, 57.47263527568333, 14.956893775327938, 17.044254861197178, 296.74819922226476, 162.97399020679623, 32.158452689519336, 58.067433403411925, 340.96862496596043, 554.1580182322531, 58.164728383249596, 556.1915568993076, 517.4153327799546, 121.15714328897957, 816.4247287107944, 1582.4827506170263, 294.40791633785875, 1853.6023932675832, 576.2927739113163, 408.6527859030365, 1007.0174726498961, 293.87603685258455, 1117.9896862576888, 354.4212130927544, 61.42881517634365, 14.103555010984046, 11.469649226802975, 11.14938665189655, 10.772764167555717, 9.376928983791636, 8.701158450600179, 7.9817588536550055, 20.088703167738082, 7.299259806783628, 11.07322811673508, 7.643169466638751, 6.2337700821056705, 6.247871200336287, 6.284513007653386, 7.961772174047634, 5.898428860783286, 5.933642376205769, 5.934231605059123, 8.05533675591487, 6.306240157720327, 9.760412593222973, 5.5347109499540075, 5.535246183008562, 5.5355858336200585, 5.534723250023946, 5.5348418333315585, 5.548184100949723, 5.548417818739102, 5.581630623608914, 10.902016685417001, 108.16986379559694, 17.457486130713647, 71.29730956448523, 382.14739937801687, 6.61395005573475, 7.759625653270784, 10.947311819120843, 289.34014171123107, 39.82231125266802, 60.47678195990607, 158.3522706052941, 87.87491634752743, 21.217789842120123, 16.97712881731947, 260.815921244602, 84.80913974291309, 80.99581928482979, 275.39841339593073, 273.39155218122306, 106.60234714295463, 178.09036998193255, 804.3279010530191, 208.45601261197865, 107.05519833889092, 802.309016330069, 116.9911961741763, 222.68103110951265, 460.9932117779527, 333.4523179732663, 303.12212161417415, 9142.883059978938, 551.9106228229618, 587.4327052425879, 307.1960666701984, 1007.0174726498961, 530.4052462671851, 1117.9896862576888, 24.95403320120712, 20.190057717027166, 20.89616358361789, 11.215496299953838, 10.65362162442542, 9.402377855642234, 7.752581124741782, 9.00900632615962, 7.45472693505743, 10.109800857810196, 7.186640602896093, 8.19435667054331, 8.206363856762232, 6.912242307723555, 9.973539464171099, 9.945603975592068, 6.338306963911267, 14.208234551295455, 10.541402012628156, 7.314278943487452, 7.378362390201072, 8.469448086319348, 9.623199461536355, 6.703248298219108, 5.773530234594987, 18.377912545081667, 19.04891628082873, 5.785561165430835, 5.88299390622493, 6.978539236143162, 34.73443229845288, 18.839130543687556, 15.758488803012636, 119.93069518704174, 112.30865184661069, 81.98643489896125, 36.09778943025931, 80.27071633293858, 28.606077808360563, 100.94118938008697, 151.9478671985043, 155.1867460087789, 281.4793743450838, 71.39436970436569, 52.753031926749834, 977.0257723228295, 303.70390145500494, 1117.9896862576888, 298.6145850083284, 84.80525471570903, 234.9454973950647, 816.4247287107944, 303.3583698056873, 460.9932117779527, 318.7949126916676, 804.3279010530191, 644.0851045071646, 4.074985628583956, 4.074917386489696, 4.075088096210926, 4.075085437099263, 4.075056685647442, 4.074986995552343, 4.075022498164053, 4.0750123650952075, 4.075105576018068, 4.075039253291009, 4.074907620834461, 4.075013198277525, 4.065321554443854, 4.065293889053548, 4.075063253069544, 4.0653250484735315, 4.065346725653578, 4.065334496026071, 4.075037576535041, 4.0653482003905905, 4.074952496985203, 4.065366191414555, 4.0750106123772705, 4.0653719686899485, 4.0653619517737996, 4.065374951770318, 4.065379152426091, 4.06537871769578, 4.075118419434174, 4.065387953333364, 4.0748774375521455, 4.075105074239206, 4.074996156848003, 4.075104994684302, 4.075079922812374, 4.074991361166362, 4.0750645538307895, 4.075033266412528, 4.075082102966874, 4.07510813479406, 4.075136912988346, 4.0750810034370835, 4.0751173560373815, 4.075126335750018, 4.075145339462085, 9142.883059978938, 1582.4827506170263, 1853.6023932675832, 4.085357717117825, 1117.9896862576888, 977.0257723228295, 4.085314566726944, 1169.9817986107198, 1007.0174726498961, 816.4247287107944, 802.309016330069, 4.085551112646665, 818.2552737377542, 548.5752992432173, 804.3279010530191, 4.085387123974497, 644.0851045071646, 556.1915568993076, 573.8298329126834, 548.4016830950301, 817.8349924711029, 554.1580182322531, 587.4327052425879, 649.1961092835929, 481.81675674829484, 480.85829210309515, 529.5098374324969, 576.2927739113163, 553.3741707801116, 613.9217781857932, 540.0889573176203, 530.4052462671851, 517.4153327799546, 408.6527859030365], "Category": ["Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Default", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic1", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic2", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic3", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic4", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic5", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic6", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic7", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8", "Topic8"], "logprob": [30.0, 29.0, 28.0, 27.0, 26.0, 25.0, 24.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 16.0, 15.0, 14.0, 13.0, 12.0, 11.0, 10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0, -6.5494, -6.4463, -6.2326, -6.9967, -7.2434, -7.3351, -7.2475, -7.385, -7.73, -7.2124, -7.1834, -7.7924, -7.5549, -7.759, -7.8241, -7.1289, -7.5444, -7.2741, -7.6473, -7.9216, -7.9597, -7.0181, -7.8347, -7.6715, -7.9937, -5.6575, -8.1087, -8.1514, -7.888, -8.1963, -7.3561, -7.8146, -4.377, -5.6125, -6.3693, -5.5035, -6.0714, -5.1751, -6.5338, -4.2401, -4.8436, -6.4854, -5.3025, -6.1907, -5.7279, -5.689, -5.4338, -5.51, -6.3282, -5.5083, -4.6007, -4.9929, -5.5278, -5.495, -5.4516, -5.9849, -5.1798, -5.6017, -5.3734, -5.6427, -5.79, -5.4444, -5.6684, -5.6836, -5.4661, -5.4222, -5.7691, -5.7001, -5.0917, -7.028, -7.0213, -7.1987, -7.1991, -6.6612, -7.4444, -7.2393, -7.2654, -7.7672, -7.7019, -7.8014, -5.5109, -7.9818, -7.9421, -8.0307, -8.0308, -8.0345, -8.0381, -7.358, -8.1303, -8.1303, -7.128, -8.0892, -8.0899, -5.6458, -8.0528, -8.189, -8.1943, -7.7991, -8.25, -7.8001, -7.4074, -6.2271, -5.5338, -7.4131, -5.7139, -7.0338, -7.0815, -6.8623, -7.4455, -6.4978, -7.3569, -5.9845, -5.7301, -6.1121, -6.0481, -4.8276, -6.4045, -5.8306, -6.7778, -6.4278, -5.3182, -5.7849, -4.528, -5.158, -6.2361, -6.1198, -5.2205, -5.1313, -5.511, -5.8066, -5.1068, -5.3378, -5.4883, -3.9003, -5.3785, -5.7224, -5.6647, -5.741, -5.7078, -5.6882, -5.6166, -5.2186, -5.7473, -5.8376, -5.7902, -6.7567, -6.6989, -7.3228, -7.3288, -7.4516, -7.3147, -7.4839, -7.5215, -7.5576, -7.1359, -6.5753, -7.612, -7.3713, -7.6483, -7.6544, -7.5645, -7.7829, -7.8195, -1.6319, -7.9096, -7.7259, -7.6154, -7.9724, -8.0187, -7.7635, -7.7301, -8.0272, -7.7326, -8.0821, -7.5725, -7.0493, -6.8225, -6.7729, -6.4961, -6.3828, -5.8216, -5.4145, -6.2298, -7.0241, -6.4822, -5.9041, -5.5054, -6.3687, -5.9435, -5.7725, -6.6453, -5.4746, -5.4636, -5.8179, -6.0477, -6.1993, -5.5338, -5.9061, -5.2032, -5.6355, -6.4843, -6.3129, -5.7076, -6.3053, -6.163, -5.7544, -6.0035, -6.054, -5.8133, -5.944, -5.787, -6.147, -6.2307, -6.2268, -6.2055, -6.228, -6.2217, -6.0113, -5.9407, -6.013, -6.1687, -6.5219, -6.7606, -6.863, -6.2691, -6.6061, -6.9372, -7.2947, -6.6775, -7.3298, -7.3371, -7.4091, -7.491, -7.4913, -7.4565, -7.5352, -6.3679, -7.3308, -7.5376, -7.5438, -7.3319, -7.5867, -7.5897, -7.6324, -7.684, -7.4149, -7.5373, -6.1911, -6.4284, -6.9054, -6.1247, -5.1206, -7.1931, -6.6836, -4.841, -6.7016, -6.2894, -4.4463, -5.823, -5.9125, -6.2893, -5.6034, -5.7785, -5.1624, -5.1797, -5.8557, -5.4389, -5.6629, -5.7635, -5.8672, -5.716, -5.506, -5.4227, -5.7389, -5.8548, -5.8939, -5.2815, -5.8677, -6.0184, -5.8879, -6.0461, -6.102, -5.6207, -5.5343, -5.7491, -6.2405, -5.6285, -6.6499, -6.967, -6.9684, -7.0247, -7.021, -6.8263, -7.0815, -7.0802, -7.2445, -7.1438, -7.1446, -6.5785, -7.2035, -7.2072, -7.3979, -7.4002, -7.4001, -7.349, -7.351, -7.3542, -7.4855, -6.9454, -7.4881, -7.4392, -7.4399, -5.0202, -6.3026, -6.353, -4.575, -5.1828, -5.6198, -6.6034, -6.0345, -6.9527, -6.9099, -5.2842, -5.678, -6.5927, -6.3632, -5.6522, -5.5245, -6.4925, -5.8132, -5.908, -6.3593, -5.9284, -5.7892, -6.2093, -5.8598, -6.1358, -6.2678, -6.162, -6.4007, -6.3048, -6.3983, -4.7492, -6.4284, -6.6866, -6.7277, -6.779, -6.9903, -7.1137, -7.2612, -6.3786, -7.4269, -7.1314, -7.5232, -7.7508, -7.7496, -7.7575, -7.5558, -7.8858, -7.8943, -7.8946, -7.6471, -7.8944, -7.4754, -8.0427, -8.0428, -8.0428, -8.0431, -8.0434, -8.0431, -8.0431, -8.0526, -7.3939, -5.2589, -6.9898, -5.7683, -4.3031, -7.887, -7.7482, -7.4561, -4.6757, -6.4597, -6.2014, -5.5024, -5.9599, -6.9898, -7.1531, -5.4333, -6.205, -6.2689, -5.6494, -5.6581, -6.1998, -6.0733, -5.4559, -6.0728, -6.5163, -5.9825, -6.5187, -6.379, -6.1975, -6.2916, -6.3327, -5.7164, -6.2482, -6.3154, -6.4185, -6.3128, -6.374, -6.4033, -5.4072, -5.7127, -5.732, -6.5641, -6.6527, -6.8432, -7.0364, -6.9097, -7.1006, -6.7981, -7.1799, -7.0851, -7.0866, -7.2634, -6.8995, -6.9108, -7.4452, -6.6512, -6.9512, -7.3187, -7.3516, -7.2346, -7.1076, -7.5071, -7.6713, -6.5176, -6.4832, -7.6749, -7.6949, -7.5564, -6.1226, -6.6983, -6.9777, -5.6657, -5.9111, -6.1402, -6.5756, -6.2165, -6.7127, -6.2798, -6.1352, -6.1789, -5.9941, -6.4812, -6.5766, -5.8007, -6.1752, -5.9469, -6.2445, -6.4985, -6.3793, -6.2039, -6.4897, -6.4953, -6.5336, -6.5133, -6.5512, -9.43, -9.4301, -9.43, -9.4301, -9.4301, -9.4301, -9.4301, -9.4301, -9.4301, -9.4301, -9.4302, -9.4302, -9.4325, -9.4325, -9.4301, -9.4325, -9.4325, -9.4325, -9.4302, -9.4325, -9.4302, -9.4325, -9.4302, -9.4325, -9.4325, -9.4325, -9.4325, -9.4325, -9.4301, -9.4325, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -9.4302, -7.3799, -8.2258, -8.27, -9.4297, -8.4557, -8.4885, -9.4298, -8.5256, -8.5523, -8.6364, -8.6806, -9.4298, -8.6905, -8.7661, -8.7259, -9.4298, -8.7739, -8.7955, -8.8065, -8.8209, -8.7846, -8.8432, -8.8395, -8.8375, -8.8901, -8.8937, -8.8948, -8.8884, -8.8939, -8.8852, -8.8988, -8.9016, -8.9086, -8.9336], "loglift": [30.0, 29.0, 28.0, 27.0, 26.0, 25.0, 24.0, 23.0, 22.0, 21.0, 20.0, 19.0, 18.0, 17.0, 16.0, 15.0, 14.0, 13.0, 12.0, 11.0, 10.0, 9.0, 8.0, 7.0, 6.0, 5.0, 4.0, 3.0, 2.0, 1.0, 1.0362, 1.034, 1.0309, 1.0215, 1.0089, 1.0038, 0.9827, 0.9769, 0.9763, 0.9709, 0.9708, 0.968, 0.9675, 0.9651, 0.9648, 0.9646, 0.9605, 0.9599, 0.9588, 0.958, 0.9521, 0.9514, 0.9506, 0.9503, 0.9488, 0.9419, 0.9374, 0.9323, 0.9312, 0.9266, 0.9234, 0.9245, 0.8048, 0.8529, 0.854, 0.8043, 0.836, 0.754, 0.8463, 0.6397, 0.6958, 0.7923, 0.5918, 0.7266, 0.6482, 0.6395, 0.5639, 0.5589, 0.7262, 0.4663, 0.121, 0.2344, 0.4117, 0.395, 0.3271, 0.5244, 0.1822, 0.3238, 0.1831, 0.2966, 0.3757, 0.0972, 0.2621, 0.2712, 0.0738, -0.0904, 0.2038, -0.1411, -1.9659, 1.314, 1.295, 1.2946, 1.2943, 1.293, 1.2753, 1.2739, 1.2713, 1.2458, 1.2455, 1.2451, 1.2316, 1.2177, 1.217, 1.2108, 1.21, 1.2065, 1.2032, 1.202, 1.1993, 1.1993, 1.1963, 1.1956, 1.1949, 1.1948, 1.1945, 1.1893, 1.1845, 1.1813, 1.1781, 1.1756, 1.1705, 1.1438, 1.1022, 1.1483, 0.9792, 1.0942, 1.0865, 1.0489, 1.1263, 0.9841, 1.1097, 0.8987, 0.7889, 0.8566, 0.8125, 0.5042, 0.8803, 0.7018, 0.967, 0.856, 0.5085, 0.6299, 0.1936, 0.3819, 0.7748, 0.7231, 0.336, 0.2307, 0.3598, 0.4982, 0.1205, 0.2212, 0.2825, -0.7744, 0.1632, 0.3908, 0.2685, 0.33, 0.2899, 0.2423, 0.1622, -0.3388, 0.2075, 0.3853, 0.0998, 1.6236, 1.6198, 1.5775, 1.5724, 1.5604, 1.5601, 1.5576, 1.5507, 1.5462, 1.5461, 1.5332, 1.5242, 1.5217, 1.5205, 1.5158, 1.5152, 1.5041, 1.4977, 1.494, 1.4922, 1.4877, 1.4831, 1.4745, 1.473, 1.4708, 1.4677, 1.4657, 1.4651, 1.4591, 1.4534, 1.3977, 1.371, 1.2931, 1.2155, 1.1501, 0.8764, 0.7344, 0.979, 1.1781, 0.8866, 0.5779, 0.2655, 0.7648, 0.5018, 0.3932, 0.88, 0.0845, 0.0762, 0.2952, 0.4616, 0.5568, 0.0078, 0.3074, -0.4816, -0.0961, 0.7293, 0.4743, -0.3758, 0.3665, 0.1418, -0.5271, -0.1327, -0.0992, -0.6315, -0.3875, -0.9072, -0.1741, 0.0147, -0.0416, -0.2723, -0.157, -0.8597, 1.9369, 1.9336, 1.9201, 1.9194, 1.9042, 1.887, 1.8853, 1.8846, 1.88, 1.8756, 1.8345, 1.8304, 1.8301, 1.8205, 1.8159, 1.8052, 1.8038, 1.8031, 1.798, 1.7978, 1.7961, 1.7949, 1.7892, 1.7878, 1.7839, 1.7819, 1.7793, 1.7702, 1.7661, 1.7646, 1.67, 1.6413, 1.6927, 1.5749, 1.4187, 1.713, 1.5893, 1.0982, 1.5149, 1.2916, 0.2754, 0.8982, 0.9259, 1.1505, 0.642, 0.7133, 0.1996, 0.0476, 0.5319, 0.1201, 0.2626, 0.3055, 0.3999, 0.1547, -0.1742, -0.5429, 0.0398, 0.1198, -0.0672, -2.1557, -0.3261, 0.0947, -0.7061, -0.1129, -0.1624, 3.2189, 3.2151, 3.2081, 3.1647, 3.1204, 3.0171, 2.9302, 2.9184, 2.9064, 2.9033, 2.8892, 2.8874, 2.8807, 2.864, 2.8635, 2.8622, 2.8574, 2.8388, 2.8328, 2.801, 2.797, 2.7969, 2.7788, 2.7751, 2.7704, 2.761, 2.7581, 2.7566, 2.7377, 2.7371, 2.3359, 2.5172, 2.4972, 1.969, 2.0647, 2.0899, 2.4566, 2.1608, 2.5887, 2.5008, 1.2695, 1.4749, 2.1832, 1.8217, 0.7626, 0.4046, 1.6908, 0.1122, 0.0897, 1.0902, -0.3868, -0.9094, 0.3523, -1.1381, -0.2459, -0.0342, -0.8302, 0.1627, -1.0776, -0.0222, 3.3795, 3.1717, 3.1202, 3.1075, 3.0906, 3.018, 2.9694, 2.9082, 2.8678, 2.8318, 2.7107, 2.6895, 2.6658, 2.6647, 2.651, 2.6161, 2.5861, 2.5716, 2.5712, 2.5131, 2.5106, 2.4928, 2.4928, 2.4926, 2.4925, 2.4924, 2.4921, 2.49, 2.49, 2.4745, 2.4637, 2.3039, 2.397, 2.2114, 1.9977, 2.4703, 2.4494, 2.3974, 1.9033, 2.1025, 1.9429, 1.6793, 1.8107, 2.2019, 2.2616, 1.2494, 1.6012, 1.5832, 0.979, 0.9776, 1.3776, 0.9909, 0.1007, 0.8341, 1.0569, -0.4234, 0.9658, 0.4618, -0.0843, 0.1455, 0.1998, -2.5906, -0.3151, -0.4446, 0.1006, -0.981, -0.4011, -1.1761, 3.6223, 3.5287, 3.475, 3.2652, 3.2279, 3.1624, 3.1621, 3.1387, 3.1371, 3.1349, 3.0944, 3.058, 3.055, 3.0499, 3.0471, 3.0387, 2.9548, 2.9415, 2.9401, 2.938, 2.8964, 2.8754, 2.8747, 2.8368, 2.8219, 2.8178, 2.8163, 2.8163, 2.7796, 2.7473, 2.5762, 2.6123, 2.5115, 1.7939, 1.6142, 1.6998, 2.0847, 1.6446, 2.1802, 1.3522, 1.0878, 1.023, 0.6124, 1.4971, 1.7044, -0.4386, 0.3553, -0.7196, 0.3029, 1.3077, 0.4079, -0.6623, 0.0419, -0.3821, -0.0516, -0.9568, -0.7725, 1.4117, 1.4116, 1.4116, 1.4116, 1.4116, 1.4116, 1.4116, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, 1.4115, -4.2541, -3.346, -3.5483, 1.4094, -3.2285, -3.1265, 1.4094, -3.3438, -3.2204, -3.0948, -3.1216, 1.4093, -3.1512, -2.8269, -3.1693, 1.4093, -2.9952, -2.8701, -2.9122, -2.8813, -3.2447, -2.9141, -2.9687, -3.0667, -2.8211, -2.8227, -2.9202, -2.9985, -2.9633, -3.0585, -2.944, -2.9287, -2.9108, -2.6999]}, "token.table": {"Topic": [1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 6, 1, 2, 3, 4, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 6, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7, 1, 2, 3, 4, 7], "Freq": [0.16323943171679015, 0.38089200733917705, 0.05441314390559672, 0.05441314390559672, 0.38089200733917705, 0.13914707236048748, 0.13914707236048748, 0.13914707236048748, 0.13914707236048748, 0.5565882894419499, 0.42819189013234127, 0.4721842076116914, 0.011731284661160035, 0.011731284661160035, 0.07038770796696021, 0.0029328211652900086, 0.0029328211652900086, 0.10663417520454764, 0.10663417520454764, 0.15995126280682145, 0.6220326886931946, 0.17370102351914166, 0.052110307055742495, 0.729544298780395, 0.03474020470382833, 0.5547784838272108, 0.16841489687611758, 0.029720275919314865, 0.0891608277579446, 0.009906758639771621, 0.04953379319885811, 0.0891608277579446, 0.1516057928568606, 0.0758028964284303, 0.0758028964284303, 0.0758028964284303, 0.6822260678558727, 0.3137264194658274, 0.4338769630910379, 0.006675030201400583, 0.010012545302100875, 0.23696357214972072, 0.0033375151007002915, 0.0033375151007002915, 0.056358446528501825, 0.056358446528501825, 0.056358446528501825, 0.7890182513990255, 0.2771160334741868, 0.5080460613693424, 0.10226901235356893, 0.05938200717304003, 0.0032990003985022237, 0.03628900438352446, 0.013196001594008895, 0.17894424491782096, 0.7483122969290695, 0.03253531725778563, 0.016267658628892814, 0.016267658628892814, 0.42043324716223957, 0.2714905273155269, 0.1545987724991195, 0.11500640393227181, 0.013197456188949224, 0.020738859725491637, 0.005656052652406811, 0.2446714075247497, 0.319954917532365, 0.3262285433663329, 0.07214669709063132, 0.00313681291698397, 0.01254725166793588, 0.02195769041888779, 0.2087950194460145, 0.06959833981533817, 0.0869979247691727, 0.31319252916902174, 0.2957929442151872, 0.017399584953834542, 0.545787782529805, 0.2171819895879847, 0.06043324927665661, 0.15297166223153705, 0.013219773279268633, 0.003777078079791038, 0.003777078079791038, 0.7920149353279577, 0.0384007241371131, 0.02400045258569569, 0.13440253447989586, 0.004800090517139138, 0.004800090517139138, 0.004800090517139138, 0.3085670431939929, 0.22441239505017668, 0.042077324071908125, 0.15428352159699646, 0.28051549381272084, 0.4622359522841079, 0.17564966186796102, 0.009244719045682158, 0.03697887618272863, 0.009244719045682158, 0.30507572850751125, 0.030282319045104235, 0.09084695713531271, 0.030282319045104235, 0.030282319045104235, 0.8176226142178143, 0.12691572301131115, 0.12691572301131115, 0.44420503053958904, 0.06345786150565558, 0.2538314460226223, 0.030252019849129824, 0.030252019849129824, 0.030252019849129824, 0.9075605954738947, 0.04101814798677287, 0.9160719717045941, 0.013672715995590957, 0.013672715995590957, 0.013672715995590957, 0.47509249609823284, 0.2949920727407328, 0.055893234835086215, 0.1412856769442457, 0.012420718852241382, 0.0077629492826508635, 0.01086812899571121, 0.09805157738828991, 0.09805157738828991, 0.09805157738828991, 0.09805157738828991, 0.5883094643297395, 0.7060704586461022, 0.06671531892719075, 0.01111921982119846, 0.18346712704977458, 0.016678829731797688, 0.01111921982119846, 0.00555960991059923, 0.20053061475164274, 0.20053061475164274, 0.10026530737582137, 0.10026530737582137, 0.5013265368791069, 0.24371329798543528, 0.12185664899271764, 0.12185664899271764, 0.12185664899271764, 0.48742659597087057, 0.04385980373452557, 0.04385980373452557, 0.04385980373452557, 0.8333362709559858, 0.08718662447524018, 0.08718662447524018, 0.08718662447524018, 0.08718662447524018, 0.6974929958019215, 0.18067363623254165, 0.18067363623254165, 0.18067363623254165, 0.18067363623254165, 0.3613472724650833, 0.34194427732564436, 0.21224127558143444, 0.09432945581397086, 0.17686772965119535, 0.011791181976746357, 0.15328536569770265, 0.011791181976746357, 0.09955844253858788, 0.04977922126929394, 0.04977922126929394, 0.2488961063464697, 0.5475714339622333, 0.028491498543565315, 0.8628853844622638, 0.0976851378636525, 0.008140428155304375, 0.004070214077652188, 0.3577321205864632, 0.06589802221329585, 0.06589802221329585, 0.49894216818638293, 0.00941400317332798, 0.051843725449159155, 0.051843725449159155, 0.8294996071865465, 0.051843725449159155, 0.1139209506232884, 0.7974466543630188, 0.0379736502077628, 0.0379736502077628, 0.10611306922499467, 0.7574277699853067, 0.10611306922499467, 0.021954428115516136, 0.0073181427051720455, 0.0036590713525860227, 0.3349636281125175, 0.0669927256225035, 0.0669927256225035, 0.0669927256225035, 0.40195635373502103, 0.03349636281125175, 0.20851882059165885, 0.03791251283484706, 0.07582502566969412, 0.5497314361052824, 0.13269379492196473, 0.051727695119185305, 0.8276431219069649, 0.051727695119185305, 0.051727695119185305, 0.049525157945178346, 0.8419276850680318, 0.049525157945178346, 0.049525157945178346, 0.023272349413213135, 0.023272349413213135, 0.023272349413213135, 0.8843492777020991, 0.2811332828466266, 0.4151313896239907, 0.21019310867037502, 0.055175691025973445, 0.007882241575139063, 0.023646724725417193, 0.005254827716759376, 0.17832469883728924, 0.08916234941864462, 0.08916234941864462, 0.08916234941864462, 0.6241364459305124, 0.16998147812831785, 0.16998147812831785, 0.16998147812831785, 0.16998147812831785, 0.3399629562566357, 0.2453939601041887, 0.2453939601041887, 0.2453939601041887, 0.2453939601041887, 0.2453939601041887, 0.046060059265472506, 0.046060059265472506, 0.829081066778505, 0.046060059265472506, 0.09836301368803917, 0.04918150684401958, 0.7869041095043133, 0.04918150684401958, 0.048015488891204446, 0.11593717135461666, 0.8167008099103042, 0.015859330043791902, 0.0009843722096146697, 0.002296868489100896, 0.00021874937991437106, 0.1600545158399193, 0.1600545158399193, 0.1600545158399193, 0.1600545158399193, 0.480163547519758, 0.18348065238848627, 0.12232043492565751, 0.6727623920911163, 0.01529005436570719, 0.40966883982486246, 0.19751890491555868, 0.17191460242650478, 0.11339048245152443, 0.025604302489053904, 0.08047066496559799, 0.42942232365897376, 0.1263006834291099, 0.06315034171455496, 0.20208109348657588, 0.012630068342910993, 0.1641908884578429, 0.26456434157835024, 0.03307054269729378, 0.1818879848351158, 0.3141701556242909, 0.01653527134864689, 0.21495852753240957, 0.10653169509864138, 0.10653169509864138, 0.10653169509864138, 0.10653169509864138, 0.5326584754932069, 0.18450812066739747, 0.5175227774817246, 0.04050178258552627, 0.24301069551315765, 0.013500594195175424, 0.004500198065058475, 0.1370001926867491, 0.1370001926867491, 0.1370001926867491, 0.1370001926867491, 0.5480007707469964, 0.05428320585117999, 0.05428320585117999, 0.05428320585117999, 0.8142480877676997, 0.9394282666355613, 0.01842016209089336, 0.01842016209089336, 0.01842016209089336, 0.944094394283253, 0.020087114771984108, 0.020087114771984108, 0.020087114771984108, 0.1180714480811677, 0.2361428961623354, 0.1180714480811677, 0.1180714480811677, 0.35421434424350307, 0.8857473772474218, 0.02952491257491406, 0.02952491257491406, 0.02952491257491406, 0.02952491257491406, 0.04782712722855407, 0.9087154173425274, 0.023913563614277034, 0.023913563614277034, 0.049536556448444014, 0.8421214596235482, 0.049536556448444014, 0.049536556448444014, 0.2805647796197672, 0.2805647796197672, 0.3218243060344389, 0.07839310018787614, 0.012377857924401495, 0.004125952641467165, 0.020629763207335828, 0.45093446249004193, 0.2494531069093849, 0.06716045186021902, 0.1439152539861836, 0.019188700531491146, 0.0719576269930918, 0.0047971751328727864, 0.11492722557316758, 0.11492722557316758, 0.11492722557316758, 0.11492722557316758, 0.5746361278658378, 0.1549922128893539, 0.1549922128893539, 0.03444271397541197, 0.3788698537295317, 0.20665628385247184, 0.017221356987705987, 0.05166407096311796, 0.1262336916546263, 0.1262336916546263, 0.1262336916546263, 0.1262336916546263, 0.5049347666185052, 0.15989356462358764, 0.2664892743726461, 0.4416107975318135, 0.068525813410109, 0.007613979267789888, 0.030455917071159553, 0.022841937803369662, 0.08969103245064125, 0.08969103245064125, 0.08969103245064125, 0.08969103245064125, 0.71752825960513, 0.8921362419452992, 0.02623930123368527, 0.02623930123368527, 0.02623930123368527, 0.02623930123368527, 0.1355314292136237, 0.1355314292136237, 0.1355314292136237, 0.1355314292136237, 0.4065942876408711, 0.09030790203704825, 0.09030790203704825, 0.27092370611114475, 0.09030790203704825, 0.4515395101852413, 0.10204492471164356, 0.8163593976931485, 0.02551123117791089, 0.02551123117791089, 0.04749990558198245, 0.8549983004756841, 0.04749990558198245, 0.04749990558198245, 0.058150033841623774, 0.058150033841623774, 0.8141004737827329, 0.058150033841623774, 0.8815979460402645, 0.03673324775167769, 0.03673324775167769, 0.03673324775167769, 0.06991805098671545, 0.03495902549335773, 0.8390166118405855, 0.03495902549335773, 0.24597954322120105, 0.24597954322120105, 0.24597954322120105, 0.24597954322120105, 0.24597954322120105, 0.43672637644211754, 0.2683155515396016, 0.019980945327417142, 0.23120808164582693, 0.017126524566357552, 0.025689786849536326, 0.0028544207610595915, 0.32903214575142187, 0.41862010622829415, 0.09936119252889472, 0.12705201667629162, 0.013030976069363242, 0.006515488034681621, 0.0048866160260112165, 0.1806775072259798, 0.1806775072259798, 0.1806775072259798, 0.1806775072259798, 0.3613550144519596, 0.8052209172607853, 0.06787302750857194, 0.018510825684155983, 0.1018095412628579, 0.003085137614025997, 0.003085137614025997, 0.13533319877912228, 0.13533319877912228, 0.13533319877912228, 0.13533319877912228, 0.5413327951164891, 0.8958279347226503, 0.015716279556537725, 0.015716279556537725, 0.03143255911307545, 0.015716279556537725, 0.015716279556537725, 0.9136305555230265, 0.031504501914587126, 0.031504501914587126, 0.031504501914587126, 0.23872155156403055, 0.6735358061985147, 0.05968038789100764, 0.017051539397430752, 0.008525769698715376, 0.05969952014805597, 0.8357932820727836, 0.05969952014805597, 0.05969952014805597, 0.904353065579571, 0.03617412262318284, 0.01808706131159142, 0.01808706131159142, 0.01808706131159142, 0.3305064055742594, 0.04131330069678243, 0.08262660139356486, 0.12393990209034729, 0.3718197062710418, 0.9593735448258711, 0.006852668177327651, 0.013705336354655302, 0.006852668177327651, 0.21484243975889755, 0.46704878208455985, 0.12143268334198556, 0.09340975641691197, 0.009340975641691198, 0.08406878077522077, 0.18269325228379363, 0.36538650456758726, 0.09134662614189681, 0.09134662614189681, 0.36538650456758726, 0.13083577491835616, 0.13083577491835616, 0.13083577491835616, 0.13083577491835616, 0.3925073247550685, 0.13671887655999068, 0.13671887655999068, 0.13671887655999068, 0.13671887655999068, 0.4101566296799721, 0.48779413768692703, 0.29080035131336035, 0.04690328246989683, 0.04690328246989683, 0.009380656493979365, 0.12194853442173176, 0.009380656493979365, 0.045551634132741256, 0.045551634132741256, 0.045551634132741256, 0.8654810485220839, 0.34967959515408165, 0.342686003251, 0.17483979757704082, 0.10024148394417008, 0.0209807757092449, 0.006993591903081633, 0.004662394602054422, 0.07862581140909253, 0.15725162281818506, 0.15725162281818506, 0.07862581140909253, 0.5503806798636477, 0.1491814051205109, 0.1491814051205109, 0.1491814051205109, 0.1491814051205109, 0.44754421536153266, 0.2454037481386688, 0.2454037481386688, 0.2454037481386688, 0.2454037481386688, 0.2454037481386688, 0.1791591145014591, 0.1791591145014591, 0.1791591145014591, 0.1791591145014591, 0.3583182290029182, 0.8930070389932827, 0.02413532537819683, 0.02413532537819683, 0.02413532537819683, 0.044272515255886866, 0.044272515255886866, 0.044272515255886866, 0.8411777898618505, 0.04417540355357624, 0.04417540355357624, 0.04417540355357624, 0.8393326675179485, 0.058346225229187254, 0.058346225229187254, 0.058346225229187254, 0.058346225229187254, 0.7585009279794344, 0.24539741816162652, 0.24539741816162652, 0.24539741816162652, 0.24539741816162652, 0.24539741816162652, 0.24539116523266075, 0.24539116523266075, 0.24539116523266075, 0.24539116523266075, 0.24539116523266075, 0.5366741468173959, 0.060985698501976805, 0.24394279400790722, 0.01219713970039536, 0.12197139700395361, 0.6872262246134135, 0.09203922651072502, 0.030679742170241674, 0.006135948434048335, 0.14726276241716005, 0.03681569060429001, 0.2845921250708517, 0.0948640416902839, 0.0948640416902839, 0.0948640416902839, 0.3794561667611356, 0.8905882336762049, 0.0356235293470482, 0.0356235293470482, 0.0356235293470482, 0.947448284454705, 0.014576127453149307, 0.014576127453149307, 0.014576127453149307, 0.3064540533795837, 0.2681472967071357, 0.2936851344887677, 0.07661351334489593, 0.0042563062969386625, 0.012768918890815988, 0.0340504503755093, 0.17284408053190684, 0.17284408053190684, 0.17284408053190684, 0.17284408053190684, 0.34568816106381367, 0.04982398430498246, 0.8470077331847018, 0.04982398430498246, 0.04982398430498246, 0.24597995157679173, 0.24597995157679173, 0.24597995157679173, 0.24597995157679173, 0.24597995157679173, 0.1837209173523671, 0.5919896225798494, 0.08675709986084001, 0.07655038223015295, 0.03062015289206118, 0.03062015289206118, 0.00510335881534353, 0.24407041094385193, 0.12203520547192596, 0.12203520547192596, 0.12203520547192596, 0.48814082188770386, 0.2127121490655503, 0.10635607453277515, 0.10635607453277515, 0.10635607453277515, 0.5317803726638758, 0.10245468523475515, 0.10245468523475515, 0.30736405570426545, 0.10245468523475515, 0.4098187409390206, 0.35897892983879004, 0.18567875681316728, 0.18567875681316728, 0.2599502595384342, 0.004951433515017794, 0.002475716757508897, 0.002475716757508897, 0.12898929839103196, 0.12898929839103196, 0.12898929839103196, 0.12898929839103196, 0.5159571935641278, 0.37512866123705013, 0.21059854665939656, 0.21717975124250272, 0.11846168249591056, 0.006581204583106143, 0.06581204583106143, 0.5178685783697474, 0.2224646709898211, 0.11852625913392108, 0.11670277822416844, 0.010940885458515792, 0.0036469618195052638, 0.009117404548763159, 0.887939756358731, 0.030618612288232105, 0.030618612288232105, 0.030618612288232105, 0.05232432100135425, 0.05232432100135425, 0.05232432100135425, 0.837189136021668, 0.2453905283066154, 0.2453905283066154, 0.2453905283066154, 0.2453905283066154, 0.2453905283066154, 0.24539382881928867, 0.24539382881928867, 0.24539382881928867, 0.24539382881928867, 0.24539382881928867, 0.35561412334621423, 0.3493752790769824, 0.15597110673079573, 0.10606035257694109, 0.006238844269231829, 0.018716532807695488, 0.006238844269231829, 0.0751807265407112, 0.8269879919478232, 0.050120484360474137, 0.025060242180237068, 0.07630625064140811, 0.8012156317347852, 0.03815312532070406, 0.03815312532070406, 0.03815312532070406, 0.8691964620323961, 0.059944583588441104, 0.029972291794220552, 0.029972291794220552, 0.25120035543333474, 0.12560017771666737, 0.12560017771666737, 0.12560017771666737, 0.3768005331500021, 0.10664472363270923, 0.10664472363270923, 0.10664472363270923, 0.10664472363270923, 0.6398683417962554, 0.04181987521834338, 0.04181987521834338, 0.8782173795852108, 0.04181987521834338, 0.24539244553999462, 0.24539244553999462, 0.24539244553999462, 0.24539244553999462, 0.24539244553999462, 0.3692676429599835, 0.3680449024203809, 0.1980839674156203, 0.05013236212370637, 0.003668221618807783, 0.007336443237615566, 0.0024454810792051886, 0.26612742823665786, 0.2381140147380623, 0.35016766873244454, 0.028013413498595565, 0.09804694724508448, 0.11100003305539717, 0.11100003305539717, 0.11100003305539717, 0.11100003305539717, 0.5550001652769858, 0.24476502004944664, 0.24476502004944664, 0.24476502004944664, 0.24476502004944664, 0.24476502004944664, 0.24539496393013024, 0.24539496393013024, 0.24539496393013024, 0.24539496393013024, 0.24539496393013024, 0.34663455779036745, 0.1713251262642046, 0.12351346312070564, 0.3346816420044927, 0.007968610523916493, 0.01195291578587474, 0.8768135409936161, 0.06494915118471231, 0.032474575592356156, 0.032474575592356156, 0.37324884044871753, 0.3297635386488669, 0.13951534327452061, 0.12139646752458289, 0.010871325449962646, 0.021742650899925293, 0.003623775149987549, 0.018804768600468202, 0.26326676040655483, 0.037609537200936405, 0.6769716696168553, 0.5560269630361423, 0.252739528652792, 0.02695888305629781, 0.03706846420240949, 0.11794511337130291, 0.006739720764074452, 0.003369860382037226, 0.2453980283754639, 0.2453980283754639, 0.2453980283754639, 0.2453980283754639, 0.2453980283754639, 0.7078003004416699, 0.2278535213750581, 0.043631525369691976, 0.014543841789897326, 0.004847947263299109, 0.004847947263299109, 0.03226536652662704, 0.03226536652662704, 0.03226536652662704, 0.9034302627455569, 0.4086460667051627, 0.202739133869228, 0.101369566934614, 0.2787663090701885, 0.006335597933413375, 0.0031677989667066877, 0.17601238801173863, 0.11734159200782575, 0.11734159200782575, 0.11734159200782575, 0.41069557202739015, 0.11888901834413762, 0.5944450917206882, 0.14686290501334648, 0.07692818834032435, 0.006993471667302214, 0.034967358336511066, 0.027973886669208855, 0.24539797820107473, 0.24539797820107473, 0.24539797820107473, 0.24539797820107473, 0.24539797820107473, 0.0944447158345318, 0.0944447158345318, 0.0944447158345318, 0.0944447158345318, 0.5666682950071908, 0.11007566429170028, 0.11007566429170028, 0.11007566429170028, 0.11007566429170028, 0.5503783214585014, 0.07038172099353636, 0.07038172099353636, 0.35190860496768184, 0.07038172099353636, 0.4222903259612182, 0.8886091963363555, 0.013884518692755555, 0.041653556078266665, 0.041653556078266665, 0.2654050296219936, 0.05308100592439872, 0.05308100592439872, 0.2654050296219936, 0.3184860355463923, 0.04612819381807122, 0.04612819381807122, 0.8303074887252819, 0.04612819381807122, 0.19496556914127713, 0.16247130761773093, 0.06498852304709238, 0.12997704609418476, 0.42242539980610044, 0.03249426152354619, 0.24540163369753049, 0.24540163369753049, 0.24540163369753049, 0.24540163369753049, 0.24540163369753049, 0.048960050596571415, 0.9057609360365712, 0.024480025298285708, 0.024480025298285708, 0.09484010806987021, 0.04742005403493511, 0.8061409185938968, 0.04742005403493511, 0.02677553115857385, 0.013387765579286925, 0.013387765579286925, 0.9371435905500848, 0.013387765579286925, 0.05428945228433064, 0.05428945228433064, 0.05428945228433064, 0.8143417842649595, 0.04565349736184592, 0.04565349736184592, 0.04565349736184592, 0.8674164498750725, 0.3845158700594686, 0.2620152388900804, 0.1463201983412137, 0.14291740303095293, 0.03743074841286862, 0.01701397655130392, 0.0068055906205215675, 0.04817348180064031, 0.04817348180064031, 0.8189491906108852, 0.04817348180064031, 0.04817348180064031, 0.24598030113790248, 0.24598030113790248, 0.24598030113790248, 0.24598030113790248, 0.24598030113790248, 0.24528609947292537, 0.08760217838318762, 0.5956948130056758, 0.05256130702991258, 0.017520435676637525, 0.017520435676637525, 0.05683023402384883, 0.7956232763338836, 0.05683023402384883, 0.05683023402384883, 0.02191760923094678, 0.02191760923094678, 0.02191760923094678, 0.9205395876997647, 0.2453900208948128, 0.2453900208948128, 0.2453900208948128, 0.2453900208948128, 0.2453900208948128, 0.4611946625176601, 0.09114519022088145, 0.010937422826505774, 0.4101533559939665, 0.01640613423975866, 0.003645807608835258, 0.007291615217670516, 0.05262030442755252, 0.05262030442755252, 0.05262030442755252, 0.7893045664132878, 0.05262030442755252, 0.15119557776716672, 0.15119557776716672, 0.15119557776716672, 0.15119557776716672, 0.15119557776716672, 0.30239115553433343, 0.41593342540684664, 0.07869010750940342, 0.3822090936171023, 0.10791786172718182, 0.004496577571965909, 0.004496577571965909, 0.004496577571965909, 0.06053679445920239, 0.12107358891840478, 0.030268397229601195, 0.030268397229601195, 0.7567099307400299, 0.128812365420144, 0.128812365420144, 0.128812365420144, 0.128812365420144, 0.515249461680576, 0.18064935312294467, 0.18064935312294467, 0.18064935312294467, 0.18064935312294467, 0.36129870624588933, 0.7576880653347873, 0.14597659974339938, 0.04170759992668554, 0.013902533308895178, 0.02085379996334277, 0.013902533308895178, 0.006951266654447589, 0.0504420579294176, 0.0504420579294176, 0.0504420579294176, 0.8070729268706816, 0.056416405982817296, 0.056416405982817296, 0.056416405982817296, 0.7898296837594422, 0.244774844991224, 0.244774844991224, 0.244774844991224, 0.244774844991224, 0.244774844991224, 0.2453992932426182, 0.2453992932426182, 0.2453992932426182, 0.2453992932426182, 0.2453992932426182, 0.24598147894488187, 0.24598147894488187, 0.24598147894488187, 0.24598147894488187, 0.24598147894488187, 0.1662151642718167, 0.3601328559222695, 0.08310758213590835, 0.1662151642718167, 0.027702527378636117, 0.1939176916504528, 0.18023915245148817, 0.18023915245148817, 0.18023915245148817, 0.18023915245148817, 0.36047830490297633, 0.2459795169174396, 0.2459795169174396, 0.2459795169174396, 0.2459795169174396, 0.2459795169174396, 0.19930517024382358, 0.17605290038204416, 0.023252269861779418, 0.5646979823575001, 0.009965258512191178, 0.029895775536573535, 0.05425505676799952, 0.05425505676799952, 0.05425505676799952, 0.8138258515199929, 0.2356513113384853, 0.1413907868030912, 0.04713026226769706, 0.18852104907078823, 0.04713026226769706, 0.2827815736061824, 0.04713026226769706, 0.396168101401503, 0.03212173795147321, 0.12848695180589284, 0.17131593574119047, 0.2676811495956101, 0.12019075423138034, 0.12019075423138034, 0.12019075423138034, 0.12019075423138034, 0.48076301692552137, 0.9618396610682904, 0.017023710815367972, 0.008511855407683986, 0.008511855407683986, 0.8992383288616514, 0.02900768802779521, 0.02900768802779521, 0.02900768802779521, 0.2459797710822559, 0.2459797710822559, 0.2459797710822559, 0.2459797710822559, 0.2459797710822559, 0.8783397719056233, 0.014109875853905596, 0.010582406890429196, 0.08818672408690997, 0.003527468963476399, 0.003527468963476399, 0.09542333843105753, 0.09542333843105753, 0.09542333843105753, 0.09542333843105753, 0.5725400305863452, 0.6502440545394774, 0.17946483137921437, 0.07393445518087353, 0.07962172096401765, 0.013270286827336275, 0.0018957552610480394, 0.0018957552610480394, 0.6203929799065895, 0.14812753733724748, 0.1063032915008482, 0.10456061459099823, 0.017426769098499707, 0.0017426769098499704, 0.0017426769098499704, 0.16490083607548067, 0.5679917687044335, 0.1603202572956062, 0.0870309968176148, 0.004580578779874463, 0.009161157559748926, 0.004580578779874463, 0.24598279057058056, 0.24598279057058056, 0.24598279057058056, 0.24598279057058056, 0.24598279057058056, 0.27213156979504044, 0.3688894612777215, 0.3023684108833783, 0.04535526163250674, 0.0030236841088337827, 0.006047368217667565, 0.0030236841088337827, 0.04316354238383334, 0.04316354238383334, 0.8632708476766668, 0.04316354238383334, 0.45825612806446875, 0.057282016008058594, 0.057282016008058594, 0.057282016008058594, 0.34369209604835155, 0.057282016008058594, 0.24539955614372588, 0.24539955614372588, 0.24539955614372588, 0.24539955614372588, 0.24539955614372588, 0.2454061540071052, 0.2454061540071052, 0.2454061540071052, 0.2454061540071052, 0.2454061540071052, 0.2459805576631817, 0.2459805576631817, 0.2459805576631817, 0.2459805576631817, 0.2459805576631817, 0.36004466632057464, 0.3566480185250975, 0.16643574197837882, 0.06453630811406526, 0.047553069136679664, 0.003396647795477119, 0.003396647795477119, 0.037276255244769296, 0.037276255244769296, 0.037276255244769296, 0.037276255244769296, 0.8200776153849244, 0.037276255244769296, 0.1446708543308192, 0.1446708543308192, 0.1446708543308192, 0.1446708543308192, 0.4340125629924576, 0.18221526446350453, 0.37093821694356277, 0.24729214462904187, 0.14967682438073587, 0.006507688016553733, 0.028199981405066177, 0.01518460537195871, 0.40115281221674964, 0.06685880203612495, 0.06685880203612495, 0.06685880203612495, 0.4680116142528746, 0.8968869970219926, 0.0344956537316151, 0.0344956537316151, 0.0344956537316151, 0.23812801067889408, 0.30878137648471976, 0.08897090508881757, 0.13607314895936803, 0.002616791326141693, 0.2224272627220439, 0.002616791326141693, 0.21532007151192245, 0.04485834823165051, 0.5831585270114567, 0.11663170540229133, 0.04485834823165051, 0.9646894277929043, 0.009457739488165728, 0.009457739488165728, 0.009457739488165728, 0.4114528105479401, 0.3162659663167002, 0.07778709851155086, 0.16683285601819461, 0.011258658995092888, 0.0020470289081987066, 0.014329202357390948, 0.24539241532415362, 0.24539241532415362, 0.24539241532415362, 0.24539241532415362, 0.24539241532415362, 0.0917261483682778, 0.0917261483682778, 0.3669045934731112, 0.0917261483682778, 0.3669045934731112, 0.12414130287796103, 0.12414130287796103, 0.12414130287796103, 0.24828260575592206, 0.3724239086338831, 0.040556118256014816, 0.040556118256014816, 0.8516784833763111, 0.040556118256014816, 0.18259605258841335, 0.7532087169272051, 0.02282450657355167, 0.02282450657355167, 0.04950488828069029, 0.8415831007717348, 0.04950488828069029, 0.04950488828069029, 0.16953667215496504, 0.16953667215496504, 0.16953667215496504, 0.16953667215496504, 0.3390733443099301, 0.042936935776158994, 0.08587387155231799, 0.8158017797470208, 0.042936935776158994, 0.10169876672621846, 0.10169876672621846, 0.10169876672621846, 0.10169876672621846, 0.6101926003573107, 0.2447766069076294, 0.2447766069076294, 0.2447766069076294, 0.2447766069076294, 0.2447766069076294, 0.013590998993273363, 0.013590998993273363, 0.013590998993273363, 0.9513699295291355, 0.04872093433991724, 0.04872093433991724, 0.04872093433991724, 0.828255883778593, 0.38681434735097203, 0.30535135369686217, 0.11329290508187466, 0.17965017805840122, 0.010789800483988062, 0.0016184700725982092, 0.0026974501209970155, 0.0951484929349476, 0.0237871232337369, 0.0237871232337369, 0.8563364364145284, 0.016691402327336156, 0.03338280465467231, 0.03338280465467231, 0.9013357256761524, 0.07607232209938297, 0.786080661693624, 0.07607232209938297, 0.05071488139958865, 0.019795960763074768, 0.8314303520491403, 0.11877576457844861, 0.019795960763074768, 0.8799507060519112, 0.04399753530259556, 0.04399753530259556, 0.04399753530259556, 0.07090410887334335, 0.07090410887334335, 0.07090410887334335, 0.07090410887334335, 0.7090410887334335, 0.24539346791786265, 0.24539346791786265, 0.24539346791786265, 0.24539346791786265, 0.24539346791786265, 0.1197938521525185, 0.1197938521525185, 0.1197938521525185, 0.1197938521525185, 0.479175408610074, 0.8556116765016534, 0.0407434131667454, 0.0407434131667454, 0.0407434131667454, 0.03691615751789015, 0.8859877804293637, 0.03691615751789015, 0.03691615751789015, 0.7666785936884928, 0.06239413304265325, 0.09743741324469139, 0.06752241795026859, 0.0025641424538076683, 0.0025641424538076683, 0.0017094283025384453, 0.6880493387207157, 0.09288055016478577, 0.16620730029487982, 0.04521816258022465, 0.0024442250043364678, 0.0012221125021682339, 0.0024442250043364678, 0.4736514903908611, 0.019465129742090182, 0.48662824355225454, 0.012976753161393455, 0.006488376580696727, 0.006488376580696727, 0.1685138138436437, 0.1685138138436437, 0.1685138138436437, 0.1685138138436437, 0.3370276276872874, 0.17602278794319903, 0.37160366343564244, 0.3781230259520572, 0.04563553761490345, 0.006519362516414779, 0.026077450065659116, 0.25028988078523645, 0.4057729885457621, 0.26545896446919015, 0.06446860565680333, 0.003792270920988431, 0.007584541841976862, 0.24539535941231228, 0.24539535941231228, 0.24539535941231228, 0.24539535941231228, 0.24539535941231228, 0.28088323739459, 0.3608924019857762, 0.16001832918237247, 0.16001832918237247, 0.013618581207010422, 0.01872554915963933, 0.0051069679526289085, 0.20109387070994236, 0.10054693535497118, 0.10054693535497118, 0.10054693535497118, 0.502734676774856, 0.06016803996873437, 0.06016803996873437, 0.06016803996873437, 0.24067215987493748, 0.6016803996873437, 0.1039155432657268, 0.1039155432657268, 0.1039155432657268, 0.2078310865314536, 0.4156621730629072, 0.04007368235574946, 0.04007368235574946, 0.04007368235574946, 0.04007368235574946, 0.8415473294707386, 0.2235031497842216, 0.2578882497510249, 0.17192549983401662, 0.10315529990040997, 0.17192549983401662, 0.05157764995020499, 0.01719254998340166, 0.20833600082747658, 0.5533925021979846, 0.13997575055596082, 0.03580775014222254, 0.02278675009050525, 0.03255250012929321, 0.0032552500129293216, 0.01964013048155069, 0.9230861326328825, 0.01964013048155069, 0.01964013048155069, 0.3621948861144182, 0.38195097081156826, 0.1251218697486172, 0.08890238113717537, 0.0032926807828583472, 0.0065853615657166945, 0.032926807828583475, 0.14356702310427596, 0.04785567436809199, 0.04785567436809199, 0.04785567436809199, 0.7178351155213799, 0.09482175737339622, 0.04741087868669811, 0.8059849376738679, 0.04741087868669811, 0.24539389503093575, 0.24539389503093575, 0.24539389503093575, 0.24539389503093575, 0.24539389503093575, 0.5802455715880509, 0.0709189031940951, 0.29012278579402545, 0.041906624614692564, 0.009670759526467515, 0.003223586508822505, 0.00644717301764501, 0.13414307575738135, 0.13414307575738135, 0.13414307575738135, 0.13414307575738135, 0.5365723030295254, 0.4492101398189923, 0.20775968966628397, 0.061766394225111446, 0.17968405592759693, 0.022460506990949616, 0.08422690121606106, 0.005615126747737404, 0.1604165676354582, 0.1604165676354582, 0.1604165676354582, 0.1604165676354582, 0.48124970290637453, 0.07985687720451465, 0.039928438602257324, 0.7985687720451465, 0.039928438602257324, 0.039928438602257324, 0.29031574914978153, 0.2142806719915054, 0.16243857392904443, 0.11405261573741417, 0.0034561398708307326, 0.20391225237901323, 0.01382455948332293, 0.24539164192898447, 0.24539164192898447, 0.24539164192898447, 0.24539164192898447, 0.24539164192898447, 0.3981062229438773, 0.2853894007850687, 0.24941594690459784, 0.057557526208753346, 0.0023982302586980564, 0.0023982302586980564, 0.004796460517396113, 0.14167833673586516, 0.03541958418396629, 0.03541958418396629, 0.7438112678632921, 0.03541958418396629, 0.052261551595194446, 0.052261551595194446, 0.052261551595194446, 0.8361848255231111, 0.05340950840226651, 0.7858827664904929, 0.03814964885876179, 0.05340950840226651, 0.015259859543504718, 0.04577957863051415, 0.02524476813257199, 0.012622384066285994, 0.012622384066285994, 0.9466788049714495, 0.1182438681258757, 0.016891981160839387, 0.016891981160839387, 0.8277070768811299, 0.016891981160839387, 0.8009069032618907, 0.15402055831959438, 0.02310308374793916, 0.015402055831959438, 0.007701027915979719, 0.43358374533643573, 0.06670519159022088, 0.1834392768731074, 0.1667629789755522, 0.00833814894877761, 0.00833814894877761, 0.13341038318044177, 0.09282668630319554, 0.09282668630319554, 0.09282668630319554, 0.09282668630319554, 0.6497868041223688, 0.4746566119625479, 0.19597564660574893, 0.0970888524468848, 0.17799622948595545, 0.03775677595156631, 0.012585591983855436, 0.005393825135938044, 0.21767216437877152, 0.3420562583094981, 0.09328807044804494, 0.031096023482681645, 0.2798642113441348, 0.24539651014710123, 0.24539651014710123, 0.24539651014710123, 0.24539651014710123, 0.24539651014710123, 0.6029972059847842, 0.33628690333766814, 0.0038653667050306687, 0.013528783467607339, 0.03672098369779135, 0.0019326833525153343, 0.005798050057546003, 0.24539170596362744, 0.24539170596362744, 0.24539170596362744, 0.24539170596362744, 0.24539170596362744, 0.06082797409498486, 0.06082797409498486, 0.7907636632348032, 0.06082797409498486, 0.2590351169789036, 0.6090825723558003, 0.07000949107537935, 0.035004745537689674, 0.014001898215075869, 0.0070009491075379345, 0.09325530464753132, 0.04662765232376566, 0.04662765232376566, 0.7926700895040162, 0.05409853896819323, 0.8114780845228984, 0.05409853896819323, 0.05409853896819323, 0.18023156017966463, 0.18023156017966463, 0.18023156017966463, 0.18023156017966463, 0.36046312035932926, 0.15250632522569424, 0.37037250411954314, 0.23965279678323378, 0.13798191329943765, 0.0036311029815641483, 0.07988426559441127, 0.014524411926256593, 0.4115237076404507, 0.3518465536623793, 0.12432740412098209, 0.062163702060491044, 0.007459644247258926, 0.03356839911266516, 0.008702918288468746, 0.1877295881632051, 0.09386479408160255, 0.09386479408160255, 0.09386479408160255, 0.5631887644896153, 0.12528566927853002, 0.12528566927853002, 0.12528566927853002, 0.12528566927853002, 0.5011426771141201, 0.24598221892380956, 0.24598221892380956, 0.24598221892380956, 0.24598221892380956, 0.24598221892380956, 0.3489050805094721, 0.17253547937281588, 0.16870135760897553, 0.19170608819201765, 0.0038341217638403527, 0.10735540938752988, 0.011502365291521058, 0.47060204662001237, 0.2226504306589306, 0.07337343737623848, 0.20240948241720963, 0.012650592651075602, 0.010120474120860482, 0.005060237060430241, 0.2459789844115769, 0.2459789844115769, 0.2459789844115769, 0.2459789844115769, 0.2459789844115769, 0.06684324445380038, 0.06684324445380038, 0.8021189334456046, 0.06684324445380038, 0.0495108443620074, 0.8416843541541258, 0.0495108443620074, 0.0495108443620074, 0.2755829880495352, 0.031798037082638675, 0.010599345694212892, 0.6571594330411993, 0.010599345694212892, 0.25561782676115125, 0.12780891338057562, 0.07518171375327978, 0.1804361130078715, 0.338317711889759, 0.015036342750655957, 0.0075181713753279785, 0.24539963846387763, 0.24539963846387763, 0.24539963846387763, 0.24539963846387763, 0.24539963846387763, 0.028789876034465704, 0.23031900827572563, 0.3166886363791227, 0.11515950413786281, 0.287898760344657, 0.23599691721934407, 0.06436279560527565, 0.6221736908509979, 0.05363566300439638, 0.010727132600879275, 0.053431249777879226, 0.053431249777879226, 0.8014687466681883, 0.053431249777879226, 0.13508473654906616, 0.13508473654906616, 0.13508473654906616, 0.13508473654906616, 0.5403389461962647, 0.3183764979011214, 0.14150066573383174, 0.05895861072242989, 0.3655433864790653, 0.035375166433457936, 0.08254205501140184, 0.017959981302297767, 0.8306491352312718, 0.13020986444165883, 0.004489995325574442, 0.013469985976723326, 0.24539362804423123, 0.24539362804423123, 0.24539362804423123, 0.24539362804423123, 0.24539362804423123, 0.803142051395567, 0.13166263137632248, 0.006583131568816123, 0.013166263137632247, 0.03291565784408062, 0.006583131568816123, 0.19961861686952495, 0.6653953895650832, 0.04435969263767221, 0.022179846318836106, 0.05544961579709026, 0.011089923159418053, 0.8796664602055396, 0.026656559400167867, 0.026656559400167867, 0.026656559400167867, 0.026656559400167867, 0.7668721038573966, 0.06851778247523131, 0.02635299325970435, 0.12912966697255132, 0.00527059865194087, 0.002635299325970435, 0.002635299325970435, 0.023444763152998132, 0.9143457629669272, 0.023444763152998132, 0.023444763152998132, 0.3931919794333522, 0.27352485525798415, 0.09402416899493204, 0.13676242762899207, 0.01709530345362401, 0.07692886554130804, 0.008547651726812005, 0.019685937301180095, 0.019685937301180095, 0.9252390531554644, 0.019685937301180095, 0.045620173079622905, 0.8667832885128351, 0.045620173079622905, 0.045620173079622905, 0.24539640917382533, 0.24539640917382533, 0.24539640917382533, 0.24539640917382533, 0.24539640917382533, 0.21484307457256094, 0.0460378016941202, 0.015345933898040067, 0.7059129593098431, 0.2978902083055685, 0.3140934413933191, 0.19942440723385338, 0.1533075130610248, 0.00997122036169267, 0.01994244072338534, 0.004985610180846335, 0.24598300198587916, 0.24598300198587916, 0.24598300198587916, 0.24598300198587916, 0.24598300198587916, 0.0373735296886714, 0.06228921614778567, 0.0373735296886714, 0.7225549073143137, 0.012457843229557133, 0.012457843229557133, 0.1121205890660142, 0.07809744664612475, 0.07809744664612475, 0.026032482215374915, 0.7289095020304976, 0.026032482215374915, 0.05206496443074983, 0.25111551001023374, 0.22600395900921036, 0.17578085700716362, 0.10044620400409349, 0.25111551001023374, 0.03255801034512226, 0.03255801034512226, 0.01627900517256113, 0.03255801034512226, 0.8953452844908623, 0.01627900517256113, 0.45863536732594745, 0.24280695917256043, 0.0067446377547933445, 0.026978551019173378, 0.26304087243694046, 0.05249642474445767, 0.05249642474445767, 0.47246782270011906, 0.05249642474445767, 0.3674749732112037, 0.09571815317968455, 0.015953025529947425, 0.8455103530872136, 0.015953025529947425, 0.9189836082467859, 0.01801928643621149, 0.01801928643621149, 0.01801928643621149, 0.01801928643621149, 0.9112489567234989, 0.03438675308390562, 0.01719337654195281, 0.01719337654195281, 0.01719337654195281, 0.09891391670959206, 0.09891391670959206, 0.09891391670959206, 0.09891391670959206, 0.09891391670959206, 0.49456958354796027, 0.049529328445488095, 0.049529328445488095, 0.049529328445488095, 0.049529328445488095, 0.049529328445488095, 0.7429399266823214, 0.07528231914936459, 0.803011404259889, 0.050188212766243065, 0.050188212766243065, 0.025094106383121532, 0.16853054778125065, 0.16853054778125065, 0.16853054778125065, 0.16853054778125065, 0.3370610955625013, 0.44635260017972134, 0.3198559118696789, 0.1264966883100425, 0.08312639517517077, 0.012649668831004249, 0.009035477736431607, 0.0036141910945726424, 0.12879501443252567, 0.12879501443252567, 0.12879501443252567, 0.12879501443252567, 0.5151800577301027, 0.245981389713167, 0.245981389713167, 0.245981389713167, 0.245981389713167, 0.245981389713167, 0.3448768948405386, 0.32688331771842355, 0.17693684170079807, 0.08696895609022277, 0.020992506642467566, 0.035987154244230116, 0.011995718081410037, 0.24539226124131702, 0.24539226124131702, 0.24539226124131702, 0.24539226124131702, 0.24539226124131702, 0.2454043362571296, 0.2454043362571296, 0.2454043362571296, 0.2454043362571296, 0.2454043362571296, 0.0312638958099426, 0.0156319479049713, 0.0156319479049713, 0.9379168742982779, 0.10114543888026972, 0.5483147476140938, 0.18632054530576003, 0.13308610378982857, 0.02661722075796572, 0.0053234441515931435, 0.31280490016831536, 0.41608016879531473, 0.1261149914964319, 0.11419861434716275, 0.014895471436586444, 0.010923345720163393, 0.003972125716423052, 0.040759012250687995, 0.8559392572644479, 0.040759012250687995, 0.040759012250687995, 0.9017736547814786, 0.016699512125582936, 0.016699512125582936, 0.05009853637674881, 0.3772546190343337, 0.2964143435269765, 0.1849527515395597, 0.09798821273619057, 0.02204734786564288, 0.008573968614416675, 0.01102367393282144, 0.3249690085998751, 0.07823327984811808, 0.3911663992405904, 0.17452039350734033, 0.006017944603701391, 0.01805383381110417, 0.22759623372958973, 0.3641539739673436, 0.022759623372958976, 0.1820769869836718, 0.011379811686479488, 0.1820769869836718, 0.011379811686479488, 0.2865929290246912, 0.1432964645123456, 0.1432964645123456, 0.1432964645123456, 0.2865929290246912, 0.1591458207558077, 0.07957291037790384, 0.07957291037790384, 0.07957291037790384, 0.5570103726453269, 0.9011140008053791, 0.02371352633698366, 0.02371352633698366, 0.04742705267396732, 0.02735264954338843, 0.02735264954338843, 0.02735264954338843, 0.9026374349318181, 0.2511598688252559, 0.3918093953673993, 0.13730072829113993, 0.1607423160481638, 0.0033487982510034126, 0.023441587757023888, 0.030139184259030713, 0.12903527408239168, 0.12903527408239168, 0.12903527408239168, 0.12903527408239168, 0.5161410963295667, 0.22580033803191682, 0.2919831957309269, 0.43992134823459655, 0.015572437105649435, 0.0038931092764123588, 0.015572437105649435, 0.0077862185528247176, 0.6511026509333413, 0.19909750483085642, 0.0753341910170808, 0.06457216372892641, 0.0026905068220386, 0.0026905068220386, 0.0053810136440772, 0.19588873731693654, 0.1335605027160931, 0.44520167572031033, 0.07123226811524964, 0.04452016757203103, 0.11575243568728068, 0.20141480423449537, 0.02237942269272171, 0.7385209488598165, 0.02237942269272171, 0.035248745751866546, 0.035248745751866546, 0.8812186437966636, 0.035248745751866546, 0.2453990044431102, 0.2453990044431102, 0.2453990044431102, 0.2453990044431102, 0.2453990044431102, 0.09872652095988563, 0.09872652095988563, 0.09872652095988563, 0.09872652095988563, 0.5923591257593138, 0.1398304243873286, 0.0699152121936643, 0.0699152121936643, 0.4544488792588179, 0.03495760609683215, 0.20974563658099288, 0.10252899682485854, 0.10252899682485854, 0.10252899682485854, 0.10252899682485854, 0.6151739809491512, 0.5084221306670222, 0.27763665838472207, 0.10584897600917528, 0.07287962282598955, 0.026028436723567694, 0.005205687344713539, 0.001735229114904513, 0.020938344442760496, 0.020938344442760496, 0.9212871554814619, 0.020938344442760496, 0.40216460840736223, 0.24063947880112657, 0.1977858729872273, 0.11867152379233639, 0.016482156082268943, 0.0032964312164537888, 0.02307501851517652, 0.03521540441631808, 0.03521540441631808, 0.8803851104079521, 0.03521540441631808, 0.2436479356667811, 0.6184909136156751, 0.11713843060902938, 0.009371074448722351, 0.0046855372243611755, 0.0046855372243611755, 0.15777083781106685, 0.15777083781106685, 0.15777083781106685, 0.15777083781106685, 0.4733125134332006, 0.17320425447986762, 0.17320425447986762, 0.17320425447986762, 0.17320425447986762, 0.34640850895973524, 0.24539676970057084, 0.24539676970057084, 0.24539676970057084, 0.24539676970057084, 0.24539676970057084, 0.13580947877466878, 0.49385265008970464, 0.08642421376569831, 0.12346316252242616, 0.1481557950269114, 0.11787919961063302, 0.11787919961063302, 0.11787919961063302, 0.11787919961063302, 0.5893959980531651, 0.15857309188832014, 0.15857309188832014, 0.15857309188832014, 0.15857309188832014, 0.15857309188832014, 0.3171461837766403, 0.039378357221487637, 0.039378357221487637, 0.8663238588727279, 0.039378357221487637, 0.0421362750168996, 0.0421362750168996, 0.842725500337992, 0.0421362750168996, 0.0421362750168996, 0.30930476496546067, 0.29641706642523313, 0.14820853321261657, 0.1417646839425028, 0.01933154781034129, 0.01933154781034129, 0.06443849270113765, 0.8788942086153351, 0.03138907887911911, 0.03138907887911911, 0.03138907887911911, 0.03138907887911911, 0.12887219624808666, 0.12887219624808666, 0.2577443924961733, 0.12887219624808666, 0.3866165887442599, 0.49838257422826115, 0.13488335724526335, 0.27205287308790405, 0.07315707511607503, 0.004572317194754689, 0.006858475792132034, 0.009144634389509378, 0.3987153548822887, 0.16127812107598194, 0.040319530268995485, 0.3449559811902947, 0.00895989561533233, 0.03583958246132932, 0.013439843422998496, 0.7290339338384879, 0.08842243256951958, 0.05954980152641114, 0.06496341984699398, 0.048722564885245484, 0.005413618320582831, 0.003609078880388554, 0.13921257614778362, 0.4625450110716681, 0.2739344240327355, 0.04939801089114902, 0.00898145652566346, 0.04939801089114902, 0.01796291305132692, 0.24477919231594839, 0.24477919231594839, 0.24477919231594839, 0.24477919231594839, 0.24477919231594839, 0.15912131915109146, 0.15912131915109146, 0.15912131915109146, 0.15912131915109146, 0.4773639574532743, 0.05890277506640788, 0.05890277506640788, 0.3534166503984473, 0.11780555013281575, 0.2945138753320394, 0.05890277506640788, 0.3373402841888146, 0.3342595509998757, 0.23875682214276833, 0.07393759653453472, 0.007701832972347366, 0.00462109978340842, 0.00462109978340842, 0.056792834609776584, 0.8518925191466488, 0.056792834609776584, 0.056792834609776584, 0.4005457579987402, 0.04087201612232043, 0.08174403224464086, 0.43324337089659654, 0.008174403224464085, 0.008174403224464085, 0.03269761289785634, 0.9044269723612004, 0.020555158462754554, 0.020555158462754554, 0.020555158462754554, 0.6545883582292351, 0.09875255404320359, 0.050787027793647556, 0.15800408646912573, 0.03103651698500684, 0.002821501544091531, 0.002821501544091531, 0.59981309481724, 0.13283058155122268, 0.05603790159192207, 0.18471752746966905, 0.022830256204116398, 0.0020754778367378544, 0.0020754778367378544, 0.7015682087952596, 0.09904492359462488, 0.08253743632885406, 0.008253743632885406, 0.09904492359462488, 0.06361961852298498, 0.06361961852298498, 0.8270550407988048, 0.06361961852298498, 0.18067790875480313, 0.18067790875480313, 0.18067790875480313, 0.18067790875480313, 0.36135581750960627, 0.08492508224461975, 0.028308360748206585, 0.8492508224461975, 0.028308360748206585, 0.039416908817519095, 0.86717199398542, 0.039416908817519095, 0.039416908817519095, 0.044584670293358705, 0.044584670293358705, 0.8471087355738154, 0.044584670293358705, 0.8883762004155723, 0.04230362859121773, 0.04230362859121773, 0.04230362859121773, 0.18066043802526446, 0.18066043802526446, 0.18066043802526446, 0.18066043802526446, 0.3613208760505289, 0.11033526632241762, 0.11033526632241762, 0.11033526632241762, 0.11033526632241762, 0.5516763316120881, 0.029396779491477905, 0.9113001642358151, 0.029396779491477905, 0.029396779491477905, 0.03432966428852213, 0.03432966428852213, 0.8582416072130534, 0.03432966428852213, 0.4338143776830969, 0.28354465510420973, 0.10822997876217469, 0.14311402150370206, 0.011628014247175793, 0.008944626343981379, 0.010733551612777654, 0.06772517880633776, 0.7449769668697154, 0.01693129470158444, 0.11851906291109109, 0.01693129470158444, 0.01693129470158444, 0.01693129470158444, 0.4499258811120154, 0.30920832158726985, 0.16663921522667238, 0.0481402177321498, 0.009257734179259578, 0.012960827850963409, 0.0018515468358519154, 0.20919527255699946, 0.670199669488165, 0.08910169016316644, 0.01936993264416662, 0.0038739865288333233, 0.0038739865288333233, 0.007747973057666647, 0.17026931822563113, 0.7203701924930548, 0.03929291959053026, 0.06548819931755044, 0.02343989046573154, 0.9141557281635301, 0.02343989046573154, 0.02343989046573154, 0.28776531207113193, 0.41210834815125064, 0.1136850615589657, 0.13855366877498945, 0.003552658173717678, 0.003552658173717678, 0.04263189808461214, 0.12623297793324054, 0.12623297793324054, 0.12623297793324054, 0.12623297793324054, 0.5049319117329621, 0.10648927149126264, 0.10648927149126264, 0.10648927149126264, 0.10648927149126264, 0.5324463574563132, 0.06128018550755459, 0.06128018550755459, 0.06128018550755459, 0.7966424115982097, 0.06628759486372011, 0.03314379743186006, 0.03314379743186006, 0.03314379743186006, 0.8285949357965015, 0.11997731964322389, 0.11997731964322389, 0.11997731964322389, 0.11997731964322389, 0.47990927857289556, 0.4042770081071196, 0.3703855223975407, 0.15493250610093207, 0.058099689787849525, 0.0024208204078270635, 0.009683281631308254, 0.0024208204078270635, 0.05872330984091213, 0.05872330984091213, 0.05872330984091213, 0.8221263377727698, 0.4380246658650515, 0.3132243420710983, 0.08320021586263548, 0.11256499793180096, 0.03181184724159592, 0.01712945620701319, 0.0024470651724304553, 0.24598467596467244, 0.24598467596467244, 0.24598467596467244, 0.24598467596467244, 0.24598467596467244, 0.054100341049146634, 0.8115051157371995, 0.054100341049146634, 0.054100341049146634, 0.020151602112101, 0.9269736971566459, 0.020151602112101, 0.020151602112101, 0.05172609701657723, 0.8276175522652357, 0.05172609701657723, 0.05172609701657723, 0.8707474570995726, 0.05678787763692865, 0.018929292545642882, 0.037858585091285764, 0.06369495014825102, 0.06369495014825102, 0.7643394017790123, 0.06369495014825102, 0.24539245033058835, 0.24539245033058835, 0.24539245033058835, 0.24539245033058835, 0.24539245033058835, 0.24539488560001924, 0.24539488560001924, 0.24539488560001924, 0.24539488560001924, 0.24539488560001924, 0.24539813392452056, 0.24539813392452056, 0.24539813392452056, 0.24539813392452056, 0.24539813392452056], "Term": ["_", "_", "_", "_", "_", "across_subject", "across_subject", "across_subject", "across_subject", "across_subject", "action", "action", "action", "action", "action", "action", "action", "active", "active", "active", "active", "adaptation", "adaptation", "adaptation", "adaptation", "address", "address", "address", "address", "address", "address", "address", "adversary", "adversary", "adversary", "adversary", "adversary", "agent", "agent", "agent", "agent", "agent", "agent", "agent", "al", "al", "al", "al", "algorithm", "algorithm", "algorithm", "algorithm", "algorithm", "algorithm", "algorithm", "alignment", "alignment", "alignment", "alignment", "alignment", "also", "also", "also", "also", "also", "also", "also", "analysis", "analysis", "analysis", "analysis", "analysis", "analysis", "analysis", "answer", "answer", "answer", "answer", "answer", "answer", "approach", "approach", "approach", "approach", "approach", "approach", "approach", "architecture", "architecture", "architecture", "architecture", "architecture", "architecture", "architecture", "assign", "assign", "assign", "assign", "assign", "assignment", "assignment", "assignment", "assignment", "assignment", "assignment", "assistant", "assistant", "assistant", "assistant", "assistant", "ax", "ax", "ax", "ax", "ax", "baleen", "baleen", "baleen", "baleen", "bandit", "bandit", "bandit", "bandit", "bandit", "base", "base", "base", "base", "base", "base", "base", "base_vqa", "base_vqa", "base_vqa", "base_vqa", "base_vqa", "baseline", "baseline", "baseline", "baseline", "baseline", "baseline", "baseline", "bc", "bc", "bc", "bc", "bc", "behavioral_clone", "behavioral_clone", "behavioral_clone", "behavioral_clone", "behavioral_clone", "bf", "bf", "bf", "bf", "bid", "bid", "bid", "bid", "bid", "bidding", "bidding", "bidding", "bidding", "bidding", "binary", "binary", "binary", "binary", "binary", "binary", "binary", "binary_classi\ufb01cation", "binary_classi\ufb01cation", "binary_classi\ufb01cation", "binary_classi\ufb01cation", "binary_classi\ufb01cation", "bind", "bind", "bind", "bind", "bind", "bit", "bit", "bit", "bit", "bit", "bmc", "bmc", "bmc", "bmc", "bootstrap", "bootstrap", "bootstrap", "bootstrap", "bound", "bound", "bound", "bound", "bound", "bound", "box", "box", "box", "box", "box", "box", "brain", "brain", "brain", "brain", "brain", "byzantine", "byzantine", "byzantine", "byzantine", "byzantine_agent", "byzantine_agent", "byzantine_agent", "byzantine_agent", "caption", "caption", "caption", "caption", "case", "case", "case", "case", "case", "case", "case", "causal_confusion", "causal_confusion", "causal_confusion", "causal_confusion", "causal_confusion", "cb_retrieval", "cb_retrieval", "cb_retrieval", "cb_retrieval", "cb_retrieval", "cefe", "cefe", "cefe", "cefe", "cefe", "chaotic", "chaotic", "chaotic", "chaotic", "characteristic_equation", "characteristic_equation", "characteristic_equation", "characteristic_equation", "cid", "cid", "cid", "cid", "cid", "cid", "cid", "cii", "cii", "cii", "cii", "cii", "circuit", "circuit", "circuit", "circuit", "class", "class", "class", "class", "class", "class", "classi\ufb01cation", "classi\ufb01cation", "classi\ufb01cation", "classi\ufb01cation", "classi\ufb01cation", "classi\ufb01cation", "classi\ufb01er", "classi\ufb01er", "classi\ufb01er", "classi\ufb01er", "classi\ufb01er", "classi\ufb01er", "cls", "cls", "cls", "cls", "cls", "cluster", "cluster", "cluster", "cluster", "cluster", "cluster", "cmax", "cmax", "cmax", "cmax", "cmax", "co_saliency", "co_saliency", "co_saliency", "co_saliency", "coagent", "coagent", "coagent", "coagent", "coan", "coan", "coan", "coan", "codebook", "codebook", "codebook", "codebook", "codebook", "collision", "collision", "collision", "collision", "collision", "compartment", "compartment", "compartment", "compartment", "compartmental", "compartmental", "compartmental", "compartmental", "condition", "condition", "condition", "condition", "condition", "condition", "condition", "conference", "conference", "conference", "conference", "conference", "conference", "conference", "confusion", "confusion", "confusion", "confusion", "confusion", "consistency", "consistency", "consistency", "consistency", "consistency", "consistency", "consistency", "consistency_losse", "consistency_losse", "consistency_losse", "consistency_losse", "consistency_losse", "constant", "constant", "constant", "constant", "constant", "constant", "constant", "constant_baseline", "constant_baseline", "constant_baseline", "constant_baseline", "constant_baseline", "continual", "continual", "continual", "continual", "continual", "cosamp", "cosamp", "cosamp", "cosamp", "cosamp", "cost_sensitive", "cost_sensitive", "cost_sensitive", "cost_sensitive", "cost_sensitive", "covariate", "covariate", "covariate", "covariate", "covid", "covid", "covid", "covid", "crbm", "crbm", "crbm", "crbm", "critic", "critic", "critic", "critic", "critical_point", "critical_point", "critical_point", "critical_point", "cv", "cv", "cv", "cv", "cv", "dataset", "dataset", "dataset", "dataset", "dataset", "dataset", "dataset", "datum", "datum", "datum", "datum", "datum", "datum", "datum", "de_anonymization", "de_anonymization", "de_anonymization", "de_anonymization", "de_anonymization", "deep", "deep", "deep", "deep", "deep", "deep", "defect", "defect", "defect", "defect", "defect", "demonstration", "demonstration", "demonstration", "demonstration", "demonstration", "demonstration", "densepose", "densepose", "densepose", "densepose", "dependent", "dependent", "dependent", "dependent", "dependent", "dependent_prior", "dependent_prior", "dependent_prior", "dependent_prior", "der", "der", "der", "der", "der", "detector", "detector", "detector", "detector", "detector", "device", "device", "device", "device", "de\ufb01nition", "de\ufb01nition", "de\ufb01nition", "de\ufb01nition", "de\ufb01nition", "de\ufb01nition", "dichotomy", "dichotomy", "dichotomy", "dichotomy", "dichotomy", "discard", "discard", "discard", "discard", "discard", "discrete_code", "discrete_code", "discrete_code", "discrete_code", "discrete_code", "distance", "distance", "distance", "distance", "distance", "distance", "distance", "distinctiveness", "distinctiveness", "distinctiveness", "distinctiveness", "distribution", "distribution", "distribution", "distribution", "distribution", "distribution", "distribution", "door", "door", "door", "door", "door", "dropblock", "dropblock", "dropblock", "dropblock", "dropblock", "ducti", "ducti", "ducti", "ducti", "ducti", "dvc", "dvc", "dvc", "dvc", "dvc", "eat", "eat", "eat", "eat", "eeg", "eeg", "eeg", "eeg", "electrode", "electrode", "electrode", "electrode", "ella", "ella", "ella", "ella", "ella", "elucidate", "elucidate", "elucidate", "elucidate", "elucidate", "embark", "embark", "embark", "embark", "embark", "energy", "energy", "energy", "energy", "energy", "environment", "environment", "environment", "environment", "environment", "environment", "environment_interaction", "environment_interaction", "environment_interaction", "environment_interaction", "environment_interaction", "equivariance", "equivariance", "equivariance", "equivariance", "equivariant", "equivariant", "equivariant", "equivariant", "error", "error", "error", "error", "error", "error", "error", "error_incurre", "error_incurre", "error_incurre", "error_incurre", "error_incurre", "evidence_procedure", "evidence_procedure", "evidence_procedure", "evidence_procedure", "executorioop", "executorioop", "executorioop", "executorioop", "executorioop", "expect", "expect", "expect", "expect", "expect", "expect", "expect", "expert_action", "expert_action", "expert_action", "expert_action", "expert_action", "expert_demonstration", "expert_demonstration", "expert_demonstration", "expert_demonstration", "expert_demonstration", "false_negative", "false_negative", "false_negative", "false_negative", "false_negative", "feature", "feature", "feature", "feature", "feature", "feature", "feature", "fiber", "fiber", "fiber", "fiber", "fiber", "fig", "fig", "fig", "fig", "fig", "fig", "figure", "figure", "figure", "figure", "figure", "figure", "figure", "fitness", "fitness", "fitness", "fitness", "flipr", "flipr", "flipr", "flipr", "flirt", "flirt", "flirt", "flirt", "flirt", "fluctuation", "fluctuation", "fluctuation", "fluctuation", "fluctuation", "follow", "follow", "follow", "follow", "follow", "follow", "follow", "forecast", "forecast", "forecast", "forecast", "forecasting", "forecasting", "forecasting", "forecasting", "forecasting", "forget", "forget", "forget", "forget", "fractional", "fractional", "fractional", "fractional", "fractional", "fractional_assignment", "fractional_assignment", "fractional_assignment", "fractional_assignment", "fractional_assignment", "freerexmomentum", "freerexmomentum", "freerexmomentum", "freerexmomentum", "fsl", "fsl", "fsl", "fsl", "fsl", "function", "function", "function", "function", "function", "function", "function", "functional", "functional", "functional", "functional", "functional", "functional_connectivity", "functional_connectivity", "functional_connectivity", "functional_connectivity", "functional_connectivity", "functioo", "functioo", "functioo", "functioo", "functioo", "gcm", "gcm", "gcm", "gcm", "gcm", "generate", "generate", "generate", "generate", "generate", "generate", "genetic", "genetic", "genetic", "genetic", "give", "give", "give", "give", "give", "give", "give", "gmm", "gmm", "gmm", "gmm", "goal", "goal", "goal", "goal", "goal", "goal", "goal", "goebelr", "goebelr", "goebelr", "goebelr", "goebelr", "gradient", "gradient", "gradient", "gradient", "gradient", "gradient", "grammar", "grammar", "grammar", "grammar", "graph", "graph", "graph", "graph", "graph", "graph", "ground", "ground", "ground", "ground", "ground", "guarantee", "guarantee", "guarantee", "guarantee", "guarantee", "guarantee", "guarantee", "gyrification", "gyrification", "gyrification", "gyrification", "gyrification", "hamdp", "hamdp", "hamdp", "hamdp", "hamdp", "hamdps", "hamdps", "hamdps", "hamdps", "hamdps", "hard_thresholding", "hard_thresholding", "hard_thresholding", "hard_thresholding", "hard_thresholding", "hardware", "hardware", "hardware", "hardware", "hash", "hash", "hash", "hash", "hash", "hidden_state", "hidden_state", "hidden_state", "hidden_state", "high_level", "high_level", "high_level", "high_level", "high_level", "high_level", "highlighted", "highlighted", "highlighted", "highlighted", "highlighted", "hinge", "hinge", "hinge", "hinge", "hoden", "hoden", "hoden", "hoden", "hop", "hop", "hop", "hop", "hop", "hotpotqa", "hotpotqa", "hotpotqa", "hotpotqa", "hover", "hover", "hover", "hover", "however", "however", "however", "however", "however", "however", "however", "htp", "htp", "htp", "htp", "htp", "htpt", "htpt", "htpt", "htpt", "htpt", "hypothesis", "hypothesis", "hypothesis", "hypothesis", "hypothesis", "hypothesis", "ibound", "ibound", "ibound", "ibound", "icnet", "icnet", "icnet", "icnet", "iiee", "iiee", "iiee", "iiee", "iiee", "image", "image", "image", "image", "image", "image", "image", "image_captione", "image_captione", "image_captione", "image_captione", "image_captione", "incentive", "incentive", "incentive", "incentive", "incentive", "incentive", "input", "input", "input", "input", "input", "input", "input", "instruction", "instruction", "instruction", "instruction", "instruction", "instruction_followe", "instruction_followe", "instruction_followe", "instruction_followe", "instruction_followe", "integrity", "integrity", "integrity", "integrity", "integrity", "international_conference", "international_conference", "international_conference", "international_conference", "international_conference", "international_conference", "international_conference", "intra_cue", "intra_cue", "intra_cue", "intra_cue", "intra_saliency", "intra_saliency", "intra_saliency", "intra_saliency", "inversioo", "inversioo", "inversioo", "inversioo", "inversioo", "involvement", "involvement", "involvement", "involvement", "involvement", "io", "io", "io", "io", "io", "iterative", "iterative", "iterative", "iterative", "iterative", "iterative", "jaccard", "jaccard", "jaccard", "jaccard", "jaccard", "jlikliandlfei", "jlikliandlfei", "jlikliandlfei", "jlikliandlfei", "jlikliandlfei", "label", "label", "label", "label", "label", "label", "label_set", "label_set", "label_set", "label_set", "labeling", "labeling", "labeling", "labeling", "labeling", "labeling", "labeling", "language", "language", "language", "language", "language", "language_biase", "language_biase", "language_biase", "language_biase", "language_biase", "latency", "latency", "latency", "latency", "latency_predictor", "latency_predictor", "latency_predictor", "latency_predictor", "latentexecutor", "latentexecutor", "latentexecutor", "latentexecutor", "latentexecutor", "layer", "layer", "layer", "layer", "layer", "layer", "lcon", "lcon", "lcon", "lcon", "lcon", "learn", "learn", "learn", "learn", "learn", "learn", "learn", "learning", "learning", "learning", "learning", "learning", "learning", "learning", "let", "let", "let", "let", "let", "let", "let", "lezamatlozano", "lezamatlozano", "lezamatlozano", "lezamatlozano", "lezamatlozano", "linear", "linear", "linear", "linear", "linear", "linear", "linear", "lmax", "lmax", "lmax", "lmax", "load", "load", "load", "load", "load", "load", "lobe", "lobe", "lobe", "lobe", "lobe", "lobule", "lobule", "lobule", "lobule", "lobule", "lop", "lop", "lop", "lop", "lop", "loss", "loss", "loss", "loss", "loss", "loss", "loss", "low_level", "low_level", "low_level", "low_level", "low_level", "low_level", "lsh", "lsh", "lsh", "lsh", "lsh", "matrix", "matrix", "matrix", "matrix", "matrix", "matrix", "matrix", "maze", "maze", "maze", "maze", "maze", "mdp_homomorphism", "mdp_homomorphism", "mdp_homomorphism", "mdp_homomorphism", "measure", "measure", "measure", "measure", "measure", "measure", "measure", "measurement", "measurement", "measurement", "measurement", "measurement", "meta", "meta", "meta", "meta", "method", "method", "method", "method", "method", "method", "method", "meuli", "meuli", "meuli", "meuli", "meuli", "micro", "micro", "micro", "micro", "micro", "micro_macro", "micro_macro", "micro_macro", "micro_macro", "micro_macro", "microcircuit", "microcircuit", "microcircuit", "microcircuit", "minibatch", "minibatch", "minibatch", "minibatch", "minibatche", "minibatche", "minibatche", "minibatche", "minimal_agreement", "minimal_agreement", "minimal_agreement", "minimal_agreement", "minimal_agreement", "minimizer", "minimizer", "minimizer", "minimizer", "misprediction", "misprediction", "misprediction", "misprediction", "misprediction", "miuimize", "miuimize", "miuimize", "miuimize", "miuimize", "mixer", "mixer", "mixer", "mixer", "mlc", "mlc", "mlc", "mlc", "model", "model", "model", "model", "model", "model", "model", "molecular", "molecular", "molecular", "molecular", "molecule", "molecule", "molecule", "molecule", "momentum", "momentum", "momentum", "momentum", "motif", "motif", "motif", "motif", "motion_planne", "motion_planne", "motion_planne", "motion_planne", "multiclass", "multiclass", "multiclass", "multiclass", "multiclass", "mva", "mva", "mva", "mva", "mva", "myopic_policy", "myopic_policy", "myopic_policy", "myopic_policy", "myopic_policy", "nas", "nas", "nas", "nas", "ncor", "ncor", "ncor", "ncor", "network", "network", "network", "network", "network", "network", "network", "neural", "neural", "neural", "neural", "neural", "neural", "neural", "neuron", "neuron", "neuron", "neuron", "neuron", "neuron", "nhl", "nhl", "nhl", "nhl", "nhl", "noise", "noise", "noise", "noise", "noise", "noise", "non", "non", "non", "non", "non", "non", "northwestern", "northwestern", "northwestern", "northwestern", "northwestern", "number", "number", "number", "number", "number", "number", "number", "object_aware", "object_aware", "object_aware", "object_aware", "object_aware", "object_detection", "object_detection", "object_detection", "object_detection", "object_detection", "omp", "omp", "omp", "omp", "omp", "ompr", "ompr", "ompr", "ompr", "ompr", "open", "open", "open", "open", "open", "open", "open", "optimal", "optimal", "optimal", "optimal", "optimal", "optimal", "optimal", "optimistic", "optimistic", "optimistic", "optimistic", "optimization", "optimization", "optimization", "optimization", "optimization", "optimization", "optimization", "oreo", "oreo", "oreo", "oreo", "oreo", "oscillator", "oscillator", "oscillator", "oscillator", "ospan", "ospan", "ospan", "ospan", "ospan", "output", "output", "output", "output", "output", "output", "output", "p", "p", "p", "p", "p", "pair", "pair", "pair", "pair", "pair", "pair", "pair", "pairwise_constraine", "pairwise_constraine", "pairwise_constraine", "pairwise_constraine", "pairwise_constraine", "panel", "panel", "panel", "panel", "panel", "paper", "paper", "paper", "paper", "paper", "paper", "paper", "paracingulate", "paracingulate", "paracingulate", "paracingulate", "paracingulate", "parameter", "parameter", "parameter", "parameter", "parameter", "parameter", "parameter", "parse", "parse", "parse", "parse", "parse", "particle_\ufb01lter", "particle_\ufb01lter", "particle_\ufb01lter", "particle_\ufb01lter", "partition", "partition", "partition", "partition", "partition", "partition", "passage", "passage", "passage", "passage", "patch", "patch", "patch", "patch", "patch", "path", "path", "path", "path", "path", "pattern", "pattern", "pattern", "pattern", "pattern", "pattern", "pattern", "peer_review", "peer_review", "peer_review", "peer_review", "peer_review", "performance", "performance", "performance", "performance", "performance", "performance", "performance", "pick", "pick", "pick", "pick", "pick", "pna", "pna", "pna", "pna", "pna", "policy", "policy", "policy", "policy", "policy", "policy", "policy", "polytechnical", "polytechnical", "polytechnical", "polytechnical", "polytechnical", "postsynaptic", "postsynaptic", "postsynaptic", "postsynaptic", "potential", "potential", "potential", "potential", "potential", "potential", "power_law", "power_law", "power_law", "power_law", "ppca", "ppca", "ppca", "ppca", "predicted_labeling", "predicted_labeling", "predicted_labeling", "predicted_labeling", "predicted_labeling", "probability", "probability", "probability", "probability", "probability", "probability", "probability", "problem", "problem", "problem", "problem", "problem", "problem", "problem", "profile", "profile", "profile", "profile", "profile", "program_chair", "program_chair", "program_chair", "program_chair", "program_chair", "programdecoder", "programdecoder", "programdecoder", "programdecoder", "programdecoder", "property", "property", "property", "property", "property", "property", "property", "propose", "propose", "propose", "propose", "propose", "propose", "propose", "ptpt", "ptpt", "ptpt", "ptpt", "ptpt", "pulse", "pulse", "pulse", "pulse", "pure_potential", "pure_potential", "pure_potential", "pure_potential", "query", "query", "query", "query", "query", "question", "question", "question", "question", "question", "question", "question", "questionable", "questionable", "questionable", "questionable", "questionable", "recovery", "recovery", "recovery", "recovery", "recovery", "recurrent", "recurrent", "recurrent", "recurrent", "recurrent", "recurrent_kernel", "recurrent_kernel", "recurrent_kernel", "recurrent_kernel", "red_ball", "red_ball", "red_ball", "red_ball", "red_ball", "region", "region", "region", "region", "region", "region", "regret", "regret", "regret", "regret", "regret", "reho", "reho", "reho", "reho", "reho", "reinforcement", "reinforcement", "reinforcement", "reinforcement", "reinforcement", "reinforcement", "relationship", "relationship", "relationship", "relationship", "relationship", "relationship", "replay", "replay", "replay", "replay", "replay", "representation", "representation", "representation", "representation", "representation", "representation", "representation", "reroote", "reroote", "reroote", "reroote", "research", "research", "research", "research", "research", "research", "research", "reservoir_compute", "reservoir_compute", "reservoir_compute", "reservoir_compute", "resilient", "resilient", "resilient", "resilient", "reso", "reso", "reso", "reso", "reso", "resolution", "resolution", "resolution", "resolution", "result", "result", "result", "result", "result", "result", "result", "resultstable", "resultstable", "resultstable", "resultstable", "resultstable", "retrieval", "retrieval", "retrieval", "retrieval", "retrieval", "retrieval", "retrieval", "retrieve", "retrieve", "retrieve", "retrieve", "retrieve", "retrieve", "review", "review", "review", "review", "review", "reviewer", "reviewer", "reviewer", "reviewer", "reviewer", "reviewer", "reward", "reward", "reward", "reward", "reward", "rip", "rip", "rip", "rip", "rip", "rnn", "rnn", "rnn", "rnn", "robot", "robot", "robot", "robot", "robot", "robotic", "robotic", "robotic", "robotic", "robotic", "roi", "roi", "roi", "roi", "roi", "roi", "rois", "rois", "rois", "rois", "rois", "rois", "round", "round", "round", "round", "round", "sakurai", "sakurai", "sakurai", "sakurai", "sakurai", "sample", "sample", "sample", "sample", "sample", "sample", "sample", "sample_efficiency", "sample_efficiency", "sample_efficiency", "sample_efficiency", "sample_efficiency", "scalepre", "scalepre", "scalepre", "scalepre", "scalepre", "section", "section", "section", "section", "section", "section", "section", "segregate", "segregate", "segregate", "segregate", "segregate", "segregated", "segregated", "segregated", "segregated", "segregated", "sentence", "sentence", "sentence", "sentence", "sequence", "sequence", "sequence", "sequence", "sequence", "sequence", "set", "set", "set", "set", "set", "set", "set", "sgld", "sgld", "sgld", "sgld", "shoot", "shoot", "shoot", "shoot", "show", "show", "show", "show", "show", "show", "show", "signal", "signal", "signal", "signal", "signal", "signal", "similarity", "similarity", "similarity", "similarity", "similarity", "similarity", "similarity", "simulated_anneale", "simulated_anneale", "simulated_anneale", "simulated_anneale", "simulated_anneale", "single_stage", "single_stage", "single_stage", "single_stage", "single_stage", "siren", "siren", "siren", "siren", "sism", "sism", "sism", "sism", "size", "size", "size", "size", "size", "size", "size", "social_dilemma", "social_dilemma", "social_dilemma", "social_dilemma", "social_dilemma", "solution", "solution", "solution", "solution", "solution", "solution", "solution", "space", "space", "space", "space", "space", "space", "space", "sparse", "sparse", "sparse", "sparse", "sparse", "sparse", "spike", "spike", "spike", "spike", "spike_train", "spike_train", "spike_train", "spike_train", "spontaneous", "spontaneous", "spontaneous", "spontaneous", "spontaneous", "ssd", "ssd", "ssd", "ssd", "ssd", "stage", "stage", "stage", "stage", "stage", "stage", "stage_detector", "stage_detector", "stage_detector", "stage_detector", "stage_detector", "state", "state", "state", "state", "state", "state", "state", "stem", "stem", "stem", "stem", "step", "step", "step", "step", "step", "step", "step", "stimulus", "stimulus", "stimulus", "stimulus", "stochastic", "stochastic", "stochastic", "stochastic", "stochastic", "stochastic", "structural_connectivity", "structural_connectivity", "structural_connectivity", "structural_connectivity", "structural_connectivity", "structural_profile", "structural_profile", "structural_profile", "structural_profile", "structural_profile", "subcortical", "subcortical", "subcortical", "subcortical", "subcortical", "subset", "subset", "subset", "subset", "subset", "subtask", "subtask", "subtask", "subtask", "subtask", "sufficiently", "sufficiently", "sufficiently", "sufficiently", "sufficiently", "sufficiently", "suf\ufb01xe", "suf\ufb01xe", "suf\ufb01xe", "suf\ufb01xe", "supp", "supp", "supp", "supp", "supp", "support", "support", "support", "support", "support", "support", "support", "svcca", "svcca", "svcca", "svcca", "svcca", "svmperf", "svmperf", "svmperf", "svmperf", "svmperf", "system", "system", "system", "system", "system", "system", "system", "table", "table", "table", "table", "table", "table", "table", "task", "task", "task", "task", "task", "task", "task", "theorem", "theorem", "theorem", "theorem", "theorem", "theorem", "theorem", "thoo", "thoo", "thoo", "thoo", "thoo", "threshold_logic", "threshold_logic", "threshold_logic", "threshold_logic", "threshold_logic", "thresholde", "thresholde", "thresholde", "thresholde", "thresholde", "thresholde", "time", "time", "time", "time", "time", "time", "time", "tmdp", "tmdp", "tmdp", "tmdp", "top", "top", "top", "top", "top", "top", "top", "topological", "topological", "topological", "topological", "train", "train", "train", "train", "train", "train", "train", "training", "training", "training", "training", "training", "training", "training", "trajectory", "trajectory", "trajectory", "trajectory", "trajectory", "traveling_pulse", "traveling_pulse", "traveling_pulse", "traveling_pulse", "triplet_constraine", "triplet_constraine", "triplet_constraine", "triplet_constraine", "triplet_constraine", "trs_oden", "trs_oden", "trs_oden", "trs_oden", "trw", "trw", "trw", "trw", "unitary", "unitary", "unitary", "unitary", "unseen_device", "unseen_device", "unseen_device", "unseen_device", "untruthful", "untruthful", "untruthful", "untruthful", "untruthful", "updn", "updn", "updn", "updn", "updn", "uproot", "uproot", "uproot", "uproot", "urnn", "urnn", "urnn", "urnn", "use", "use", "use", "use", "use", "use", "use", "user", "user", "user", "user", "user", "user", "user", "value", "value", "value", "value", "value", "value", "value", "variable", "variable", "variable", "variable", "variable", "variable", "variable", "variational", "variational", "variational", "variational", "vbo", "vbo", "vbo", "vbo", "vector", "vector", "vector", "vector", "vector", "vector", "vector", "voc", "voc", "voc", "voc", "voc", "voc_voc", "voc_voc", "voc_voc", "voc_voc", "voc_voc", "volume_conduction", "volume_conduction", "volume_conduction", "volume_conduction", "vqa", "vqa", "vqa", "vqa", "vqa", "vqa_cp", "vqa_cp", "vqa_cp", "vqa_cp", "vqa_cp", "weight", "weight", "weight", "weight", "weight", "weight", "weight", "wikipedia", "wikipedia", "wikipedia", "wikipedia", "work", "work", "work", "work", "work", "work", "work", "worldpro", "worldpro", "worldpro", "worldpro", "worldpro", "\u02c6\u03b8k", "\u02c6\u03b8k", "\u02c6\u03b8k", "\u02c6\u03b8k", "\u02c6\u03b8kl", "\u02c6\u03b8kl", "\u02c6\u03b8kl", "\u02c6\u03b8kl", "\u02c6\u03b8li", "\u02c6\u03b8li", "\u02c6\u03b8li", "\u02c6\u03b8li", "\ufb01ne_tuning", "\ufb01ne_tuning", "\ufb01ne_tuning", "\ufb01ne_tuning", "\ufb01ring_rate", "\ufb01ring_rate", "\ufb01ring_rate", "\ufb01ring_rate", "\ud835\udc38\ud835\udc50", "\ud835\udc38\ud835\udc50", "\ud835\udc38\ud835\udc50", "\ud835\udc38\ud835\udc50", "\ud835\udc38\ud835\udc50", "\ud835\udc38\ud835\udc53", "\ud835\udc38\ud835\udc53", "\ud835\udc38\ud835\udc53", "\ud835\udc38\ud835\udc53", "\ud835\udc38\ud835\udc53", "\ud835\udc40\ud835\udc38\ud835\udc53", "\ud835\udc40\ud835\udc38\ud835\udc53", "\ud835\udc40\ud835\udc38\ud835\udc53", "\ud835\udc40\ud835\udc38\ud835\udc53", "\ud835\udc40\ud835\udc38\ud835\udc53"]}, "R": 30, "lambda.step": 0.01, "plot.opts": {"xlab": "PC1", "ylab": "PC2"}, "topic.order": [5, 2, 1, 8, 7, 4, 3, 6]};

function LDAvis_load_lib(url, callback){
  var s = document.createElement('script');
  s.src = url;
  s.async = true;
  s.onreadystatechange = s.onload = callback;
  s.onerror = function(){console.warn("failed to load library " + url);};
  document.getElementsByTagName("head")[0].appendChild(s);
}

if(typeof(LDAvis) !== "undefined"){
   // already loaded: just create the visualization
   !function(LDAvis){
       new LDAvis("#" + "ldavis_el27545871397211637755529140865402", ldavis_el27545871397211637755529140865402_data);
   }(LDAvis);
}else if(typeof define === "function" && define.amd){
   // require.js is available: use it to load d3/LDAvis
   require.config({paths: {d3: "https://d3js.org/d3.v5"}});
   require(["d3"], function(d3){
      window.d3 = d3;
      LDAvis_load_lib("https://cdn.jsdelivr.net/gh/bmabey/pyLDAvis@3.3.1/pyLDAvis/js/ldavis.v3.0.0.js", function(){
        new LDAvis("#" + "ldavis_el27545871397211637755529140865402", ldavis_el27545871397211637755529140865402_data);
      });
    });
}else{
    // require.js not available: dynamically load d3 & LDAvis
    LDAvis_load_lib("https://d3js.org/d3.v5.js", function(){
         LDAvis_load_lib("https://cdn.jsdelivr.net/gh/bmabey/pyLDAvis@3.3.1/pyLDAvis/js/ldavis.v3.0.0.js", function(){
                 new LDAvis("#" + "ldavis_el27545871397211637755529140865402", ldavis_el27545871397211637755529140865402_data);
            })
         });
}
</script>




```python
import pandas as pd

df = pd.read_csv('lda_tuning_results.csv')
print(df.head())
print(df[df['Coherence'] == max(df['Coherence'] )])
```

      Validation_Set  Topics Alpha                Beta  Coherence
    0     75% Corpus       2  0.01                0.01   0.255210
    1     75% Corpus       2  0.01                0.31   0.257202
    2     75% Corpus       2  0.01                0.61   0.251002
    3     75% Corpus       2  0.01  0.9099999999999999   0.250497
    4     75% Corpus       2  0.01           symmetric   0.251002
        Validation_Set  Topics       Alpha                Beta  Coherence
    268     75% Corpus      10  asymmetric  0.9099999999999999   0.425221



```python
import seaborn as sns
import matplotlib.pyplot as plt
```


```python
def int_to_round_str(val):
    
    try : 
        return str(np.round(float(val),4))
#         return str(val)[0]
    except :
        return str(val)
#         return str(val[0])
 
```


```python
topic_10 = df[(df['Topics']==10 )& (df['Validation_Set']=='75% Corpus')]
topic_10.loc[:,'Alpha'] = topic_10.loc[:,'Alpha'] .map(lambda x: str(x))
topic_10.loc[:,'Beta'] =topic_10.loc[:,'Beta'] .apply(lambda x: int_to_round_str(x))
```

    /var/folders/qj/0ym5ps652l76x64w3xg4ktw00000gn/T/ipykernel_14847/454671947.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      topic_10.loc[:,'Alpha'] = topic_10.loc[:,'Alpha'] .map(lambda x: str(x))
    /var/folders/qj/0ym5ps652l76x64w3xg4ktw00000gn/T/ipykernel_14847/454671947.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      topic_10.loc[:,'Beta'] =topic_10.loc[:,'Beta'] .apply(lambda x: int_to_round_str(x))



```python
fig = plt.figure(figsize = (10, 10))
ax = plt.subplot(111)

plt.style.use('seaborn-whitegrid')
# sns.scatterplot(data = topic_10, x= 'Alpha', y = 'Coherence', hue = 'Beta', ax = ax)
sns.scatterplot(data = topic_10, x= 'Alpha', y = 'Beta', size = 'Coherence', hue = 'Coherence', sizes = (10, 1000), ax = ax)
    # plt.ylim(0, 1)
locs, labels = plt.xticks()
plt.xticks(locs, ['0.01', '0.31', '0.61', '0.91', 'Symmetric', 'Asymmetric'], rotation = 45)
locs, labels = plt.yticks()
plt.yticks(locs, ['0.01', '0.31', '0.61', '0.91', 'Symmetric'], rotation = 45)
# plt.legend(['0.01', '0.31', '0.61', '0.91', 'Symmetric', 'Asymmetric'], bbox_to_anchor=(1.5, 1))
plt.legend(bbox_to_anchor=(1.5, 1), title = 'Coherence Score', title_fontsize = 20)

plt.xlabel('Hyperparameter : Alpha', fontweight = 'bold', fontsize = 20)
plt.ylabel('Hyperparameter : Beta', fontweight = 'bold', fontsize = 20)
plt.title('Hyperparameter tuning', fontweight = 'bold', y=1.08, fontsize = 26)
plt.show()


```


    
![png](output_22_0.png)
    



```python

```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Input In [83], in <cell line: 1>()
    ----> 1 sns.heatmap(data = topic_10.loc[:,['Alpha', 'Beta']])


    File ~/opt/anaconda3/lib/python3.9/site-packages/seaborn/_decorators.py:46, in _deprecate_positional_args.<locals>.inner_f(*args, **kwargs)
         36     warnings.warn(
         37         "Pass the following variable{} as {}keyword arg{}: {}. "
         38         "From version 0.12, the only valid positional argument "
       (...)
         43         FutureWarning
         44     )
         45 kwargs.update({k: arg for k, arg in zip(sig.parameters, args)})
    ---> 46 return f(**kwargs)


    File ~/opt/anaconda3/lib/python3.9/site-packages/seaborn/matrix.py:540, in heatmap(data, vmin, vmax, cmap, center, robust, annot, fmt, annot_kws, linewidths, linecolor, cbar, cbar_kws, cbar_ax, square, xticklabels, yticklabels, mask, ax, **kwargs)
        362 """Plot rectangular data as a color-encoded matrix.
        363 
        364 This is an Axes-level function and will draw the heatmap into the
       (...)
        537     ...     ax = sns.heatmap(corr, mask=mask, vmax=.3, square=True)
        538 """
        539 # Initialize the plotter object
    --> 540 plotter = _HeatMapper(data, vmin, vmax, cmap, center, robust, annot, fmt,
        541                       annot_kws, cbar, cbar_kws, xticklabels,
        542                       yticklabels, mask)
        544 # Add the pcolormesh kwargs here
        545 kwargs["linewidths"] = linewidths


    File ~/opt/anaconda3/lib/python3.9/site-packages/seaborn/matrix.py:159, in _HeatMapper.__init__(self, data, vmin, vmax, cmap, center, robust, annot, fmt, annot_kws, cbar, cbar_kws, xticklabels, yticklabels, mask)
        156 self.ylabel = ylabel if ylabel is not None else ""
        158 # Determine good default values for the colormapping
    --> 159 self._determine_cmap_params(plot_data, vmin, vmax,
        160                             cmap, center, robust)
        162 # Sort out the annotations
        163 if annot is None or annot is False:


    File ~/opt/anaconda3/lib/python3.9/site-packages/seaborn/matrix.py:193, in _HeatMapper._determine_cmap_params(self, plot_data, vmin, vmax, cmap, center, robust)
        190 """Use some heuristics to set good defaults for colorbar and range."""
        192 # plot_data is a np.ma.array instance
    --> 193 calc_data = plot_data.astype(float).filled(np.nan)
        194 if vmin is None:
        195     if robust:


    ValueError: could not convert string to float: 'symmetric'



```python

```
